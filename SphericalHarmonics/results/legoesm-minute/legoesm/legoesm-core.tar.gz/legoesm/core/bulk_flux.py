"""Monin-Obukhov bulk air-sea flux algorithms.

Provides stability-dependent transfer coefficients using iterative
Monin-Obukhov similarity theory (MOST). Three schemes:

1. ``constant`` — Fixed neutral transfer coefficients (no iteration)
2. ``coare3`` — COARE 3.0 (Fairall et al. 2003) as implemented by AeroBulk
   1.0.0 ``TURB_COARE3P0`` (Brodeau; tag 1.0.0, SHA ca40928872eb), ported
   faithfully: bulk-Richardson first guess, Charnock + smooth-flow roughness
   with visc_air(T), built-in gustiness, zeta clipped at +-50, height
   adjustment of t/q for zt != zu, Cx_min floors, AeroBulk's single-precision
   literals.  Oracle-matched to 1e-10 by tests/core/test_aerobulk_coare3p0_oracle.py.
3. ``large_yeager`` — Large & Yeager 2004/2009 (CORE/OMIP) as implemented by
   AeroBulk 1.0.0 ``TURB_NCAR``, ported faithfully: LY09 C_DN(U_10N) with the
   2.34e-3 plateau above 33 m/s, U_N10 from the current Cd and psi_m, Cx_min
   floors, height adjustment of t/q.  Oracle-matched by
   tests/core/test_aerobulk_ncar_oracle.py.

RULE 5 (#2241): coare3's Charnock wind ramp and gustiness onset, and
large_yeager's neutral Stanton switches (first guess and loop) and 33 m/s drag
cutoff, are smooth by default (``coare_charnock_ramp_width``,
``coare_gust_onset_width``, ``large_yeager_neutral_width``,
``large_yeager_dthv_width``, ``large_yeager_cd_cutoff_width``; 0 = the
oracle).  The three large_yeager widths are fields of every component config
that selects a bulk scheme, passed by each caller via
:func:`large_yeager_widths` (the 2 m diagnostic still uses the defaults).  coare3's dt/dq sign floors stay hard as in AeroBulk (division guard,
user decision 2026-10-31; KNOWN DIFFERENCE, see :func:`_sign_floor`).

The iterative Obukhov length loop uses ``jax.lax.fori_loop`` for
full JAX differentiability (compatible with jax.grad, jax.jit).

The ``large_yeager`` path is the OMIP-2 protocol bulk formula (Griffies
2016 §2.2 mandates Large & Yeager 2009).

References
----------
- Fairall, C. W., et al. (2003). Bulk parameterization of air-sea fluxes:
  Updates and verification for the COARE algorithm. J. Climate, 16, 571-591.
- Large, W. G., & Yeager, S. G. (2009). The global climatology of an
  interannually varying air-sea flux data set. Climate Dynamics, 33,
  341-364. doi:10.1007/s00382-008-0441-3.
- Businger, J. A., et al. (1971). Flux-profile relationships in the
  atmospheric surface layer. J. Atmos. Sci., 28, 181-189.
- Dyer, A. J. (1974). A review of flux-profile relationships. Boundary-Layer
  Meteorol., 7, 363-372.
- Beljaars, A. C. M., & Holtslag, A. A. M. (1991). Flux parameterization over
  land surfaces for atmospheric models. J. Appl. Meteorol., 30, 327-341.
- Grachev, A. A., Andreas, E. L., Fairall, C. W., Guest, P. S., & Persson,
  P. O. G. (2007). SHEBA flux-profile relationships in the stable atmospheric
  boundary layer. Boundary-Layer Meteorol., 124, 315-333.
  doi:10.1007/s10546-007-9177-6.
- Gryanik, V. M., Lupkes, C., Grachev, A., & Sidorenko, D. (2020). New modified
  and extended stability functions for the stable boundary layer based on SHEBA
  and parametrizations of bulk transfer coefficients for climate models.
  J. Atmos. Sci., 77, 2687-2716. doi:10.1175/JAS-D-19-0255.1.

The stable-regime (zeta>0) similarity functions are selectable via the
``stability_scheme`` argument to :func:`psi_m` / :func:`psi_h` /
:func:`psi_m_coare` / :func:`psi_h_coare` / :func:`compute_most_fluxes`; the
unstable branch is never affected by the selector — Businger-Dyer on the
``psi_m``/``psi_h`` path, the Fairall (1996/2003) Kansas + free-convective
blend on the COARE path.  On ``coare3`` the default ``"dyer1974"`` is a
sentinel for the byte-identical COARE-native stable form (itself the BH91 fit
with rounded constants — see :func:`psi_m_coare`).  Coefficient values
cross-checked against CliMA ``SurfaceFluxes.jl`` (``UniversalFunctions``).
"""

from __future__ import annotations

import functools
import math
import numbers
from typing import NamedTuple

import jax
import jax.numpy as jnp
import numpy as np

from legoesm import constants
from legoesm.core.source_rounding import nemo_source_round as sr
from legoesm.core.smooth import positive_part_c1, smoothstep_quintic

# Physical constants
KAPPA = constants.kappa_von_karman
G = constants.g

# Known bulk-flux scheme names (union across all surface-flux dispatchers):
#   "constant"     — fixed neutral transfer coefficients (no iteration)
#   "most"         — iterative MOST with fixed roughness (constant-z0 stability)
#   "coare3"       — COARE 3.0
#   "large_yeager" — Large & Yeager 2009 (OMIP)
#   "large_yeager_cesm" — CESM/CIME ``shr_flux_atmOcn`` (Large & Pond 1981/82
#                         + LY04 neutral coefficients, 2 fixed iterations);
#                         see ``compute_sam_oceflx_fluxes(variant="cesm")``
#   "nemo_si3_constant" — NEMO SI3 constant-coefficient ice/ocean bulk identity
_VALID_BULK_SCHEMES = (
    "constant", "most", "coare3", "large_yeager", "large_yeager_cesm",
    "nemo_si3_constant",
)


# ============================================================================
# Stable-regime stability-function coefficients (empirical fits)
# ============================================================================
# ``stability_scheme`` selects the STABLE-branch (zeta = z/L > 0) Monin-Obukhov
# similarity functions psi_m, psi_h. The UNSTABLE branch (zeta < 0) stays
# Businger-Dyer for every scheme. These are EMPIRICAL fit coefficients (not
# physical constants), tabulated here as module-level named constants -- not
# inline literals -- each under its published-reference provenance block. Values
# cross-checked against CliMA SurfaceFluxes.jl (UniversalFunctions / ClimaParams).
_VALID_STABILITY_SCHEMES = (
    "dyer1974",
    "beljaars_holtslag1991",
    "grachev2007_sheba",
    "gryanik2020",
)

# --- Dyer (1974) linear stable functions ---
# psi_m(zeta) = psi_h(zeta) = -beta*zeta (the historical default). Dyer (1974).
_DYER_STABLE_BETA = 5.0

# --- Businger-Dyer (1971) / Dyer (1974) UNSTABLE-branch coefficient ---
# The universal gamma in the unstable dimensionless gradient functions
# phi_m = (1 - gamma*zeta)^{-1/4}, phi_h = (1 - gamma*zeta)^{-1/2} that
# integrate to the Businger-Dyer psi_m/psi_h; the historical value is 16.
# Businger et al. (1971) J. Atmos. Sci. 28, 181-189; Dyer (1974) BLM 7, 363-372.
# UNSTABLE branch only (zeta < 0); the beljaars/grachev/gryanik schemes carry
# their OWN published fits and are NOT reparameterised by this coefficient.
_DYER_UNSTABLE_GAMMA = 16.0

# --- Beljaars & Holtslag (1991) stable functions ---
#   psi_m(zeta) = -(a*zeta + b*(zeta - c/d)*exp(-d*zeta) + b*c/d)
#   psi_h(zeta) = -((1 + 2a*zeta/3)^{3/2} + b*(zeta - c/d)*exp(-d*zeta) + b*c/d - 1)
_BH91_A = 1.0
_BH91_B = 0.667
_BH91_C = 5.0
_BH91_D = 0.35

# --- Grachev et al. (2007) SHEBA stable functions ---
# Momentum = their Eq. 12 (x = (1+zeta)^{1/3}, B_m = (1/b_m - 1)^{1/3});
# heat = their Eq. 13 (B_h = (c_h^2 - 4)^{1/2}); b_m = a_m/6.5. Rational/log-
# arctan fits valid to very large zeta (Arctic sea-ice / strongly-stable SBL).
_GRACHEV_A_M = 5.0
_GRACHEV_B_M = 5.0 / 6.5  # = 0.7692307692307693
_GRACHEV_A_H = 5.0
_GRACHEV_B_H = 5.0
_GRACHEV_C_H = 3.0
# Grachev et al. (2007) Eq. 13 assumes phi_h(0) = 1 — there is NO neutral-
# Prandtl prefactor in the paper (d psi_h/d zeta|0+ = -a_h = -5), and CliMA
# SurfaceFluxes.jl likewise pins Pr_0 = 1.0 for Grachev (CreateParametersExt:
# "the formulation assumes phi_h(0) = 1.0").  Pr0 = 0.98 belongs to the
# Gryanik et al. (2020) modification only (see _GRYANIK_PR0 below).
_GRACHEV_PR0 = 1.0        # neutral turbulent Prandtl number (paper + CliMA)

# --- Gryanik et al. (2020) modified SHEBA stable functions ---
#   psi_m(zeta) = -3*(a_m/b_m)*((1 + b_m*zeta)^{1/3} - 1)
#   psi_h(zeta) = -Pr0*(a_h/b_h)*ln(1 + b_h*zeta)
_GRYANIK_A_M = 5.0
_GRYANIK_B_M = 0.3
_GRYANIK_A_H = 5.0
_GRYANIK_B_H = 0.4
_GRYANIK_PR0 = 0.98

# --- Thermal/momentum roughness ratio z0h/z0 ---
# Ratio of the thermal (scalar) roughness length z0h (= z0_t = z0_q) to the
# aerodynamic momentum roughness length z0 for the FIXED-roughness MOST path
# ("constant"/"most"): z0_t = z0 * _Z0H_Z0_RATIO_DEFAULT.  ~0.1 is the typical
# land value (Garratt 1992 §4; the Zilitinkevich 1995 kB^-1 = ln(z0/z0h) family
# spans ~0.01-1 over natural surfaces).  A LARGER ratio raises z0_t, SHRINKS the
# heat log-law denominator ln(z_t/z0_t), RAISES the heat exchange coefficient
# and thereby STRENGTHENS the sensible/latent flux.  COARE 3.0 and large_yeager
# compute their OWN scalar roughness (Fairall smooth-flow Re fit / LY09
# coefficient space) and DO NOT read this ratio.
_Z0H_Z0_RATIO_DEFAULT = 0.1

# Safety floor for the base of the Beljaars-Holtslag psi_h ^{3/2} power. In the
# valid domain (zeta > 0) the base 1 + 2a*zeta/3 >= 1, so the floor is inert; it
# only guards a direct out-of-domain (zeta <= 0) call from a NaN value/gradient
# (fractional power of a non-positive base) -- the "clamp the base before the
# power" AD-safety rule.
_BH91_PSIH_BASE_FLOOR = 1e-6


def surface_reference_state(T, z_ref, z_low=None):
    """Pair model-level height with dry-adiabatic surface-referenced air T.

    Observed forcing (z_low=None) already follows its supplied reference
    convention. Model-level forcing must move BOTH height and temperature.
    """
    if z_low is None:
        return T, z_ref
    # Sensible heat is positive UPWARD: H = rho cp Ch U (T_sfc - T_air).
    # Bringing air down warms it (+g z/cp), reducing upward H; land loses H
    # through -H in its energy budget. Height simultaneously reduces exchange.
    return T + (constants.g / constants.c_pd) * z_low, z_low


def apply_gustiness(u: jax.Array, v: jax.Array, gustiness: float) -> jax.Array:
    """Effective surface wind with a sub-grid convective gustiness floor.

    ``|U|_eff = sqrt(u^2 + v^2 + u_gust^2)``.  The resolved grid-mean wind misses
    sub-grid wind variability — boundary-layer convective gustiness — which in
    calm/convective regions (the tropics, where the mean wind is light but deep
    convection drives gusts) is the dominant contributor to the air-sea latent
    and sensible flux.  Omitting it (or using a ~1 m/s numerical floor) yields
    ~1/3 of the realistic surface evaporation at light winds, starving the
    hydrological cycle (measured: coupled hfls ~35 vs ~80 W/m^2 at a 1.9 m/s
    mean surface wind).  Same algebraic form as the numerical wind floor
    ``sqrt(u^2+v^2+U_min^2)`` — a larger, physically-motivated ``u_gust``
    subsumes it.

    The floor lives INSIDE the single ``sqrt`` (not a two-stage
    ``sqrt(sqrt(u^2+v^2)^2 + g^2)``): with ``gustiness > 0`` the argument is
    strictly positive everywhere, so the gradient is finite even at exact calm
    wind ``u = v = 0`` (a bare ``sqrt(u^2+v^2)`` would give a NaN gradient
    there).  AD-safe for the differentiable coupler.

    Parameters
    ----------
    u, v : array
        Resolved grid-mean surface wind components [m/s].  A caller holding only
        the wind SPEED magnitude ``s`` passes ``apply_gustiness(s, 0.0, gust)``
        (``sqrt(s^2 + gust^2)``), which is equally AD-safe.
    gustiness : float
        Gustiness floor ``u_gust`` [m/s] (~5 m/s, Wing 2018 RCEMIP1).

    Returns
    -------
    array
        Effective wind speed for the bulk flux [m/s].

    References
    ----------
    - Beljaars (1995), QJRMS 121, 255-270 — convective gustiness in bulk fluxes.
    - Wing et al. (2018), GMD 11, 793-813 — RCEMIP1 5 m/s gustiness floor.
    """
    return jnp.sqrt(u ** 2 + v ** 2 + gustiness ** 2)


# Floors for the neutral log-law drag. _LN_RATIO_FLOOR is the same 0.5 the
# iterative solver applies to its own denominator (``_denom_floor`` in
# compute_most_fluxes), so the neutral limit is bounded exactly as the in-loop
# form is; _Z0_FLOOR_M matches the roughness floor used there.
_LN_RATIO_FLOOR = 0.5
_Z0_FLOOR_M = 1.0e-12


def neutral_drag_coefficient(z_ref, z0):
    """Neutral-limit bulk drag coefficient ``Cd = (kappa / ln(z_ref/z0))^2``.

    The canonical home for the neutral log-law drag, so a single-column model,
    the global model and the CRM cannot each grow their own copy. It is the
    zero-stability limit of the profile this module already integrates: with
    ``psi_m = 0`` the iterative solver's ``u* = kappa*U/ln(z_ref/z0)``
    (the ``u_star`` initialisation below) is exactly ``sqrt(Cd)*U``.

    That in-loop expression is deliberately NOT rewritten in terms of this
    helper: ``kappa*U/ln`` and ``sqrt((kappa/ln)^2)*U`` are algebraically equal
    but not bit-identical, and that code path is shared by the ocean, sea-ice,
    land and coupler surface schemes. ``tests`` pins the two forms to agree.

    Parameters
    ----------
    z_ref : array or float
        Height at which the wind is evaluated [m]. Use the height of the model
        level whose wind is actually passed to the flux routine, not a nominal
        10 m, or the drag will be inconsistent with that wind.
    z0 : array or float
        Aerodynamic roughness length [m].

    Returns
    -------
    array
        Neutral drag coefficient [-].
    """
    z_ref = jnp.asarray(z_ref)
    z0 = jnp.asarray(z0, dtype=z_ref.dtype)
    ln_ratio = jnp.log(z_ref / jnp.maximum(z0, _Z0_FLOOR_M))
    return (KAPPA / jnp.maximum(ln_ratio, _LN_RATIO_FLOOR)) ** 2


def validate_bulk_scheme(scheme: str) -> None:
    """Raise ``ValueError`` on an unknown bulk-flux scheme name.

    Every surface-flux dispatcher gates on ``bulk_scheme`` with
    ``if scheme in (<MOST schemes>): ... else: <constant>``.  Without this guard
    a *typo'd* scheme silently falls through to the constant-coefficient branch
    and runs the wrong air-sea physics (CLAUDE.md dispatch rule: factories must
    raise on unknown schemes).  ``scheme`` is a static Python string resolved at
    trace time, so this validates at function entry — never inside a traced /
    ``jit`` body.
    """
    if scheme not in _VALID_BULK_SCHEMES:
        raise ValueError(
            f"Unknown bulk_scheme {scheme!r}; expected one of "
            f"{_VALID_BULK_SCHEMES}."
        )


def validate_stability_scheme(stability_scheme: str) -> None:
    """Raise ``ValueError`` on an unknown stable-regime stability scheme.

    ``stability_scheme`` selects the STABLE-branch (zeta > 0) ``psi_m``/``psi_h``
    forms; it is a static Python string resolved at trace time, so this validates
    at function entry -- never inside a traced / ``jit`` body. Dispatch-hardening
    (CLAUDE.md): a typo'd name must fail LOUDLY rather than silently fall through
    to a default branch and run the wrong surface-layer physics.
    """
    if stability_scheme not in _VALID_STABILITY_SCHEMES:
        raise ValueError(
            f"Unknown stability_scheme {stability_scheme!r}; expected one of "
            f"{_VALID_STABILITY_SCHEMES}."
        )


def _ly09_cdn_poly(w):
    """LY09 Eq. 6 neutral drag polynomial ``1e3 * C_DN`` (no floor, clip or plateau);
    the one copy every non-source-exact Large-Yeager drag branch evaluates (#2242)."""
    w6 = w * w * w
    w6 = w6 * w6
    return 2.7 / w + 0.142 + w / 13.09 - 3.14807e-10 * w6


def large_yeager_neutral_cd(
    wind, *, nemo_parity: bool = False, nemo_source_exact: bool = False,
    cd_cutoff_width: float | None = None,
):
    """Large & Yeager (2009) Eq. 6 neutral 10-m drag coefficient ``C_DN``.

    .. math::
        C_{DN} = \\left(\\frac{2.7}{U} + 0.142 + \\frac{U}{13.09}
                  - 3.14807\\times10^{-10}\\,U^{6}\\right)\\times10^{-3}

    Default (``nemo_parity=False``, the MOST-solver convention): clipped to
    ``[0.5e-3, 3.0e-3]``.  The ``-3.14807e-10·U⁶`` high-wind term is LY09's
    correction over LY04 (which over-estimated drag at ``U > 30 m/s``) and is
    REQUIRED by the OMIP-2 protocol (Griffies 2016 §2.2).  ``wind`` is the
    10-m wind speed [m/s]; floored to 0.5 to avoid the ``1/U`` blow-up at calm
    winds.  The canonical drag law shared by the MOST flux solver and the OMIP-2
    air-sea bulk formulas (no per-component re-derivation).

    ``nemo_parity=True`` reproduces NEMO/aerobulk ``cd_n10_ncar``
    (sbcblk_algo_ncar.F90) at ``cd_cutoff_width=0``: the same polynomial, but
    (a) a constant cyclone plateau ``2.34e-3`` for ``U >= 33 m/s`` instead of
    letting the ``U⁶`` term pull the polynomial down (RULE 5 default: blended
    into the plateau over [32.5, 33] m/s, KNOWN DIFFERENCE up to 7.2e-4
    relative at 32.9 m/s, #2241), and (b) ONLY the NEMO floor ``Cx_min = 1e-4`` —
    no upper clip, so the calm-wind ``2.7/U`` enhancement (up to ``5.54e-3``
    at the 0.5 m/s floor) is kept.  The two conventions differ only for
    ``U < ~0.97 m/s`` (where the 3.0e-3 clip binds) and ``U > 32.5 m/s``.

    ``nemo_parity=True`` applies NO wind floor: NEMO's ``cd_n10_ncar``
    (sbcblk_algo_ncar.F90:242-255) has none, and its caller ``turb_ncar``
    floors the argument itself -- ``MAX(0.5, U_zu)`` for the first guess
    (:115) and ``MAX(0.25, UN10)`` inside the iteration (:192).  Re-flooring
    at 0.5 here overrode the 0.25 neutral-wind floor on calm cells (tier-3
    ORCA1 audit BLK D1: Cd 86% off on 67 cells).  Callers passing
    ``nemo_parity=True`` MUST therefore supply a positive, already-floored
    wind (both ``ncar_transfer_coefficients`` call sites do).

    ``cd_cutoff_width`` (``nemo_parity=True`` only; ``None`` =
    ``NCAR_CD_CUTOFF_WIDTH``): RULE 5 width [m/s] of the one-sided quintic
    blend into the 33 m/s plateau, shared with :func:`_cd_n10_ncar` (#2241);
    ``0.0`` is NEMO's hard switch.  ``nemo_source_exact=True`` keeps the hard
    switch: that branch exists to reproduce NEMO's rounding bit for bit.
    """
    if nemo_source_exact:
        if not nemo_parity:
            raise ValueError("nemo_source_exact requires nemo_parity=True")
        from legoesm.core.source_rounding import (
            nemo_fortran_sign as fortran_sign,
            nemo_source_barrier as B,
            nemo_source_round as R,
        )

        U = jnp.asarray(wind)
        U3 = R(U * U * U)
        U6 = R(U3 * U3)
        inverse_wind = R(2.7 / U)
        linear_wind = R(U / B(13.09))
        high_wind = R(3.14807e-10 * U6)
        low = R(R(R(inverse_wind + 0.142) + linear_wind) - high_wind)
        gt33 = R(0.5 + fortran_sign(0.5, R(U - 33.0)))
        below = R(R(1.0 - gt33) * low)
        above = R(gt33 * 2.34)
        C_DN = R(1.0e-3 * R(below + above))
        return R(jnp.maximum(C_DN, 0.1e-3))

    U = jnp.asarray(wind)
    if nemo_parity:
        return _cd_n10_ncar(
            U, NCAR_CD_CUTOFF_WIDTH if cd_cutoff_width is None else cd_cutoff_width)
    return jnp.clip(1e-3 * _ly09_cdn_poly(jnp.maximum(U, 0.5)), 0.5e-3, 3.0e-3)


# ============================================================================
# Stability functions (Businger-Dyer unstable; selectable stable regime)
# ============================================================================
# Convention: zeta = z/L is the Monin-Obukhov stability parameter (L the Obukhov
# length); zeta < 0 unstable, zeta > 0 stable. Every psi satisfies psi(0) = 0
# and, in the stable regime, decreases monotonically (more negative) with
# increasing zeta -- a more-stable column raises the log-law denominator
# ``ln(z/z0) - psi`` and thereby REDUCES the drag/exchange coefficient and the
# surface fluxes (the physically-required stable-regime suppression).
#
# The private ``_<scheme>_psi_{m,h}`` helpers below evaluate ONLY the stable
# branch and are always called with ``zeta_pos >= 0`` (``max(zeta, 0)`` in
# :func:`psi_m` / :func:`psi_h`), where every fractional power / log / cbrt
# argument is >= 1. Together with the ``jnp.where`` split this
# keeps the masked (inactive) branch finite in BOTH value and gradient -- the
# classic AD-safe double-branch construction.


def _gryanik_psi_m(zeta_pos):
    """Gryanik et al. (2020) stable momentum psi_m(zeta), zeta = zeta_pos > 0."""
    a_m, b_m = _GRYANIK_A_M, _GRYANIK_B_M
    return -3.0 * (a_m / b_m) * (jnp.cbrt(1.0 + b_m * zeta_pos) - 1.0)


def _gryanik_psi_h(zeta_pos):
    """Gryanik et al. (2020) stable heat psi_h(zeta), zeta > 0."""
    a_h, b_h = _GRYANIK_A_H, _GRYANIK_B_H
    return -_GRYANIK_PR0 * (a_h / b_h) * jnp.log1p(b_h * zeta_pos)


def _beljaars_holtslag_psi_m(zeta_pos):
    """Beljaars & Holtslag (1991) stable momentum psi_m(zeta), zeta > 0."""
    a, b, c, d = _BH91_A, _BH91_B, _BH91_C, _BH91_D
    return -(
        a * zeta_pos
        + b * (zeta_pos - c / d) * jnp.exp(-d * zeta_pos)
        + b * c / d
    )


def _beljaars_holtslag_psi_h(zeta_pos):
    """Beljaars & Holtslag (1991) stable heat psi_h(zeta), zeta > 0."""
    a, b, c, d = _BH91_A, _BH91_B, _BH91_C, _BH91_D
    # Clamp the ^{3/2} base to a positive floor BEFORE the power (AD-safety):
    # in-domain (zeta > 0) the base 1 + 2a*zeta/3 >= 1 so the floor is inert.
    base = jnp.maximum(1.0 + (2.0 / 3.0) * a * zeta_pos, _BH91_PSIH_BASE_FLOOR)
    return -(
        base ** 1.5
        + b * (zeta_pos - c / d) * jnp.exp(-d * zeta_pos)
        + b * c / d
        - 1.0
    )


def _grachev_psi_m(zeta_pos):
    """Grachev et al. (2007) SHEBA stable momentum psi_m(zeta), zeta > 0 (Eq. 12)."""
    a_m, b_m = _GRACHEV_A_M, _GRACHEV_B_M
    # Compile-time scalar constants via ``math`` (weakly-typed Python floats, so
    # they never promote the traced float32 ``zeta_pos`` state to float64).
    B_m = (1.0 / b_m - 1.0) ** (1.0 / 3.0)
    sqrt3 = math.sqrt(3.0)
    one_plus_Bm = 1.0 + B_m
    quad_den = 1.0 - B_m + B_m * B_m
    atan_ref = math.atan((2.0 - B_m) / (sqrt3 * B_m))
    x = jnp.cbrt(1.0 + zeta_pos)  # (1 + zeta)^{1/3}
    linear = -3.0 * (a_m / b_m) * (x - 1.0)
    log_1 = 2.0 * jnp.log((x + B_m) / one_plus_Bm)
    log_2 = -jnp.log((x * x - x * B_m + B_m * B_m) / quad_den)
    atan_1 = jnp.arctan((2.0 * x - B_m) / (sqrt3 * B_m))
    bracket = log_1 + log_2 + 2.0 * sqrt3 * (atan_1 - atan_ref)
    return linear + (a_m * B_m) / (2.0 * b_m) * bracket


def _grachev_psi_h(zeta_pos):
    """Grachev et al. (2007) SHEBA stable heat psi_h(zeta), zeta > 0 (Eq. 13)."""
    a_h, b_h, c_h = _GRACHEV_A_H, _GRACHEV_B_H, _GRACHEV_C_H
    B_h = math.sqrt(c_h * c_h - 4.0)  # = sqrt(5); compile-time constant
    coeff = a_h / B_h - (b_h * c_h) / (2.0 * B_h)
    log_ref = math.log((c_h - B_h) / (c_h + B_h))
    fractional_logs = jnp.log(
        (2.0 * zeta_pos + c_h - B_h) / (2.0 * zeta_pos + c_h + B_h)
    ) - log_ref
    quadratic_log = (b_h / 2.0) * jnp.log1p(c_h * zeta_pos + zeta_pos * zeta_pos)
    return _GRACHEV_PR0 * (-coeff * fractional_logs - quadratic_log)


def _stable_psi_m(zeta_pos, stability_scheme, stable_beta=_DYER_STABLE_BETA):
    """Stable-branch (zeta > 0) psi_m for ``stability_scheme``.

    The SINGLE dispatch for the selectable stable momentum similarity
    function, consumed by :func:`psi_m` (Businger-Dyer unstable side) AND by
    :func:`psi_m_coare` (COARE unstable side, non-default schemes only) so
    the published fits are never duplicated.  ``stable_beta`` acts only on
    the linear ``dyer1974`` form.  Unknown scheme -> ``ValueError`` (dispatch
    hardening; static Python string, raises at trace time).
    """
    if stability_scheme == "dyer1974":
        return -stable_beta * zeta_pos
    elif stability_scheme == "beljaars_holtslag1991":
        return _beljaars_holtslag_psi_m(zeta_pos)
    elif stability_scheme == "grachev2007_sheba":
        return _grachev_psi_m(zeta_pos)
    elif stability_scheme == "gryanik2020":
        return _gryanik_psi_m(zeta_pos)
    raise ValueError(
        f"Unknown stability_scheme {stability_scheme!r}; expected one of "
        f"{_VALID_STABILITY_SCHEMES}."
    )


def _stable_psi_h(zeta_pos, stability_scheme, stable_beta=_DYER_STABLE_BETA):
    """Stable-branch (zeta > 0) psi_h for ``stability_scheme``.

    Heat/moisture twin of :func:`_stable_psi_m` (same dispatch contract).
    """
    if stability_scheme == "dyer1974":
        return -stable_beta * zeta_pos
    elif stability_scheme == "beljaars_holtslag1991":
        return _beljaars_holtslag_psi_h(zeta_pos)
    elif stability_scheme == "grachev2007_sheba":
        return _grachev_psi_h(zeta_pos)
    elif stability_scheme == "gryanik2020":
        return _gryanik_psi_h(zeta_pos)
    raise ValueError(
        f"Unknown stability_scheme {stability_scheme!r}; expected one of "
        f"{_VALID_STABILITY_SCHEMES}."
    )


def psi_m(zeta, stability_scheme="dyer1974", *,
          unstable_gamma=_DYER_UNSTABLE_GAMMA,
          stable_beta=_DYER_STABLE_BETA,
          nemo_source_exact: bool = False):
    """MOST momentum stability function psi_m(zeta).

    Convention zeta = z/L (>0 stable). Unstable (zeta < 0) is Businger-Dyer for
    every scheme:
        psi_m = 2 ln((1+x)/2) + ln((1+x^2)/2) - 2 arctan(x) + pi/2,
        with x = (1 - gamma zeta)^{1/4}, gamma = ``unstable_gamma`` (default 16).
    Stable (zeta > 0) is selected by ``stability_scheme``:

    - ``"dyer1974"``             : psi_m = -beta zeta (default; historical linear
      form with beta = ``stable_beta``, default 5)
    - ``"beljaars_holtslag1991"``: Beljaars & Holtslag (1991)
    - ``"grachev2007_sheba"``    : Grachev et al. (2007) SHEBA (Arctic/strong-stable)
    - ``"gryanik2020"``          : Gryanik et al. (2020) modified SHEBA

    ``unstable_gamma`` / ``stable_beta`` are the trainable Businger-Dyer
    coefficients (Businger et al. 1971 / Dyer 1974). They act ONLY when
    ``stability_scheme="dyer1974"`` (unstable gamma for zeta < 0, stable beta for
    zeta > 0). For the beljaars/grachev/gryanik schemes BOTH the stable form
    (their own published fit) AND the unstable branch (kept at the historical
    gamma = 16) are UNAFFECTED. Both default to the module constants so every
    existing caller is byte-identical.

    Branch construction as CliMA SurfaceFluxes.jl: the unstable expression is
    evaluated on ``min(zeta, 0)`` and the stable one on ``max(zeta, 0)`` (both
    finite, with finite gradients, at 0); the stable form is selected for
    ``zeta > 0`` (SurfaceFluxes v0.12 Beljaars / v1.5.1 Gryanik), so psi(0) is
    the unstable form's exact 0.
    """
    validate_stability_scheme(stability_scheme)
    if nemo_source_exact:
        if stability_scheme != "dyer1974":
            raise ValueError(
                "nemo_source_exact supports stability_scheme='dyer1974' only"
            )
        from legoesm.core import transcendentals as tx
        from legoesm.core.source_rounding import (
            nemo_fortran_sign as fortran_sign,
            nemo_source_round as R,
        )

        z = jnp.asarray(zeta, dtype=jnp.float64)
        x2 = R(jnp.sqrt(jnp.abs(1.0 - 16.0 * z)))
        x2 = R(jnp.maximum(x2, 1.0))
        x = R(jnp.sqrt(x2))
        unstable = R(
            2.0 * tx.log((1.0 + x) * 0.5)
            + tx.log((1.0 + x2) * 0.5)
            - 2.0 * tx.atan(x) + jnp.pi * 0.5
        )
        stable_value = R(-5.0 * z)
        stable = R(0.5 + fortran_sign(0.5, z))
        return R(stable * stable_value + (1.0 - stable) * unstable)
    zeta_c = jnp.clip(zeta, -10.0, 10.0)
    # Safe inputs: each branch only sees valid arguments
    # where (not min/max): at zeta = 0 the selected (unstable) branch gets the
    # full derivative instead of half of it at a min/max tie.
    zeta_neg = jnp.where(zeta_c > 0.0, 0.0, zeta_c)
    zeta_pos = jnp.where(zeta_c > 0.0, zeta_c, 0.0)

    # The trainable ``unstable_gamma`` reparameterises the Businger-Dyer UNSTABLE
    # branch ONLY for ``dyer1974`` (the scheme whose stable branch it is paired
    # with).  The beljaars/grachev/gryanik schemes keep the historical
    # gamma = 16 unstable branch (their PUBLISHED fits assume it), so a tuned
    # gamma does not silently perturb their unstable side.  Static Python select
    # on the (compile-time) scheme string -> no traced branch.
    _gamma = unstable_gamma if stability_scheme == "dyer1974" else _DYER_UNSTABLE_GAMMA
    x = jnp.power(1.0 - _gamma * zeta_neg, 0.25)
    unstable = (
        2.0 * jnp.log((1.0 + x) / 2.0)
        + jnp.log((1.0 + x ** 2) / 2.0)
        - 2.0 * jnp.arctan(x)
        + jnp.pi / 2.0
    )

    # Stable branch: static ``stability_scheme`` -> Python dispatch (only the
    # selected expression is traced), not ``jnp.where`` (which would trace all).
    stable = _stable_psi_m(zeta_pos, stability_scheme, stable_beta)

    return jnp.where(zeta_c > 0.0, stable, unstable)


def psi_h(zeta, stability_scheme="dyer1974", *,
          unstable_gamma=_DYER_UNSTABLE_GAMMA,
          stable_beta=_DYER_STABLE_BETA,
          nemo_source_exact: bool = False):
    """MOST heat/moisture stability function psi_h(zeta).

    Convention zeta = z/L (>0 stable). Unstable (zeta < 0) is Businger-Dyer for
    every scheme:
        psi_h = 2 ln((1+y)/2),  y = (1 - gamma zeta)^{1/2},
        gamma = ``unstable_gamma`` (default 16).
    Stable (zeta > 0) is selected by ``stability_scheme`` (same options as
    :func:`psi_m`; ``"dyer1974"`` default reproduces the historical
    -``stable_beta`` zeta with beta = 5). ``unstable_gamma`` / ``stable_beta``
    (Businger-Dyer / Dyer 1974 coefficients) act ONLY when
    ``stability_scheme="dyer1974"`` (both branches); the beljaars/grachev/gryanik
    schemes keep their own published stable fits AND the historical gamma = 16
    unstable branch. Both default to the module constants (byte-identical).
    For ``"gryanik2020"`` the unstable branch is multiplied by Pr0 = 0.98, as in
    SurfaceFluxes.jl v1.5.1 (oracle: tests/core/test_surfacefluxes_psi_oracle.py).
    """
    validate_stability_scheme(stability_scheme)
    if nemo_source_exact:
        if stability_scheme != "dyer1974":
            raise ValueError(
                "nemo_source_exact supports stability_scheme='dyer1974' only"
            )
        from legoesm.core import transcendentals as tx
        from legoesm.core.source_rounding import (
            nemo_fortran_sign as fortran_sign,
            nemo_source_round as R,
        )

        z = jnp.asarray(zeta, dtype=jnp.float64)
        x2 = R(jnp.sqrt(jnp.abs(1.0 - 16.0 * z)))
        x2 = R(jnp.maximum(x2, 1.0))
        unstable = R(2.0 * tx.log(0.5 * (1.0 + x2)))
        stable_value = R(-5.0 * z)
        stable = R(0.5 + fortran_sign(0.5, z))
        return R(stable * stable_value + (1.0 - stable) * unstable)
    zeta_c = jnp.clip(zeta, -10.0, 10.0)
    # where (not min/max): at zeta = 0 the selected (unstable) branch gets the
    # full derivative instead of half of it at a min/max tie.
    zeta_neg = jnp.where(zeta_c > 0.0, 0.0, zeta_c)
    zeta_pos = jnp.where(zeta_c > 0.0, zeta_c, 0.0)

    # See psi_m: the trainable unstable gamma applies ONLY to dyer1974; the
    # non-linear stable schemes keep the historical gamma = 16 unstable branch.
    _gamma = unstable_gamma if stability_scheme == "dyer1974" else _DYER_UNSTABLE_GAMMA
    y = jnp.sqrt(1.0 - _gamma * zeta_neg)
    unstable = 2.0 * jnp.log((1.0 + y) / 2.0)
    if stability_scheme == "gryanik2020":
        # SurfaceFluxes.jl v1.5.1 GryanikParams psi_h: the Businger fallback is
        # scaled by Pr_0, consistent with the stable branch's phi_h(0) = Pr_0.
        unstable = _GRYANIK_PR0 * unstable

    stable = _stable_psi_h(zeta_pos, stability_scheme, stable_beta)

    return jnp.where(zeta_c > 0.0, stable, unstable)


def _f32(x):
    """Value of the Fortran default-real (single-precision) literal ``x``.

    AeroBulk writes most of its constants as default-real literals that are
    assigned to, or combined with, REAL(wp) = fp64 variables, so the numbers it
    actually computes with are the fp32 roundings promoted to fp64.  The port
    uses the same numbers.
    """
    return float(np.float32(x))


# ============================================================================
# AeroBulk 1.0.0 (Brodeau; github.com/brodeau/aerobulk tag 1.0.0,
# SHA ca40928872eb9c00f96a51cf3a6eed0bb4a70580) — the COARE 3.0 oracle.
# Every value below is the number AeroBulk computes with (``_f32`` = an
# AeroBulk default-real literal), each under the routine it comes from.
# ============================================================================
# --- mod_const (grav and R_vap carry legoESM's values, as the tier-2 oracle
# audit built AeroBulk; AeroBulk keeps them as default-real literals) ---
_AB_GRAV = _f32(constants.g)
_AB_RCTV0 = _f32(constants.R_v) / _f32(constants.R_d) - 1.0   # rctv0 = R_vap/R_dry - 1
_AB_RT0 = _f32(constants.T_freeze)                             # rt0 (visc_air C<->K)
_AB_RCP_DRY = 1005.0  # const-ok: AeroBulk mod_const rCp_dry (Ri_bulk lapse rate only)
_AB_RGAMMA_DRY = _AB_GRAV / _AB_RCP_DRY                        # rgamma_dry
_AB_CX_MIN = 0.1e-3                                            # Cx_min
# --- mod_phymbl One_on_L / visc_air (Andreas 1989 fit) ---
_AB_ONE_ON_L_MAX = 200.0
_AB_ONE_ON_L_DEN_MIN = 1.0e-9
_AB_VISC_A = _f32(1.326e-5)
_AB_VISC_B = _f32(6.542e-3)
_AB_VISC_C = _f32(8.301e-6)
_AB_VISC_D = _f32(4.84e-9)
# --- mod_common_coare psi_m_coare / psi_h_coare (Fairall et al. 1996, 2003) ---
_AB_PSI_KANSAS = 15.0
_AB_PSI_CONV_M = _f32(10.15)
_AB_PSI_CONV_H = _f32(34.15)
_AB_PSI_CONV_EXP = _f32(0.3333)
_AB_SQRT3 = _f32(1.7320508)
_AB_PI_O_SQRT3 = _f32(1.813799447)
_AB_PSI_STB_B = _f32(0.6667)
_AB_PSI_STB_C = _f32(14.28)
_AB_PSI_STB_D = _f32(8.525)
_AB_PSI_STB_RATE = 0.35
_AB_PSI_STB_EXP_MAX = 50.0
# --- mod_common_coare FIRST_GUESS_COARE ---
_AB_FG_Z0 = _f32(1.0e-4)          # "rough" first-guess roughness length [m]
_AB_FG_CA = 0.035
_AB_FG_ZI0 = 600.0
_AB_FG_BETA0 = 1.2
_AB_FG_CB = 0.004 * _AB_FG_ZI0 * _AB_FG_BETA0 * _AB_FG_BETA0 * _AB_FG_BETA0
_AB_FG_GUST = 0.5                 # first-guess gustiness [m/s]
_AB_FG_CH10 = _f32(0.00115)       # neutral 10 m Stanton number for z0t
_AB_FG_Z_MIN = _f32(1.0e-8)       # first-guess z0 / z0t floor [m]
_AB_FG_RIB_STB = 27.0 / 9.0
_AB_T_MIN = 180.0                 # t_zu = MAX(t_zt, 180)
_AB_Q_MIN = 1.0e-6                # q_zu = MAX(q_zt, 1e-6)
_AB_DT_MIN = 1.0e-6               # |t_zu - T_s| floor
_AB_DQ_MIN = 1.0e-9               # |q_zu - q_s| floor
# --- mod_blk_coare3p0 TURB_COARE3P0 ---
_AB_COARE_ZETA_ABS_MAX = 50.0
_AB_COARE_Z_MIN = _f32(1.0e-9)    # z0 / z0t floor [m]
_AB_COARE_USTAR_MIN = _f32(1.0e-9)
_AB_COARE_Z0T_MAX = 1.1e-4        # Fairall et al. (2003) eq. 28 cap
_AB_COARE_Z0T_COEF = 5.5e-5
_AB_COARE_Z0T_EXP = 0.6
_AB_COARE_SMOOTH = 0.11           # smooth-flow roughness coefficient
_AB_EQUAL_HEIGHT_TOL = 0.01       # l_zt_equal_zu = |zu - zt| < 0.01 m
# RULE 5 smooth default (user decision 2026-10-28, form N6): half-width of the
# compact quintic blend across zeta = 0 in psi_m_coare / psi_h_coare; 0.0 = the
# oracle's hard SIGN switch.
COARE_NEUTRAL_WIDTH = 1.0e-3
# RULE 5 smooth defaults (#2241; form and value decided by codex and GLM
# separately, same answers); 0.0 = the oracle's hard switch in each case.
# Charnock wind ramp: width [m/s] of the C1 rounding inside each corner of the
# 10 -> 18 m/s ramp (exact outside [10, 10 + w] and [18 - w, 18]).
COARE_CHARNOCK_RAMP_WIDTH = 0.5
# Convective-gustiness onset: width [1] in x = max(-zi/(kappa L), 0) over which
# x**(2/3) is ramped on by a quintic smoothstep (exact for x >= w).
COARE_GUST_ONSET_WIDTH = 1.0e-2


def _psi_coare_unstable(zn, conv, kansas):
    """Fairall Kansas + free-convective blend (AeroBulk psi_*_coare, zeta < 0)."""
    phi_c = jnp.abs(1.0 - conv * zn) ** _AB_PSI_CONV_EXP
    psi_c = (1.5 * jnp.log((1.0 + phi_c + phi_c * phi_c) / 3.0)
             - _AB_SQRT3 * jnp.arctan((1.0 + 2.0 * phi_c) / _AB_SQRT3) + _AB_PI_O_SQRT3)
    zf = zn * zn
    zf = zf / (1.0 + zf)
    return (1.0 - zf) * kansas + zf * psi_c


def _coare_neutral_select(zeta, neutral_width, stable_fn, unstable_fn):
    """Neutral switch of AeroBulk's psi_*_coare.

    ``neutral_width == 0``: the oracle's hard ``0.5 + SIGN(0.5, zeta)`` switch
    (+0 stable, -0 unstable), branch arguments valid on both sides.
    ``neutral_width = w > 0`` (RULE 5 smooth default, user decision N6): compact
    quintic smootherstep ``s = smoothstep_quintic((zeta + w) / (2 w))``,
    ``s * stable(max(zeta, -w)) + (1 - s) * unstable(min(zeta, w))`` (static
    Python float width).  Inside ``|zeta| < w`` both branches are evaluated at
    the true zeta; outside it ``s`` is exactly 0 or 1, so exactly one branch
    contributes and the result is the oracle's.  The blend is C2 in zeta
    (C-infinity inside the band), removing the 0.0045 jump AeroBulk's rounded
    constants leave at zeta = 0.

    KNOWN DIFFERENCE at the default width 1e-3, vs the compiled AeroBulk
    TURB_COARE3P0 (fixture of 1549 states, Charnock 0.011): the fluxes differ by
    up to 8.0e-4 relative in stress, 5.0e-4 in sensible and latent heat and
    4.0e-4 in u* at 10 m (6.8e-4 / 4.6e-4 / 3.4e-4 at 2 m).  The blend alone
    (fp32 Charnock) moves 39 of 1549 states by more than 1e-9 at 10 m and 190
    at 2 m; the fp64 Charnock adds a gap of at most ~1e-9 relative in stress
    (per-state in ``aerobulk_coare3p0_charnock0p011_width0_gap.npz``).
    Measured 2026-10-28 after the switch from the logistic blend, whose stress
    gap was 1.2e-3 and which was not C1 at zeta = 0.  Per-state gaps in
    ``tests/core/oracle_fixtures/aerobulk_coare3p0_default_gap.npz`` (since
    #2241 that file is the gap at ALL coare3 defaults, incl. the Charnock-ramp
    and gust-onset smoothing; see :func:`compute_most_fluxes`).  Width 0
    recovers the oracle (<= 1e-10).
    """
    if neutral_width == 0.0:
        stable = ~jnp.signbit(zeta)   # 0.5 + SIGN(0.5, zeta): +0 stable, -0 unstable
        return jnp.where(stable, stable_fn(jnp.where(stable, zeta, 0.0)),
                         unstable_fn(jnp.where(stable, -1.0, zeta)))
    if not neutral_width > 0.0:
        raise ValueError(f"neutral_width must be >= 0, got {neutral_width!r}")
    wt = smoothstep_quintic((zeta + neutral_width) / (2.0 * neutral_width))
    return (wt * stable_fn(jnp.maximum(zeta, -neutral_width))
            + (1.0 - wt) * unstable_fn(jnp.minimum(zeta, neutral_width)))


def psi_m_coare(zeta, stability_scheme="dyer1974", neutral_width=COARE_NEUTRAL_WIDTH):
    """COARE 3.0 momentum stability function, AeroBulk 1.0.0 ``psi_m_coare``.

    Faithful port of mod_common_coare.f90 ``psi_m_coare_sclr`` (Fairall et al.
    1996, 2003), including AeroBulk's single-precision literals (0.3333,
    10.15, 1.7320508, 1.813799447, 0.6667, 14.28, 8.525):

    * unstable (zeta < 0): Kansas ``x = |1 - 15 zeta|^0.25`` blended with the
      free-convective ``y = |1 - 10.15 zeta|^0.3333`` by
      ``f = zeta^2/(1 + zeta^2)``;
    * stable (zeta >= 0, AeroBulk's ``0.5 + SIGN(0.5, zeta)`` puts zeta = 0 on
      this side): ``-(1 + zeta + 0.6667 (zeta - 14.28)/exp(min(50, 0.35 zeta))
      + 8.525)``.

    No clip on zeta (the solver clips it at +-50, as AeroBulk does).

    ``stability_scheme`` swaps ONLY the stable branch: ``"dyer1974"`` (the
    config default) is the sentinel for the AeroBulk native form above;
    ``"beljaars_holtslag1991"`` / ``"grachev2007_sheba"`` / ``"gryanik2020"``
    use those published stable fits (legoESM options; AeroBulk has no such
    switch).  The two branches are selected with ``jnp.where`` on arguments
    that are valid on both sides, so the inactive branch never feeds a NaN into
    the value or the gradient.

    ``neutral_width`` (default ``COARE_NEUTRAL_WIDTH`` = 1e-3, RULE 5): the
    SIGN switch above is replaced by the compact quintic blend of
    :func:`_coare_neutral_select`; ``neutral_width = 0`` is the faithful
    AeroBulk form described here.  Same parameter on :func:`psi_h_coare`.
    """
    validate_stability_scheme(stability_scheme)

    def unstable(zn):
        x = jnp.abs(1.0 - _AB_PSI_KANSAS * zn) ** 0.25
        psi_k = (2.0 * jnp.log((1.0 + x) / 2.0) + jnp.log((1.0 + x * x) / 2.0)
                 - 2.0 * jnp.arctan(x) + 0.5 * jnp.pi)
        return _psi_coare_unstable(zn, _AB_PSI_CONV_M, psi_k)

    def stable(zp):
        if stability_scheme != "dyer1974":
            return _stable_psi_m(zp, stability_scheme)
        zc = jnp.minimum(_AB_PSI_STB_EXP_MAX, _AB_PSI_STB_RATE * zp)
        return -(1.0 + 1.0 * zp + _AB_PSI_STB_B * (zp - _AB_PSI_STB_C) / jnp.exp(zc)
                 + _AB_PSI_STB_D)

    return _coare_neutral_select(jnp.asarray(zeta), neutral_width, stable, unstable)


def psi_h_coare(zeta, stability_scheme="dyer1974", neutral_width=COARE_NEUTRAL_WIDTH):
    """COARE 3.0 heat/moisture stability function, AeroBulk 1.0.0 ``psi_h_coare``.

    Faithful port of mod_common_coare.f90 ``psi_h_coare_sclr``: unstable =
    Kansas ``2 ln((1 + |1 - 15 zeta|^0.5)/2)`` blended with the free-convective
    form (``y = |1 - 34.15 zeta|^0.3333``); stable (zeta >= 0) =
    ``-(|1 + 2 zeta/3|^1.5 + 0.6667 (zeta - 14.28)/exp(min(50, 0.35 zeta))
    + 8.525)``.  ``stability_scheme`` semantics as in :func:`psi_m_coare`.
    """
    validate_stability_scheme(stability_scheme)

    def unstable(zn):
        x = jnp.abs(1.0 - _AB_PSI_KANSAS * zn) ** 0.5
        return _psi_coare_unstable(zn, _AB_PSI_CONV_H, 2.0 * jnp.log((1.0 + x) / 2.0))

    def stable(zp):
        if stability_scheme != "dyer1974":
            return _stable_psi_h(zp, stability_scheme)
        zc = jnp.minimum(_AB_PSI_STB_EXP_MAX, _AB_PSI_STB_RATE * zp)
        return -(jnp.abs(1.0 + 2.0 * zp / 3.0) ** 1.5
                 + _AB_PSI_STB_B * (zp - _AB_PSI_STB_C) / jnp.exp(zc) + _AB_PSI_STB_D)

    return _coare_neutral_select(jnp.asarray(zeta), neutral_width, stable, unstable)


# --- COARE 3.0 wind-dependent Charnock (AeroBulk charn_coare3p0; Hare et al.
# 1999 / Fairall et al. 2003 §3c): 0.011 below 10 m/s, linear to 0.018 at 18.
_COARE_CHARNOCK_U_LO = 10.0   # [m/s]
_COARE_CHARNOCK_U_HI = 18.0   # [m/s]
_COARE_CHARNOCK_HI = _f32(0.018)  # AeroBulk default-real literal 0.018

# --- Scheme-native gustiness / calm-wind conventions (AeroBulk) ---
# COARE 3.0 has convective gustiness BUILT IN (mod_blk_coare3p0: zi0 = 600 m,
# Beta0 = 1.25) plus a 0.2 m/s bulk-wind floor; LY09/NEMO ncar has NO
# gustiness but floors the bulk wind at 0.5 m/s.
_COARE_GUSTINESS_ZI = 600.0   # [m] aerobulk coare3p0 zi0 (BL scale height)
_COARE_UB_FLOOR = 0.2         # [m/s] aerobulk coare3p0 bulk-wind floor


def resolve_gustiness_w_zi(gustiness_w_zi, scheme) -> float:
    """The EFFECTIVE convective-gustiness BL depth z_i [m] for ``scheme``.

    ``None`` means scheme-native (AeroBulk/COARE parity): COARE 3.0 includes
    convective gustiness as part of the algorithm (zi = 600 m), the other
    schemes do not.  An explicit value (0.0 = off) overrides.  The SINGLE
    source for this resolution — used by :func:`compute_most_fluxes` itself
    and by the air-sea consistency guard, so "what does None mean" can never
    drift between the model and the validator.
    """
    if gustiness_w_zi is None:
        return _COARE_GUSTINESS_ZI if scheme == "coare3" else 0.0
    return float(gustiness_w_zi)


# ============================================================================
# AeroBulk 1.0.0 TURB_COARE3P0 (no cool-skin / warm-layer)
# ============================================================================

def _sign_floor(x, x_min):
    """Fortran ``SIGN(MAX(ABS(x), x_min), x)`` (gfortran: -0.0 counts negative).

    Kept hard as in AeroBulk (user decision 2026-10-31, #2241): it is the
    division guard of ``Ch = r*ts/dt`` / ``Ce = r*qs/dq`` in TURB_COARE3P0.
    KNOWN DIFFERENCE from RULE 5: a jump of ``2*x_min`` (2e-6 K in dt, 2e-9
    kg/kg in dq) where the air-sea difference crosses zero.  It flips the
    sign of theta* (q*) at that state, which changes 1/L by that scale's
    tiny buoyancy contribution; the derivative there is undefined.  Not a gap
    to the oracle (same form).
    """
    m = jnp.maximum(jnp.abs(x), x_min)
    return jnp.where(jnp.signbit(x), -m, m)


def _visc_air_aerobulk(T):
    """AeroBulk mod_phymbl ``visc_air`` (Andreas 1989): kinematic viscosity of
    air [m^2/s] at absolute temperature ``T`` [K]."""
    tc = T - _AB_RT0
    tc2 = tc * tc
    return _AB_VISC_A * (1.0 + _AB_VISC_B * tc + _AB_VISC_C * tc2 - _AB_VISC_D * tc2 * tc)


def _one_on_l_aerobulk(theta, q, u_star, theta_star, q_star):
    """AeroBulk mod_phymbl ``One_on_L``: 1/L [1/m] from the turbulent scales.

    ``theta_star``/``q_star`` follow AeroBulk's sign (positive DOWNWARD, i.e.
    ``kappa (t_zu - T_s)/denom``).  Includes AeroBulk's 1e-9 denominator floor
    and |1/L| <= 200 clip.
    """
    zqa = 1.0 + _AB_RCTV0 * q
    inv_L = (_AB_GRAV * KAPPA * (theta_star * zqa + _AB_RCTV0 * theta * q_star)
             / jnp.maximum(u_star * u_star * theta * zqa, _AB_ONE_ON_L_DEN_MIN))
    return jnp.clip(inv_L, -_AB_ONE_ON_L_MAX, _AB_ONE_ON_L_MAX)


def _ri_bulk_aerobulk(z, T_s, theta, q_s, q, Ub):
    """AeroBulk mod_phymbl ``Ri_bulk`` (no layer-temperature arguments)."""
    sstv = T_s * (1.0 + _AB_RCTV0 * q_s)
    dthv = theta * (1.0 + _AB_RCTV0 * q) - sstv
    tv = 0.5 * (sstv + (theta - _AB_RGAMMA_DRY * z) * (1.0 + _AB_RCTV0 * q))
    return _AB_GRAV * dthv * z / (tv * Ub * Ub)


def _coare3p0_charnock(wind, charnock, ramp_width=COARE_CHARNOCK_RAMP_WIDTH):
    """AeroBulk ``charn_coare3p0``: ``charnock`` below 10 m/s, linear to the
    0.018 high-wind value at 18 m/s.  With ``charnock`` = AeroBulk's literal
    0.011 and ``ramp_width = 0`` this is the oracle's function exactly; a larger
    ``charnock`` keeps the ramp monotone (high value ``max(0.018, charnock)``).

    RULE 5 (#2241): ``ramp_width = w > 0`` [m/s] rounds both corners C1 with
    ``1 - pp(1 - pp(t, s), s)`` (``pp`` = :func:`positive_part_c1`,
    ``t = (wind - 10)/8``, ``s = 8/w``): exact outside ``[10, 10 + w]`` and
    ``[18 - w, 18]``, monotone, never outside the ``[charnock, charnock_hi]``
    range (below the hard ramp inside the low band, above it inside the high
    band, by at most ``4 w/(27*8)`` of the ramp).  ``w = 0``: AeroBulk's
    ``clip``.
    """
    t = (wind - _COARE_CHARNOCK_U_LO) / (_COARE_CHARNOCK_U_HI - _COARE_CHARNOCK_U_LO)
    if ramp_width == 0.0:
        ramp = jnp.clip(t, 0.0, 1.0)
    else:
        s = (_COARE_CHARNOCK_U_HI - _COARE_CHARNOCK_U_LO) / ramp_width
        ramp = 1.0 - positive_part_c1(1.0 - positive_part_c1(t, s), s)
    charnock_hi = jnp.maximum(_COARE_CHARNOCK_HI, charnock)
    return charnock + ramp * (charnock_hi - charnock)


def _gust_factor(x, onset_width=COARE_GUST_ONSET_WIDTH):
    """Gustiness factor ``max(x, 0)**(2/3)`` of TURB_COARE3P0
    (``x = -zi/(kappa L)``).

    RULE 5 (#2241): ``onset_width = w > 0`` multiplies it by
    ``smoothstep_quintic(x/w)``: exactly 0 for ``x <= 0`` (as AeroBulk), exact
    for ``x >= w``, never above the hard factor, and C2 at ``x = 0`` where the
    hard ``x**(2/3)`` has an infinite slope.  ``w = 0``: AeroBulk's form.
    """
    xp = jnp.maximum(x, 0.0)
    g = _gust_power(xp)
    if onset_width == 0.0:
        return g
    return g * smoothstep_quintic(xp / onset_width)


def _gust_power(x):
    """``x**(2/3)`` for ``x >= 0`` with a finite gradient at ``x = 0`` (the value
    there is 0, as in AeroBulk; the inactive branch gets a dummy argument)."""
    pos = x > 0.0
    return jnp.where(pos, jnp.where(pos, x, 1.0) ** (2.0 / 3.0), 0.0)


def _same_static_height(a, b):
    """True when two heights are concrete (non-traced) and equal everywhere."""
    if isinstance(a, jax.core.Tracer) or isinstance(b, jax.core.Tracer):
        return False
    return bool(np.all(np.asarray(a) == np.asarray(b)))


def _safe_sqrt(x):
    """``sqrt(x)`` for ``x >= 0``; same value, gradient 0 instead of NaN at x = 0."""
    pos = x > 0.0
    return jnp.where(pos, jnp.sqrt(jnp.where(pos, x, 1.0)), 0.0)


def _first_guess_coare(W2, t_zt, q_zt, T_s, q_s, z_u, z_t, equal, charnock,
                       neutral_width, charnock_ramp_width=COARE_CHARNOCK_RAMP_WIDTH):
    """AeroBulk mod_common_coare ``FIRST_GUESS_COARE`` (bulk-Richardson seed)."""
    t_zu = jnp.maximum(t_zt, _AB_T_MIN)
    q_zu = jnp.maximum(q_zt, _AB_Q_MIN)
    log_zu = jnp.log(z_u)
    c_a = _AB_FG_CA * jnp.log(10.0 / _AB_FG_Z0) / jnp.log(z_u / _AB_FG_Z0)
    dt = _sign_floor(t_zu - T_s, _AB_DT_MIN)
    dq = _sign_floor(q_zu - q_s, _AB_DQ_MIN)
    nu = _visc_air_aerobulk(t_zu)
    Ub = jnp.sqrt(W2 + _AB_FG_GUST * _AB_FG_GUST)
    us = c_a * Ub
    ch = _coare3p0_charnock(_safe_sqrt(W2), charnock, charnock_ramp_width)
    z0 = jnp.clip(jnp.abs(ch * us * us / _AB_GRAV + _AB_COARE_SMOOTH * nu / us),
                  _AB_FG_Z_MIN, 1.0)
    log_z0 = jnp.log(z0)
    Cd = (KAPPA / (log_zu - log_z0)) ** 2
    z0t = 10.0 / jnp.exp(KAPPA / (_AB_FG_CH10 * ((jnp.log(10.0) - log_z0) / KAPPA)))
    z0t = jnp.clip(jnp.abs(z0t), _AB_FG_Z_MIN, 1.0)
    log_z0t = jnp.log(z0t)
    rib = _ri_bulk_aerobulk(z_u, T_s, t_zu, q_s, q_zu, Ub)
    cc_ri = KAPPA * KAPPA / (Cd * (jnp.log(z_t) - log_z0t)) * rib
    # 0.5 + SIGN(0.5, zRib).  Kept hard (#2241, codex+GLM): both branches are 0
    # with slope K = cc_ri/rib at rib = 0, so the seed is already C1 in rib;
    # only its second derivative jumps there.
    rib_stable = ~jnp.signbit(rib)
    den_unst = jnp.where(rib_stable, 1.0, 1.0 + rib * (-_AB_FG_CB / z_u))
    zeta_u = jnp.where(rib_stable, cc_ri + _AB_FG_RIB_STB * rib * rib, cc_ri / den_unst)
    us = jnp.maximum(Ub * KAPPA / (log_zu - log_z0 - psi_m_coare(zeta_u, neutral_width=neutral_width)),
                     _AB_COARE_USTAR_MIN)
    psih_u = psi_h_coare(zeta_u, neutral_width=neutral_width)
    tmp = KAPPA / (log_zu - log_z0t - psih_u)
    ts = dt * tmp
    qs = dq * tmp
    if equal is not True:
        zeta_t = z_t * zeta_u / z_u
        prf = jnp.log(z_t / z_u) + psih_u - psi_h_coare(zeta_t, neutral_width=neutral_width)
        t_new = t_zt - ts / KAPPA * prf
        q_new = q_zt - qs / KAPPA * prf
        q_new = jnp.where(q_new >= 0.0, q_new, 0.0)
        dt_new = _sign_floor(t_new - T_s, _AB_DT_MIN)
        dq_new = _sign_floor(q_new - q_s, _AB_DQ_MIN)
        t_zu = jnp.where(equal, t_zu, t_new)
        q_zu = jnp.where(equal, q_zu, q_new)
        dt = jnp.where(equal, dt, dt_new)
        dq = jnp.where(equal, dq, dq_new)
        ts = dt * tmp
        qs = dq * tmp
    z0 = jnp.clip(jnp.abs(ch * us * us / _AB_GRAV + _AB_COARE_SMOOTH * nu / us),
                  _AB_FG_Z_MIN, 1.0)
    return us, ts, qs, t_zu, q_zu, Ub, z0


def _turb_coare3p0(W2, t_zt, q_zt, T_s, q_s, z_u, z_t, equal, n_iter, charnock,
                   zi, beta, stability_scheme, denom_floor, neutral_width,
                   charnock_ramp_width=COARE_CHARNOCK_RAMP_WIDTH,
                   gust_onset_width=COARE_GUST_ONSET_WIDTH):
    """AeroBulk 1.0.0 ``TURB_COARE3P0`` (l_use_cs = l_use_wl = .false.).

    ``W2`` is the squared wind module ``U_zu**2``; ``equal`` is AeroBulk's
    ``l_zt_equal_zu`` (a Python bool, or a boolean array for per-column
    heights).  ``zi`` = 0 switches the gustiness off (gust^2 = 0 exactly);
    ``denom_floor`` (None = AeroBulk, no floor) is legoESM's optional
    ``max_exchange_coeff`` ceiling on the log-law denominators.

    Returns AeroBulk's outputs (Cd, Ch, Ce, t_zu, q_zu, Ub, u*) plus the
    internal state the legoESM diagnostics read (theta*, q* in AeroBulk's
    positive-downward sign, z0t, 1/L) and the last-iteration relative u* change.
    """
    log_zu = jnp.log(z_u)
    log_10 = jnp.log(10.0)
    us, ts, qs, t_zu, q_zu, Ub, z0 = _first_guess_coare(
        W2, t_zt, q_zt, T_s, q_s, z_u, z_t, equal, charnock, neutral_width,
        charnock_ramp_width)
    log_z0 = jnp.log(z0)
    nu = _visc_air_aerobulk(t_zu)
    dt = _sign_floor(t_zu - T_s, _AB_DT_MIN)
    dq = _sign_floor(q_zu - q_s, _AB_DQ_MIN)
    z0t = jnp.zeros_like(us)
    inv_L = jnp.zeros_like(us)
    resid = jnp.ones_like(us)
    if equal is not True:
        log_zt = jnp.log(z_t)

    def _floor(d):
        return d if denom_floor is None else jnp.maximum(d, denom_floor)

    def body(_, c):
        us, ts, qs, t_zu, q_zu, dt, dq, log_z0, _z0t, _Ub, _inv_L, _resid = c
        us2 = us * us
        inv_L = _one_on_l_aerobulk(t_zu, q_zu, us, ts, qs)
        if zi > 0.0:
            gust2 = beta * beta * us2 * _gust_factor(-zi * inv_L / KAPPA, gust_onset_width)
            Ub = jnp.maximum(_safe_sqrt(W2 + gust2), _COARE_UB_FLOOR)
        else:
            Ub = jnp.maximum(_safe_sqrt(W2), _COARE_UB_FLOOR)
        zeta_u = jnp.clip(z_u * inv_L, -_AB_COARE_ZETA_ABS_MAX, _AB_COARE_ZETA_ABS_MAX)
        un10 = us / KAPPA * (log_10 - log_z0)
        z0 = (_coare3p0_charnock(un10, charnock, charnock_ramp_width) * us2 / _AB_GRAV
              + _AB_COARE_SMOOTH * nu / us)
        z0 = jnp.clip(jnp.abs(z0), _AB_COARE_Z_MIN, 1.0)
        log_z0 = jnp.log(z0)
        z0t = jnp.minimum(_AB_COARE_Z0T_MAX,
                          _AB_COARE_Z0T_COEF * (nu / (z0 * us)) ** _AB_COARE_Z0T_EXP)
        z0t = jnp.clip(jnp.abs(z0t), _AB_COARE_Z_MIN, 1.0)
        psih_u = psi_h_coare(zeta_u, stability_scheme, neutral_width)
        tmp = KAPPA / _floor(log_zu - jnp.log(z0t) - psih_u)
        ts = dt * tmp
        qs = dq * tmp
        us_new = jnp.maximum(
            Ub * KAPPA / _floor(log_zu - log_z0 - psi_m_coare(zeta_u, stability_scheme, neutral_width)),
            _AB_COARE_USTAR_MIN)
        if equal is not True:
            zeta_t = jnp.clip(z_t * inv_L, -_AB_COARE_ZETA_ABS_MAX, _AB_COARE_ZETA_ABS_MAX)
            prf = log_zt - log_zu + psih_u - psi_h_coare(zeta_t, stability_scheme, neutral_width)
            t_new = t_zt - ts / KAPPA * prf
            q_new = q_zt - qs / KAPPA * prf
            t_zu = jnp.where(equal, t_zu, t_new)
            q_zu = jnp.where(equal, q_zu, q_new)
            dt = jnp.where(equal, dt, _sign_floor(t_zu - T_s, _AB_DT_MIN))
            dq = jnp.where(equal, dq, _sign_floor(q_zu - q_s, _AB_DQ_MIN))
        resid = jnp.abs(us_new - us) / jnp.maximum(jnp.abs(us_new), 1e-6)
        return (us_new, ts, qs, t_zu, q_zu, dt, dq, log_z0, z0t, Ub, inv_L, resid)

    carry = (us, ts, qs, t_zu, q_zu, dt, dq, log_z0, z0t, Ub, inv_L, resid)
    dtypes = tuple(jnp.result_type(c) for c in carry)

    def body_pinned(i, c):
        return tuple(jnp.asarray(o).astype(d) for o, d in zip(body(i, c), dtypes))

    carry = tuple(jnp.asarray(c).astype(d) for c, d in zip(carry, dtypes))
    us, ts, qs, t_zu, q_zu, dt, dq, _log_z0, z0t, Ub, inv_L, resid = jax.lax.fori_loop(
        0, n_iter, body_pinned, carry)
    r = us / Ub
    Cd = jnp.maximum(r * r, _AB_CX_MIN)
    Ch = jnp.maximum(r * ts / dt, _AB_CX_MIN)
    Ce = jnp.maximum(r * qs / dq, _AB_CX_MIN)
    return dict(Cd=Cd, Ch=Ch, Ce=Ce, t_zu=t_zu, q_zu=q_zu, Ub=Ub, us=us, ts=ts, qs=qs,
                z0t=z0t, inv_L=inv_L, resid=resid)


# ============================================================================
# AeroBulk 1.0.0 TURB_NCAR (Large & Yeager 2004, 2009)
# ============================================================================
# --- mod_blk_ncar ---
_AB_NCAR_UB_MIN = 0.5          # Ubzu = MAX(0.5, U_zu)
_AB_NCAR_UN10_MIN = 0.25       # zUn10 = MAX(0.25, UN10_from_CD(...))
_AB_NCAR_ZETA_ABS_MAX = 10.0
_AB_NCAR_CHN_STABLE = 18.0     # 1e-3 sqrt(CdN) * 18   (zeta >= 0)
_AB_NCAR_CHN_UNSTABLE = 32.7   # 1e-3 sqrt(CdN) * 32.7 (zeta < 0)
_AB_NCAR_CEN = 34.6            # 1e-3 sqrt(CdN) * 34.6
_AB_NCAR_CD_CUTOFF_U = 33.0    # cd_n10_ncar: 2.34e-3 plateau for U >= 33 m/s
_AB_NCAR_CD_PLATEAU = 2.34
# RULE 5 smooth defaults (#2241, user decisions 2026-10-31); 0.0 = AeroBulk's
# hard switch in each case.
# Half-width in zeta_u of the compact quintic blend of the stable/unstable
# neutral Stanton numbers (18 vs 32.7) inside the iteration (the N6 form).
NCAR_NEUTRAL_WIDTH = 1.0e-3
# Half-width [K] of the same blend in dthv for the first guess.
NCAR_DTHV_WIDTH = 1.0e-2
# Width [m/s] of the one-sided quintic blend of the LY09 polynomial into the
# 2.34e-3 plateau over [33 - w, 33] m/s (the plateau stays exact from 33 m/s).
NCAR_CD_CUTOFF_WIDTH = 0.5
# Config-field name -> default of the three widths above (#2241).
LARGE_YEAGER_WIDTH_DEFAULTS = {
    "large_yeager_neutral_width": NCAR_NEUTRAL_WIDTH,
    "large_yeager_dthv_width": NCAR_DTHV_WIDTH,
    "large_yeager_cd_cutoff_width": NCAR_CD_CUTOFF_WIDTH,
}


def large_yeager_widths(config) -> dict:
    """The three Large-Yeager smooth-switch widths a component config carries,
    as :func:`compute_most_fluxes` keyword arguments (#2241: config fields, not
    call-site defaults).  Missing fields raise ``AttributeError``."""
    return {k: getattr(config, k) for k in LARGE_YEAGER_WIDTH_DEFAULTS}


def _ncar_stable_weight(x, width):
    """Weight of the stable neutral Stanton number (18) in TURB_NCAR.

    ``x`` is ``zeta_u`` in the iteration or ``dthv`` [K] in the first guess.
    ``width == 0``: AeroBulk's ``x >= 0`` step.  ``width = w > 0`` (RULE 5):
    ``smoothstep_quintic((x + w) / (2 w))``, C2, exactly 0 for ``x <= -w`` and
    1 for ``x >= w`` (0.5 at ``x = 0``, where the hard step is 1).
    """
    if width == 0.0:
        return jnp.where(x >= 0.0, 1.0, 0.0)
    return smoothstep_quintic((x + width) / (2.0 * width))


def _cd_n10_ncar(w10, cutoff_width=NCAR_CD_CUTOFF_WIDTH):
    """AeroBulk ``cd_n10_ncar``: LY09 Eq. 6 neutral 10 m drag, 2.34e-3 for
    U >= 33 m/s, floored at Cx_min.  No wind floor (callers floor U).

    ``cutoff_width == 0``: AeroBulk's hard switch at 33 m/s (a 0.074 % jump,
    2.33827 -> 2.34).  ``cutoff_width = w > 0`` (RULE 5 default 0.5 m/s):
    ``s * 2.34 + (1 - s) * poly`` with ``s = smoothstep_quintic((U - 33 + w)/w)``,
    exactly the polynomial below ``33 - w`` and exactly 2.34 from 33 m/s.  The
    smooth path evaluates the polynomial at ``min(U, 33)`` (only its weight
    ``1 - s = 0`` reaches it above 33 m/s), so a huge wind cannot overflow
    its ``U**6`` term into ``0 * inf = NaN``.
    """
    if cutoff_width == 0.0:
        cd = jnp.where(w10 >= _AB_NCAR_CD_CUTOFF_U, _AB_NCAR_CD_PLATEAU, _ly09_cdn_poly(w10))
    else:
        s = smoothstep_quintic((w10 - _AB_NCAR_CD_CUTOFF_U + cutoff_width) / cutoff_width)
        cd = (s * _AB_NCAR_CD_PLATEAU
              + (1.0 - s) * _ly09_cdn_poly(jnp.minimum(w10, _AB_NCAR_CD_CUTOFF_U)))
    return jnp.maximum(1.0e-3 * cd, _AB_CX_MIN)


def _turb_ncar(W2, t_zt, q_zt, T_s, q_s, z_u, z_t, equal, n_iter, stability_scheme="dyer1974",
               unstable_gamma=_DYER_UNSTABLE_GAMMA, stable_beta=_DYER_STABLE_BETA,
               coeff_cap=None, neutral_width=NCAR_NEUTRAL_WIDTH, dthv_width=NCAR_DTHV_WIDTH,
               cd_cutoff_width=NCAR_CD_CUTOFF_WIDTH):
    """AeroBulk 1.0.0 ``TURB_NCAR`` (Large & Yeager 2004, 2009).

    ``W2`` is the squared wind module; ``equal`` is AeroBulk's
    ``l_zt_equal_zu`` (Python bool or boolean array).  The stability functions
    are :func:`psi_m`/:func:`psi_h`, which with the defaults
    (``"dyer1974"``, gamma 16, beta 5) are AeroBulk's ``psi_m_ncar`` /
    ``psi_h_ncar``.  ``coeff_cap`` (None = AeroBulk) is legoESM's optional
    ``max_exchange_coeff`` ceiling, applied as ``sqrt(Cd)``, ``Ch/sqrt(Cd)``,
    ``Ce/sqrt(Cd)`` <= cap after each coefficient update.

    Returns Cd, Ch, Ce, t_zu, q_zu, Ub, u* (u* = sqrt(Cd) Ub at the start of the
    last iteration, as AeroBulk returns it), the AeroBulk-sign scales theta*,
    q*, 1/L and the last-iteration relative u* change.
    """
    Ub = jnp.maximum(_AB_NCAR_UB_MIN, _safe_sqrt(W2))
    log_zt_zu = jnp.log(z_t / z_u)
    log_zu_10 = jnp.log(z_u / 10.0)
    dthv = t_zt * (1.0 + _AB_RCTV0 * q_zt) - T_s * (1.0 + _AB_RCTV0 * q_s)
    stab = _ncar_stable_weight(dthv, dthv_width)
    CdN = _cd_n10_ncar(Ub, cd_cutoff_width)
    sqrt_CdN = jnp.sqrt(CdN)
    Cd = CdN
    Ce = jnp.maximum(1.0e-3 * (_AB_NCAR_CEN * sqrt_CdN), _AB_CX_MIN)
    Ch = jnp.maximum(1.0e-3 * sqrt_CdN * (_AB_NCAR_CHN_STABLE * stab
                                          + _AB_NCAR_CHN_UNSTABLE * (1.0 - stab)), _AB_CX_MIN)
    sqrt_Cd = sqrt_CdN
    t_zu = jnp.maximum(t_zt, _AB_T_MIN)
    q_zu = jnp.maximum(q_zt, _AB_Q_MIN)
    zero = jnp.zeros_like(Ub)

    carry = (Cd, Ch, Ce, sqrt_Cd, t_zu, q_zu, zero, zero, zero, zero, jnp.ones_like(Ub))
    dtypes = tuple(jnp.result_type(c) for c in carry)
    carry = tuple(jnp.asarray(c).astype(d) for c, d in zip(carry, dtypes))
    k = dict(T_s=T_s, q_s=q_s, Ub=Ub, t_zt=t_zt, q_zt=q_zt, z_u=z_u, z_t=z_t,
             equal=equal, log_zt_zu=log_zt_zu, log_zu_10=log_zu_10,
             stability_scheme=stability_scheme, unstable_gamma=unstable_gamma,
             stable_beta=stable_beta, coeff_cap=coeff_cap,
             neutral_width=neutral_width, cd_cutoff_width=cd_cutoff_width)
    # Key on type and repr too: 5.0 vs np.float64(5.0) promote differently,
    # and 0.0 == -0.0, so equality alone could reuse the wrong literal.
    static = tuple((n, type(v), repr(v), v) for n, v in k.items() if _is_static_value(v))
    dyn = {n: v for n, v in k.items() if not _is_static_value(v)}
    Cd, Ch, Ce, _sqrt_Cd, t_zu, q_zu, us, ts, qs, inv_L, resid = _ncar_iterate(
        carry, dyn, n_iter=n_iter, static=static)
    return dict(Cd=Cd, Ch=Ch, Ce=Ce, t_zu=t_zu, q_zu=q_zu, Ub=Ub, us=us, ts=ts, qs=qs,
                inv_L=inv_L, resid=resid)


def _is_static_value(v):
    return v is None or isinstance(v, (str, bool, numbers.Number))


# One module-level jit, keyed on the Python scalars, so an eager caller (the 2 m
# temperature diagnostic) reuses the compiled loop; a per-call closure body made
# the eager fori_loop retrace and recompile on every call.
@functools.partial(jax.jit, static_argnames=("n_iter", "static"))
def _ncar_iterate(carry, dyn, *, n_iter, static):
    k = {**{n: v for n, _, _, v in static}, **dyn}
    dtypes = tuple(jnp.result_type(c) for c in carry)

    def body_pinned(i, c):
        return tuple(jnp.asarray(o).astype(d)
                     for o, d in zip(_ncar_body(c, **k), dtypes))

    return jax.lax.fori_loop(0, n_iter, body_pinned, carry)


def _ncar_body(c, *, T_s, q_s, Ub, t_zt, q_zt, z_u, z_t, equal, log_zt_zu,
               log_zu_10, stability_scheme, unstable_gamma, stable_beta,
               coeff_cap, neutral_width, cd_cutoff_width):
    def _pm(z):
        return psi_m(z, stability_scheme, unstable_gamma=unstable_gamma, stable_beta=stable_beta)

    def _ph(z):
        return psi_h(z, stability_scheme, unstable_gamma=unstable_gamma, stable_beta=stable_beta)

    Cd, Ch, Ce, sqrt_Cd, t_zu, q_zu, _us, _ts, _qs, _inv_L, _resid = c
    dt = t_zu - T_s
    dq = q_zu - q_s
    us = sqrt_Cd * Ub
    ts = Ch / sqrt_Cd * dt
    qs = Ce / sqrt_Cd * dq
    inv_L = _one_on_l_aerobulk(t_zu, q_zu, us, ts, qs)
    zeta_u = jnp.clip(z_u * inv_L, -_AB_NCAR_ZETA_ABS_MAX, _AB_NCAR_ZETA_ABS_MAX)
    psih_u = _ph(zeta_u)
    if equal is not True:
        zeta_t = jnp.clip(z_t * inv_L, -_AB_NCAR_ZETA_ABS_MAX, _AB_NCAR_ZETA_ABS_MAX)
        tmp = log_zt_zu + psih_u - _ph(zeta_t)
        t_zu = jnp.where(equal, t_zu, t_zt - ts / KAPPA * tmp)
        q_zu = jnp.where(equal, q_zu, jnp.maximum(0.0, q_zt - qs / KAPPA * tmp))
    psim = _pm(zeta_u)
    # UN10_from_CD: sqrt(Cd) Ub / kappa * ln(10 / z0_from_Cd(zu, Cd, psi_m))
    sq = jnp.sqrt(Cd)
    z0 = z_u * jnp.exp(-(KAPPA / sq + psim))
    un10 = jnp.maximum(_AB_NCAR_UN10_MIN, sq * Ub / KAPPA * jnp.log(10.0 / z0))
    CdN = _cd_n10_ncar(un10, cd_cutoff_width)
    sqrt_CdN = jnp.sqrt(CdN)
    tmp = 1.0 + sqrt_CdN / KAPPA * (log_zu_10 - psim)
    Cd = jnp.maximum(CdN / (tmp * tmp), _AB_CX_MIN)
    sqrt_Cd = jnp.sqrt(Cd)
    tmp = (log_zu_10 - psih_u) / KAPPA / sqrt_CdN
    tmp2 = sqrt_Cd / sqrt_CdN
    stab = _ncar_stable_weight(zeta_u, neutral_width)
    ChN = 1.0e-3 * sqrt_CdN * (_AB_NCAR_CHN_STABLE * stab
                               + _AB_NCAR_CHN_UNSTABLE * (1.0 - stab))
    CeN = 1.0e-3 * (_AB_NCAR_CEN * sqrt_CdN)
    Ch = jnp.maximum(ChN * tmp2 / (1.0 + ChN * tmp), _AB_CX_MIN)
    Ce = jnp.maximum(CeN * tmp2 / (1.0 + CeN * tmp), _AB_CX_MIN)
    if coeff_cap is not None:
        sqrt_Cd = jnp.minimum(sqrt_Cd, coeff_cap)
        Cd = sqrt_Cd * sqrt_Cd
        Ch = jnp.minimum(Ch, coeff_cap * sqrt_Cd)
        Ce = jnp.minimum(Ce, coeff_cap * sqrt_Cd)
    resid = jnp.abs(sqrt_Cd * Ub - us) / jnp.maximum(jnp.abs(sqrt_Cd * Ub), 1e-6)
    return (Cd, Ch, Ce, sqrt_Cd, t_zu, q_zu, us, ts, qs, inv_L, resid)


# ============================================================================
# Main MOST flux computation
# ============================================================================

def compute_most_fluxes(
    u_rel,
    v_rel,
    T_atm,
    q_atm,
    T_sfc,
    q_sfc,
    rho,
    z_ref=10.0,
    z_t=None,
    z_q=None,
    z0_init=1e-4,
    scheme="coare3",
    n_iter=5,
    charnock=0.011,
    L_latent=None,
    thermo_convention="legoesm",
    gustiness_w_zi=None,
    gustiness_beta=1.25,
    return_2m=False,
    z_diag=2.0,
    max_exchange_coeff=None,
    stability_scheme="dyer1974",
    return_convergence=False,
    *,
    return_wind_speed=False,
    unstable_gamma=_DYER_UNSTABLE_GAMMA,
    stable_beta=_DYER_STABLE_BETA,
    z0h_z0_ratio=_Z0H_Z0_RATIO_DEFAULT,
    coare_neutral_width=COARE_NEUTRAL_WIDTH,
    coare_charnock_ramp_width=COARE_CHARNOCK_RAMP_WIDTH,
    coare_gust_onset_width=COARE_GUST_ONSET_WIDTH,
    large_yeager_neutral_width=NCAR_NEUTRAL_WIDTH,
    large_yeager_dthv_width=NCAR_DTHV_WIDTH,
    large_yeager_cd_cutoff_width=NCAR_CD_CUTOFF_WIDTH,
):
    """Compute stability-dependent bulk fluxes via iterative MOST.

    Uses ``jax.lax.fori_loop`` for the Obukhov length iteration,
    ensuring full JAX differentiability (jax.grad, jax.jit).

    Parameters
    ----------
    u_rel, v_rel : array
        Wind components relative to z_ref [m/s].
    T_atm : array
        Atmospheric temperature at z_t [K].
    q_atm : array
        Atmospheric specific humidity at z_q [kg/kg].
    T_sfc : array
        Surface temperature [K].
    q_sfc : array
        Surface saturation specific humidity [kg/kg].
    rho : array
        Air density at z_t [kg/m³].
    z_ref : float
        Reference height for the wind / momentum [m] (default 10).
    z_t : float or None
        Reference height for atmospheric temperature [m]. Defaults to
        ``z_ref`` (single-height mode).  For OMIP-2 / JRA55-do use **10.0**:
        the v1.4.0 files carry an explicit ``height = 10.0 m`` coordinate on
        ``tas`` and ``huss`` as well as on ``uas``/``vas`` (the CF
        ``comment`` string "usually, 2 meter" is CMOR-table boilerplate that
        contradicts the file's own coordinate), and FESOM2 forces the same
        dataset with ``ncar_bulk_z_tair = ncar_bulk_z_shum = 10.0``.  This
        docstring previously said 2.0; declaring the 10 m state at 2 m
        inflates the air-sea gradients by ~10 % of the turbulent fluxes.
    z_q : float or None
        Reference height for atmospheric specific humidity [m]. Defaults
        to ``z_ref`` (single-height mode).  10.0 for OMIP-2 / JRA55-do, per
        the note on ``z_t``.
    z0_init : float
        Initial momentum roughness length [m] (default 1e-4).  Not read by
        ``coare3`` / ``large_yeager``: AeroBulk's first guesses have no
        roughness seed.
    scheme : str
        ``"constant"``, ``"most"``, ``"coare3"`` or ``"large_yeager"``.  The
        fixed-roughness log-law path (``"constant"``/``"most"``) uses
        ``z0_init`` (and ``z0h_z0_ratio`` for the scalar roughness) directly;
        ``coare3``/``large_yeager`` evolve the roughness in the iteration.
    n_iter : int
        Number of MOST iterations (default 5; AeroBulk ``nb_iter``).
    charnock : float
        Charnock coefficient below 10 m/s (COARE only, default 0.011).
        AeroBulk's literal is the single-precision 0.011
        (= 0.010999999940395355); the high-wind value is
        ``max(0.018, charnock)``.
    thermo_convention : str
        Constants set converting MOST scales into fluxes (#762):
        ``"legoesm"`` (default) = constant ``L_v`` / dry ``c_pd``;
        ``"aerobulk"`` = the NEMO/AeroBulk/COARE convention
        (SST-dependent ``L_vap(T_sfc)``, moist ``cp_air(q_atm)``) — up to
        ~3 % LH at warm SST and ~1-2 % SH in the humid tropics.  An
        explicit ``L_latent`` overrides the L choice either way.
    gustiness_w_zi : float or None
        COARE convective-gustiness BL depth z_i [m].  None (default) =
        scheme-native: 600 m for ``"coare3"`` (AeroBulk zi0 — gustiness is
        part of the algorithm), 0 (off) for the others.  Explicit 0.0
        disables for any scheme.  ``large_yeager`` (AeroBulk TURB_NCAR, no
        gustiness) raises NotImplementedError for a value > 0.  On
        ``coare3`` the gust is AeroBulk's
        ``Beta0^2 u*^2 max(-zi/(kappa L), 0)^(2/3)`` with
        ``Beta0 = gustiness_beta``.
    max_exchange_coeff : float or None
        Optional physical ceiling on the neutral-equivalent bulk transfer
        coefficient ``C = κ²/(denom_m·denom_h)``.  ``None`` (default) leaves
        the MOST log-law denominators floored at the standard ``0.5``
        (``C ≤ κ²/0.25 ≈ 0.64``), i.e. BYTE-IDENTICAL to the prior behaviour
        for every existing (ocean/atmosphere) caller.  When set to ``C_max``,
        each denominator is instead floored at ``max(0.5, κ/√C_max)`` so the
        implied ``C_d``, ``C_h`` and ``C_e`` cannot exceed ``C_max``.  This
        caps ``u*``, ``θ*`` and ``q*`` CONSISTENTLY (the fluxes stay linear in
        the T/q gradients, so a surface-energy-balance solve retains its
        self-limiting feedback) and removes the extreme-instability cold-start
        singularity where the floored ``0.5`` denominator lets a trivial
        ~0.6 g/kg humidity gradient generate a spurious ~4900 W/m² latent
        shock (``C_e≈0.64`` vs a physical ~3.4e-3).  Intended for the land
        surface tile, whose stiff thin top layer at ``dt_rad`` is unstable to
        that shock; ocean/atmosphere callers never approach the floor.
        On ``coare3`` (AeroBulk has no denominator floor) ``None`` applies no
        floor; a ``C_max`` floors the denominators at ``max(0.5, κ/√C_max)``.
    stability_scheme : str
        Stable-regime (zeta > 0) similarity functions ``psi_m``/``psi_h``.
        ``"dyer1974"`` (default) is the historical linear ``-5 zeta`` on the
        ``constant``/``most``/``large_yeager`` Businger-Dyer path, and the
        AeroBulk native stable form on ``coare3`` (the Beljaars & Holtslag
        1991 fit with rounded constants; see :func:`psi_m_coare`).  The
        non-linear alternatives ``"beljaars_holtslag1991"``,
        ``"grachev2007_sheba"`` and ``"gryanik2020"`` do not collapse the fluxes
        to zero under strong stability (Arctic sea-ice / nocturnal SBL); on
        ``coare3`` they swap ONLY the stable branch (the Fairall unstable blend
        is COARE-defining and always kept), so on that scheme
        ``"beljaars_holtslag1991"`` is a rounding-level change vs the default
        and the genuinely different tails are grachev/gryanik. The unstable
        branch (zeta < 0) stays Businger-Dyer (Fairall blend for coare3)
        regardless. Validated at function entry (a typo raises ``ValueError``).
    unstable_gamma : float
        Businger-Dyer / Dyer (1974) UNSTABLE-branch coefficient gamma in
        ``x = (1 - gamma zeta)^{1/4}`` (psi_m) / ``y = (1 - gamma zeta)^{1/2}``
        (psi_h) for zeta < 0.  Default 16 (byte-identical to the prior
        behaviour).  A LARGER gamma makes psi more positive under instability =>
        smaller log-law denominator => larger exchange coefficient => stronger
        fluxes.  Applies to the Businger-Dyer unstable branch used by the
        ``constant``/``most``/``large_yeager`` (non-COARE) path ONLY when
        ``stability_scheme="dyer1974"``; the non-linear stable schemes keep the
        historical gamma = 16 unstable branch and COARE 3.0 keeps its own Fairall
        (1996/2003) unstable coefficients.
    stable_beta : float
        Dyer (1974) STABLE-branch linear coefficient beta in
        ``psi = -beta zeta`` for zeta > 0, used ONLY when
        ``stability_scheme="dyer1974"``.  Default 5 (byte-identical).  A LARGER
        beta makes psi more negative under stability => larger log-law
        denominator => smaller exchange coefficient => weaker fluxes.  Ignored by
        the non-linear ``beljaars_holtslag1991``/``grachev2007_sheba``/
        ``gryanik2020`` stable forms (their own published fits) and by COARE 3.0.
    z0h_z0_ratio : float
        Thermal/momentum roughness ratio z0h/z0 for the FIXED-roughness path:
        z0_t = z0_q = z0_init * z0h_z0_ratio.  Default 0.1 (byte-identical to
        the prior hardcoded ``z0 * 0.1``).  Consumed ONLY by the
        ``constant``/``most`` (log-law fixed-roughness) branch.  COARE 3.0 and
        large_yeager compute their own scalar roughness in the loop and are
        EXACTLY invariant to this argument: their pre-loop z0_t seed is pinned to
        the historical 0.1 so a finite-``n_iter`` seed residual cannot leak the
        ratio into the ocean-scheme fluxes.  A LARGER ratio => larger z0_t =>
        smaller ln(z_t/z0_t) denom_h => larger heat exchange coefficient =>
        STRONGER sensible/latent flux (Garratt 1992; Zilitinkevich kB^-1 range
        ~0.01-1).
    coare_neutral_width : float
        ``coare3`` only: half-width of the compact quintic blend across zeta = 0 in
        :func:`psi_m_coare` / :func:`psi_h_coare` (static Python float).
        Default ``COARE_NEUTRAL_WIDTH`` = 1e-3 (RULE 5 smooth default);
        ``0.0`` is AeroBulk's hard SIGN switch.  KNOWN DIFFERENCE vs the
        compiled AeroBulk oracle at the default (with ``charnock`` = 0.011):
        per-state gaps stored in
        ``tests/core/oracle_fixtures/aerobulk_coare3p0_default_gap.npz``.
    coare_charnock_ramp_width : float
        ``coare3`` only: width [m/s] of the C1 corner rounding of the Charnock
        10 -> 18 m/s wind ramp (:func:`_coare3p0_charnock`; static Python
        float, ``0 <= w <= 8``).  Default ``COARE_CHARNOCK_RAMP_WIDTH`` = 0.5
        (RULE 5); ``0.0`` is AeroBulk's ``clip``.  KNOWN DIFFERENCE (#2241,
        measured 2026-10-30 on the 1549-state AeroBulk fixture, this width
        alone, the others hard): max relative gap 1.3e-3 in stress, 4.0e-4 in
        heat fluxes, 6.5e-4 in u* at z_t = 10 m (1.5e-3 / 3.8e-4 / 7.3e-4 at
        2 m).  With every coare3 default: 1.3e-3 / 5.2e-4 / 6.5e-4 at 10 m,
        1.5e-3 / 4.6e-4 / 7.3e-4 at 2 m, per state in
        ``aerobulk_coare3p0_default_gap.npz``.
    coare_gust_onset_width : float
        ``coare3`` only: width [1] in ``x = -zi/(kappa L)`` of the quintic onset
        of the convective-gustiness factor ``x**(2/3)`` (:func:`_gust_factor`;
        static Python float).  Default ``COARE_GUST_ONSET_WIDTH`` = 1e-2
        (RULE 5); ``0.0`` is AeroBulk's form (infinite slope at x = 0+).
        KNOWN DIFFERENCE (#2241, same fixture, this width alone): max relative
        gap 3.9e-5 in stress, 2.7e-5 in heat fluxes, 3.1e-5 in u*.
    large_yeager_neutral_width : float
        ``large_yeager`` only: half-width in zeta_u of the compact quintic blend
        (:func:`_ncar_stable_weight`) of the stable/unstable neutral Stanton
        numbers (18 vs 32.7) inside the iteration (static Python float).
        Default ``NCAR_NEUTRAL_WIDTH`` = 1e-3 (RULE 5); ``0.0`` is AeroBulk's
        hard ``zeta_u >= 0`` switch.  KNOWN DIFFERENCE (#2241, measured
        2026-10-31 on the 1549-state AeroBulk TURB_NCAR fixture, this width
        alone): 73 states at z_t = 10 m and 96 at 2 m move by more than 1e-9
        relative, mostly high-wind ones (small |zeta| at every stratification);
        max sensible-heat gap 45.7 W/m2 (0.33 relative) at 10 m and 28.9 W/m2
        (0.72) at 2 m; max relative gap in stress 3.6e-3 / 3.9e-2, latent heat
        3.8e-3 / 2.2e-2, u* 5.4e-3 / 1.9e-2 (10 m / 2 m).
    large_yeager_dthv_width : float
        ``large_yeager`` only: half-width [K] of the same blend in the first
        guess, across ``dthv = 0`` (virtual potential temperature air - sea).
        Default ``NCAR_DTHV_WIDTH`` = 1e-2 (RULE 5); ``0.0`` is AeroBulk's
        ``dthv >= 0``.  KNOWN DIFFERENCE (same fixture, this width alone): 1
        state at 10 m and 3 at 2 m move by more than 1e-9; max relative gap
        7.9e-7 (sensible heat, 2 m).
    large_yeager_cd_cutoff_width : float
        ``large_yeager`` only: width [m/s] of the one-sided quintic blend of the
        LY09 drag polynomial into the 2.34e-3 plateau over ``[33 - w, 33]``
        (:func:`_cd_n10_ncar`; static Python float, ``0 <= w <= 33``).  Default
        ``NCAR_CD_CUTOFF_WIDTH`` = 0.5 (RULE 5); ``0.0`` is AeroBulk's hard
        switch.  KNOWN DIFFERENCE (same fixture, this width alone): 5 states
        move; max relative gap 7.4e-4 in stress, 3.7e-4 in heat fluxes and u*.
        With all three defaults: 77 states (10 m) / 101 (2 m), maxima as for
        the neutral width alone; per state in
        ``tests/core/oracle_fixtures/aerobulk_ncar_default_gap.npz``.
    return_convergence : bool
        When True, additionally return the MOST fixed-point convergence
        residual (the relative change in ``u*`` over the FINAL iteration).
        Default False = byte-identical to the prior signature.  The Obukhov
        iteration is a fixed ``n_iter`` ``fori_loop`` (AD-safe — a
        tolerance-based ``while_loop`` would break reverse-mode ``grad``), so
        this residual is the convergence CHECK: it is ~0 where the fixed
        iteration count converged and O(1) in the strong-stability columns
        where it did not (the gap vs a tolerance-guaranteed root solve, e.g.
        CliMA SurfaceFluxes.jl).  It does not affect the fluxes.

    Returns
    -------
    tau_x, tau_y : array
        Surface stress [Pa] (opposes wind direction).
    shflx : array
        Sensible heat flux [W/m²] (positive upward = surface warmer).
    lhflx : array
        Latent heat flux [W/m²] (positive upward = surface moister).
    ustar : array
        Friction velocity [m/s].
    most_residual : array
        ONLY when ``return_convergence=True`` (appended last, after ``T_2m``
        if ``return_2m`` is also set): the final-iteration relative ``u*``
        change [1], per column.
    """
    # Dispatch hardening (CLAUDE.md): ``scheme`` is a static Python string
    # resolved at trace time. Validate it at function entry so a typo'd name
    # (e.g. ``"coar3"``) fails LOUDLY instead of silently falling through the
    # ``else`` branch below to the constant-roughness MOST path and running the
    # wrong air-sea physics. ``coare3``/``large_yeager`` take dedicated
    # branches; ``constant``/``most`` are the (valid) fixed-roughness else path.
    validate_bulk_scheme(scheme)
    if scheme == "large_yeager_cesm":
        raise ValueError(
            "compute_most_fluxes does not implement 'large_yeager_cesm' (the "
            "CESM shr_flux_atmOcn law has its own fixed-iteration solver): "
            "call compute_sam_oceflx_fluxes(..., variant='cesm') — the "
            "surface-layer / coupler dispatchers do."
        )
    # Dispatch hardening (#762): the thermodynamic-convention selector is a
    # static string — a typo must fail LOUDLY, never silently run the other
    # constants set.
    if thermo_convention not in ("legoesm", "aerobulk"):
        raise ValueError(
            "thermo_convention must be 'legoesm' or 'aerobulk', got "
            f"{thermo_convention!r}"
        )
    # ``stability_scheme`` selects the STABLE-branch psi_m/psi_h; also a static
    # string, so validate it once here rather than inside the traced loop body.
    validate_stability_scheme(stability_scheme)

    # Scheme-native gustiness default (AeroBulk/COARE parity, static Python
    # resolved at trace time) via the single shared resolver — the air-sea
    # consistency guard uses the same one.
    gustiness_w_zi = resolve_gustiness_w_zi(gustiness_w_zi, scheme)

    # Resolve scalar reference heights. ``z_ref`` is the wind/momentum
    # height (always = z_u in the formulas below); z_t, z_q default to
    # z_ref so that single-height callers (lake, idealized adapter,
    # legacy tests) keep their existing behaviour bit-identically.
    z_u = z_ref
    if z_t is None:
        z_t = z_ref
    if z_q is None:
        z_q = z_ref

    wind_speed = jnp.sqrt(u_rel ** 2 + v_rel ** 2 + 1e-4)
    dT = T_sfc - T_atm
    dq = q_sfc - q_atm
    # Virtual-T moisture coefficient = 1/ε − 1 ≈ 0.6078 (canonical, not 0.61).
    _vT_coef = 1.0 / constants.epsilon - 1.0
    T_v = T_atm * (1.0 + _vT_coef * q_atm)

    # Log-law denominator floor. Default 0.5 (=> C ≤ κ²/0.25 ≈ 0.64, the
    # historical behaviour, byte-identical for every existing caller). When a
    # physical ceiling ``max_exchange_coeff`` is requested, floor each
    # denominator at κ/√C_max so the implied C_d/C_h/C_e ≤ C_max — a static
    # Python float, constant-folded, no retrace (feature-gating, not traced
    # selection). See the ``max_exchange_coeff`` docstring entry.
    if max_exchange_coeff is None:
        _denom_floor = 0.5
        _coeff_cap = None
    else:
        # Static feature-gate value (constant-folded). A traced/array scalar
        # would break the Python ``max``/``if`` below, so require a real Python
        # or numpy scalar and reject it loudly rather than silently mis-tracing.
        # ``bool`` is a numbers.Real subclass — exclude it explicitly. Then
        # guard finite > 0: C_max = 0 gives an infinite floor (silent zero
        # fluxes) and C_max < 0 gives ``sqrt`` of a negative (NaN).
        if isinstance(max_exchange_coeff, bool) or not isinstance(
            max_exchange_coeff, numbers.Real
        ):
            raise TypeError(
                "max_exchange_coeff must be a static real scalar or None, "
                f"got {type(max_exchange_coeff).__name__}"
            )
        max_exchange_coeff = float(max_exchange_coeff)
        if not (math.isfinite(max_exchange_coeff) and max_exchange_coeff > 0.0):
            raise ValueError(
                "max_exchange_coeff must be finite and > 0, "
                f"got {max_exchange_coeff}"
            )
        _denom_floor = max(0.5, KAPPA / (max_exchange_coeff ** 0.5))
        # Coefficient-space equivalent ceiling for the large_yeager branch,
        # which forms rd/rh/re directly (u*=rd·U, θ*=rh·dT, q*=re·dq) and never
        # touches the log-law denominators.  The log-law path caps the
        # "rd-equivalent" κ/denom at κ/_denom_floor, so bounding rd, rh, re at
        # the SAME value gives C_d=rd² , C_h=rd·rh , C_e=rd·re ≤ C_max
        # identically.  = min(√C_max, 0.8) so it never tightens below the
        # historical 0.5-floor behaviour.
        _coeff_cap = KAPPA / _denom_floor

    for _name, _w, _w_max in (("coare_charnock_ramp_width", coare_charnock_ramp_width,
                               _COARE_CHARNOCK_U_HI - _COARE_CHARNOCK_U_LO),
                              ("coare_gust_onset_width", coare_gust_onset_width, math.inf),
                              ("large_yeager_neutral_width", large_yeager_neutral_width, math.inf),
                              ("large_yeager_dthv_width", large_yeager_dthv_width, math.inf),
                              ("large_yeager_cd_cutoff_width", large_yeager_cd_cutoff_width,
                               _AB_NCAR_CD_CUTOFF_U)):
        if not (isinstance(_w, numbers.Real) and math.isfinite(_w) and 0.0 <= _w <= _w_max):
            raise ValueError(f"{_name} must be a finite float in [0, {_w_max}], got {_w!r}")

    _coare = None
    if scheme in ("coare3", "large_yeager"):
        if max_exchange_coeff is not None and max_exchange_coeff < _AB_CX_MIN:
            raise ValueError(
                f"{scheme} (AeroBulk): max_exchange_coeff={max_exchange_coeff} is "
                f"below AeroBulk's exchange-coefficient floor Cx_min={_AB_CX_MIN}.")
        # AeroBulk 1.0.0 TURB_COARE3P0 / TURB_NCAR, ported faithfully.
        # AeroBulk has one height for t and q.
        if not (z_q is z_t or _same_static_height(z_q, z_t)):
            raise NotImplementedError(
                f"{scheme} (AeroBulk) takes temperature and humidity at one "
                f"height; got z_t={z_t!r}, z_q={z_q!r}.")
        if z_t is z_u:
            _equal = True
        elif isinstance(z_t, numbers.Real) and isinstance(z_u, numbers.Real):
            _equal = abs(z_u - z_t) < _AB_EQUAL_HEIGHT_TOL
        else:
            _equal = jnp.abs(jnp.asarray(z_u) - jnp.asarray(z_t)) < _AB_EQUAL_HEIGHT_TOL
    if scheme == "large_yeager":
        if gustiness_w_zi > 0.0:
            raise NotImplementedError(
                "large_yeager (AeroBulk TURB_NCAR) has no convective gustiness; "
                f"got gustiness_w_zi={gustiness_w_zi!r}.")
        _coare = _turb_ncar(
            u_rel ** 2 + v_rel ** 2, T_atm, q_atm, T_sfc, q_sfc, z_u, z_t, _equal,
            n_iter, stability_scheme, unstable_gamma, stable_beta, _coeff_cap,
            large_yeager_neutral_width, large_yeager_dthv_width, large_yeager_cd_cutoff_width)
        u_star = _coare["us"]
        theta_star = -_coare["ts"]
        q_star_val = -_coare["qs"]
        z0_t = None
        U_eff_final = _coare["Ub"]
        most_residual = _coare["resid"]
    elif scheme == "coare3":
        _coare = _turb_coare3p0(
            u_rel ** 2 + v_rel ** 2, T_atm, q_atm, T_sfc, q_sfc, z_u, z_t, _equal,
            n_iter, charnock, gustiness_w_zi, gustiness_beta, stability_scheme,
            None if max_exchange_coeff is None else _denom_floor, coare_neutral_width,
            coare_charnock_ramp_width, coare_gust_onset_width)
        # legoESM sign convention for the scales (positive upward = surface
        # warmer/moister than the air): theta* = -AeroBulk zts.
        u_star = _coare["us"]
        theta_star = -_coare["ts"]
        q_star_val = -_coare["qs"]
        z0_t = _coare["z0t"]
        U_eff_final = _coare["Ub"]
        most_residual = _coare["resid"]
    else:
        # Initialize with neutral log-law profile. The thermal (scalar) roughness
        # z0_t = z0_q = z0 * z0h_z0_ratio (default 0.1) is the trainable knob for
        # the FIXED-roughness "constant"/"most" path — that path carries the init
        # z0_t straight through to the flux via the log law.
        #
        # (coare3 / large_yeager never reach this path: AeroBulk ports above.)
        z0 = jnp.full_like(wind_speed, z0_init)
        z0_t = z0 * z0h_z0_ratio
        z0_q = z0_t

        ln_zu_z0 = jnp.log(z_u / jnp.maximum(z0, 1e-12))
        ln_zt_z0t = jnp.log(z_t / jnp.maximum(z0_t, 1e-12))
        ln_zq_z0q = jnp.log(z_q / jnp.maximum(z0_q, 1e-12))
        u_star = KAPPA * wind_speed / jnp.maximum(ln_zu_z0, _denom_floor)
        theta_star = KAPPA * dT / jnp.maximum(ln_zt_z0t, _denom_floor)
        q_star_val = KAPPA * dq / jnp.maximum(ln_zq_z0q, _denom_floor)

        # Carry leaves 7-8 (orthogonal MOST diagnostics unioned across branches):
        #  (7) U_eff, the bulk/effective wind incl. gustiness + scheme calm-wind
        #      floor, so the post-loop stress normalization tau = rho u*^2 u/U_eff
        #      (AeroBulk semantics: tau = rho Cd Ub u) uses the CONVERGED value;
        #      with gustiness off and no floor binding, U_eff == wind_speed
        #      byte-identically.  Seeded with the pre-loop wind_speed.
        #  (8) the MOST convergence residual (relative u* change), updated each
        #      iteration; seeded at 1.0 ("not yet converged").
        resid0 = jnp.ones_like(u_star)
        carry = (u_star, z0, z0_t, z0_q, theta_star, q_star_val, wind_speed, resid0)
        # The MOST iteration mixes the (possibly float32) input state with float64
        # physical constants (G, NU_AIR, c_pd via the virtual-T coefficient), so a
        # carry leaf would silently promote float32 -> float64 mid-loop and trip
        # ``fori_loop``'s equal-types invariant.  This only bites the float32
        # atmosphere coupled path; the OMIP ocean path runs float64 so the re-casts
        # below are no-ops (byte-identical).  Pin each leaf back to its input dtype.
        _carry_dtypes = tuple(c.dtype for c in carry)

        def body_fn(i, carry):
            u_star, z0, z0_t, z0_q, theta_star, q_star_val, _U_eff_prev, _resid = carry
            u_star_safe = jnp.maximum(u_star, 1e-6)

            # Virtual potential temperature scale (1/ε − 1 ≈ 0.6078)
            theta_v_star = theta_star + _vT_coef * T_atm * q_star_val

            # Optional convective gustiness on the non-COARE paths (OFF unless
            # an explicit gustiness_w_zi > 0 is passed; coare3 uses AeroBulk's
            # own gustiness in _turb_coare3p0).  Over
            # a calm but convectively-unstable warm ocean the mean wind alone gives
            # an anemic flux (the tropical hfls ~45 vs ~120 W/m² bias); the
            # free-convection velocity scale w* = (g·z_i·<w'θv'>/θv)^(1/3) adds a
            # sub-grid gust U_eff = sqrt(|U|² + (β·w*)²) (Fairall et al. 2003,
            # β~1.25, z_i = BL depth ~600 m).  <w'θv'> = u*·θv* (kinematic, upward
            # +; unstable only).
            if gustiness_w_zi > 0.0:
                wpthvp = jnp.maximum(u_star_safe * theta_v_star, 0.0)
                # cbrt(0) has an infinite derivative, so a stable column (buoyancy
                # flux floored to exactly 0) would inject a NaN reverse-mode
                # gradient into every trainable upstream (charnock, state).  Floor
                # the cbrt argument at a tiny positive constant: the max() kink
                # clamps the stable-side gradient to 0 (physically correct — no
                # free convection when stable) and the primal offset is w* ~ 1e-8
                # m/s, negligible next to the resolved wind.  (1e-24 <= 1e-6 safety
                # floor, exempt from the inline-coeff ratchet.)
                wstar = jnp.cbrt(
                    jnp.maximum(G * gustiness_w_zi * wpthvp / T_v, 1e-24)
                )
                U_eff = jnp.sqrt(wind_speed ** 2 + (gustiness_beta * wstar) ** 2)
            else:
                U_eff = wind_speed

            # Inverse Obukhov length: 1/L = −κ g θ_v* / (u*² T_v).
            #
            # The stability parameter ζ = z/L is the *only* way L enters this
            # solver, so we carry the reciprocal directly.  The reciprocal form
            # is singularity-free: the denominator u*² T_v is strictly positive
            # (u_star_safe ≥ 1e-6, T_v > 0), so there is no divide-by-zero and
            # no need for a sentinel or ``safe_divide``.  Crucially it gives the
            # correct neutral limit *and* its derivative: at exact neutral
            # (θ_v* = 0) ⇒ 1/L = 0 ⇒ ζ = 0 with the true finite sensitivity
            # dζ/dθ_v* = −z κ g /(u*² T_v).  Forming L = −u*²T_v/(κgθ_v*) first
            # and then z/L would instead either inject a NaN gradient (0·∞ from
            # the dead branch of a neutral-limit ``where``) or, if masked with a
            # constant ±1e6 sentinel, flatten dζ/dθ_v* to zero across the
            # neutral band and jump at the mask threshold.  Away from neutral ζ
            # equals the textbook z/L to round-off.
            inv_L = -KAPPA * G * theta_v_star / (u_star_safe ** 2 * T_v)

            # Stability parameters and ψ functions evaluated at each
            # measurement height. When z_t == z_q == z_u (single-height),
            # zeta_t == zeta_q == zeta_u and psi_h_t == psi_h_q.
            zeta_u = jnp.clip(z_u * inv_L, -10.0, 10.0)
            zeta_t = jnp.clip(z_t * inv_L, -10.0, 10.0)
            zeta_q = jnp.clip(z_q * inv_L, -10.0, 10.0)
            # Businger-Dyer with the ``stability_scheme``-selectable stable
            # branch ("dyer1974" default = the -5*zeta that LY09/NEMO ncar use).
            psi_m_u = psi_m(zeta_u, stability_scheme,
                            unstable_gamma=unstable_gamma, stable_beta=stable_beta)
            psi_h_t = psi_h(zeta_t, stability_scheme,
                            unstable_gamma=unstable_gamma, stable_beta=stable_beta)
            psi_h_q = psi_h(zeta_q, stability_scheme,
                            unstable_gamma=unstable_gamma, stable_beta=stable_beta)

            # Fixed roughness ("constant"/"most").
            z0_new = z0
            z0_t_new = z0_t
            z0_q_new = z0_q

            # Transfer coefficients via log-law + stability,
            # with each variable referenced to its own measurement height.
            ln_zu_z0 = jnp.log(z_u / jnp.maximum(z0_new, 1e-12))
            ln_zt_z0t = jnp.log(z_t / jnp.maximum(z0_t_new, 1e-12))
            ln_zq_z0q = jnp.log(z_q / jnp.maximum(z0_q_new, 1e-12))

            denom_m = jnp.maximum(ln_zu_z0 - psi_m_u, _denom_floor)
            denom_h = jnp.maximum(ln_zt_z0t - psi_h_t, _denom_floor)
            denom_q = jnp.maximum(ln_zq_z0q - psi_h_q, _denom_floor)

            u_star_new = KAPPA * U_eff / denom_m
            theta_star_new = KAPPA * dT / denom_h
            q_star_new = KAPPA * dq / denom_q

            # MOST fixed-point convergence residual: the relative change in u*
            # over this iteration (small = converged).  DIAGNOSTIC ONLY — it does
            # not feed the fluxes, so the default (return_convergence=False) path
            # is byte-identical; it lets callers/tests detect columns where the
            # fixed n_iter under-converges (strong stability), the gap vs a
            # tolerance-based root solve (CliMA SurfaceFluxes.jl).
            resid_new = jnp.abs(u_star_new - u_star) / jnp.maximum(
                jnp.abs(u_star_new), 1e-6)

            return (u_star_new, z0_new, z0_t_new, z0_q_new,
                    theta_star_new, q_star_new, U_eff, resid_new)

        def _body_fn_dtype_stable(i, carry):
            out = body_fn(i, carry)
            return tuple(jnp.asarray(o).astype(d)
                         for o, d in zip(out, _carry_dtypes))

        carry = jax.lax.fori_loop(0, n_iter, _body_fn_dtype_stable, carry)
        u_star, z0, z0_t, z0_q, theta_star, q_star_val, U_eff_final, most_residual = carry

    # Fluxes from scaling parameters.  Stress normalization: tau =
    # -rho u*^2 u/U_eff == -rho Cd U_eff u (AeroBulk/COARE: one factor of the
    # bulk wind incl. gust/floor, one raw wind component for direction and
    # magnitude); reduces to u/|U| exactly when U_eff == wind_speed.
    # Thermodynamic convention (#762) now selects only the heat capacity:
    # 'aerobulk' = NEMO/AeroBulk moist cp_air(q); 'legoesm' = dry c_pd.  The
    # latent heat is the Kirchhoff L_v(T_sfc) in BOTH (user decision
    # 2026-09-28); an explicit ``L_latent`` always wins (ice passes L_s, the
    # OMIP NEMO-parity path and the oracle tests inject their own).
    from legoesm.thermo import latent_heat_vaporization
    _L = latent_heat_vaporization(T_sfc) if L_latent is None else L_latent
    if thermo_convention == "aerobulk":
        from legoesm.thermo import moist_air_cp
        _cp = moist_air_cp(q_atm)
    else:
        _cp = constants.c_pd
    if _coare is None:
        tau_x = -rho * u_star ** 2 * u_rel / U_eff_final
        tau_y = -rho * u_star ** 2 * v_rel / U_eff_final
        shflx = rho * _cp * u_star * theta_star
        lhflx = rho * _L * u_star * q_star_val
    else:
        # AeroBulk BULK_FORMULA structure: tau = rho Cd Ub |U| (components
        # along -u, -v: drag on the air), Q = rho cp Ch Ub (T_s - t_zu),
        # E = rho Ce Ub (q_s - q_zu), with the floored transfer coefficients and
        # the height-adjusted t_zu/q_zu; rho, cp and L are the caller's.
        _c = _coare
        tau_x = -rho * _c["Cd"] * _c["Ub"] * u_rel
        tau_y = -rho * _c["Cd"] * _c["Ub"] * v_rel
        shflx = rho * _cp * _c["Ch"] * _c["Ub"] * (T_sfc - _c["t_zu"])
        lhflx = rho * _L * _c["Ce"] * _c["Ub"] * (q_sfc - _c["q_zu"])

    # ``return_wind_speed``: the speed THIS solver put in its flux formulas
    # (U_eff incl. gustiness/floor, or AeroBulk's Ub), appended LAST, for a
    # closure that must pair it with this u* (WRF MYNN's ust**2/wspd drag).
    _wind_out = (U_eff_final,) if return_wind_speed else ()

    if return_2m:
        # Air temperature at the diagnostic height (default 2 m) from the
        # converged MOST similarity profile: T(z) = T_sfc − (θ*/κ)·[ln(z/z0t) −
        # ψ_h(z/L)], which reduces to T_atm at z=z_t.  Over a warm ocean the
        # lowest model level (~100 m at nlev=20) reads colder than 2 m, so the
        # raw lowest-level "tas" exaggerates the cold/air-sea-gap bias — this
        # gives the physically correct CMIP 2 m value.  Recompute 1/L from the
        # converged scales (the iteration carries scales, not L).
        if _coare is None:
            u_star_safe = jnp.maximum(u_star, 1e-6)
            theta_v_star = theta_star + _vT_coef * T_atm * q_star_val
            inv_L = -KAPPA * G * theta_v_star / (u_star_safe ** 2 * T_v)
            zeta_d = jnp.clip(z_diag * inv_L, -10.0, 10.0)
            _psi_h_d = psi_h(zeta_d, stability_scheme,
                             unstable_gamma=unstable_gamma, stable_beta=stable_beta)
            denom_d = jnp.log(z_diag / jnp.maximum(z0_t, 1e-12)) - _psi_h_d
            T_2m = T_sfc - (theta_star / KAPPA) * denom_d
        else:
            # coare3 / large_yeager: AeroBulk's own height shift (the t_zu
            # update of TURB_COARE3P0 / TURB_NCAR) applied from z_t to z_diag
            # with the solver's last-iteration 1/L and theta*, zeta clipped as
            # in that routine: T(z_t) = T_atm exactly.
            if scheme == "coare3":
                _zmax = _AB_COARE_ZETA_ABS_MAX

                def _ph(z):
                    return psi_h_coare(z, stability_scheme, coare_neutral_width)
            else:
                _zmax = _AB_NCAR_ZETA_ABS_MAX

                def _ph(z):
                    return psi_h(z, stability_scheme, unstable_gamma=unstable_gamma,
                                 stable_beta=stable_beta)

            def _zeta(z):
                return jnp.clip(z * _coare["inv_L"], -_zmax, _zmax)
            prf = jnp.log(z_t / z_diag) + _ph(_zeta(z_diag)) - _ph(_zeta(z_t))
            T_2m = T_atm - _coare["ts"] / KAPPA * prf
        # Guard against profile extrapolation outside [T_atm, T_sfc].
        lo = jnp.minimum(T_atm, T_sfc)
        hi = jnp.maximum(T_atm, T_sfc)
        T_2m = jnp.clip(T_2m, lo, hi)
        if return_convergence:
            return (tau_x, tau_y, shflx, lhflx, u_star, T_2m, most_residual
                    ) + _wind_out
        return (tau_x, tau_y, shflx, lhflx, u_star, T_2m) + _wind_out

    if return_convergence:
        return (tau_x, tau_y, shflx, lhflx, u_star, most_residual) + _wind_out
    return (tau_x, tau_y, shflx, lhflx, u_star) + _wind_out


def sam_ocean_surface_q(
    T_sfc: jnp.ndarray,
    p_sfc: jnp.ndarray | float,
    salt_factor: float = 0.981,
) -> jnp.ndarray:
    """SAM ocean surface saturation specific humidity (``oceflx`` ``qs``).

    SAM sets the ocean surface humidity to the SATURATION value at the SST,
    reduced by a salinity factor (``qs = salt_factor · qsat(SST, p_sfc)``,
    ``salt_factor = 0.981`` ≈ the 2 % saturation reduction over saline
    ocean water).  At SST = 300 K, p_sfc = 1014.8 hPa this is ≈ 0.0217
    kg/kg — about 20 % larger than the hardcoded ``q_sfc = 0.018`` the
    RCEMIP plane harness used, so the latent-heat flux (and the whole
    WISHE feedback / RCE moisture budget) was biased low.

    Uses the shared :func:`legoesm.thermo.saturation_specific_humidity`
    (CLAUDE.md — no re-implemented Clausius–Clapeyron).

    Parameters
    ----------
    T_sfc : array
        Sea-surface temperature [K].
    p_sfc : array or float
        Surface pressure [Pa].
    salt_factor : float
        Salinity reduction of saturation humidity (SAM default 0.981).

    Returns
    -------
    array
        Surface saturation specific humidity [kg/kg].
    """
    from legoesm.thermo import saturation_specific_humidity

    return salt_factor * saturation_specific_humidity(T_sfc, p_sfc)


def ocean_surface_q_sat(
    T_sfc: jnp.ndarray,
    p_sfc: jnp.ndarray | float,
    *,
    thermo_convention: str = "legoesm",
    bulk_scheme: str = "constant",
    saline_factor: float = 1.0,
) -> jnp.ndarray:
    """Air-sea surface saturation MIXING RATIO with the convention-appropriate
    saturation curve (#762): the single q_sfc source shared by the coupler
    ocean tile and the standalone slab ocean, so the interface humidity is no
    longer split between Goff (coupler) and Tetens (slab) on the aerobulk MOST
    path.  (The atmosphere tiled surface-layer q_sfc is a separate site tracked
    for the same unification.)

    The WMO Goff (1957) curve is used under ``thermo_convention='aerobulk'`` on
    a MOST solver scheme (``'most'``/``'coare3'``/``'large_yeager'`` — the only
    schemes carrying the NEMO/AeroBulk constant set, matching the flux-formation
    convention); every other case keeps the Tetens
    :func:`legoesm.thermo.saturation_mixing_ratio`, so the default ``legoesm``
    convention and the fixed-coefficient ``constant`` closure are byte-identical.
    ``saline_factor`` applies the salinity reduction of q_sat (0.98 for the
    coupled ocean tile; 1.0 leaves it unscaled).

    Parameters
    ----------
    T_sfc : array
        Sea-surface temperature [K].
    p_sfc : array or float
        Surface pressure [Pa].
    thermo_convention : str
        ``'legoesm'`` (Tetens) or ``'aerobulk'`` (Goff on the MOST schemes).
    bulk_scheme : str
        Surface bulk scheme; Goff engages only on the MOST solvers.
    saline_factor : float
        Salinity reduction of q_sat (1.0 = none).

    Returns
    -------
    array
        Surface saturation mixing ratio [kg/kg].
    """
    from legoesm.thermo import (
        saturation_mixing_ratio, saturation_mixing_ratio_goff)

    _use_goff = (thermo_convention == "aerobulk"
                 and bulk_scheme in ("most", "coare3", "large_yeager"))
    _sat = saturation_mixing_ratio_goff if _use_goff else saturation_mixing_ratio
    return saline_factor * _sat(T_sfc, p_sfc)


# --- CESM coupler air-sea flux law (cime5.6.47 shr_flux_mod.F90) ---
# ``seq_flux_atmocn_minwind`` namelist default (CESM2 namelist_defaults_cam.xml).
_CESM_MINWIND = 0.5
# ``flux_max_iteration`` as the CESM2.1 driver sets it (cime5.6.47
# namelist_definition_drv.xml ``flux_max_iteration`` = 5 for cesm, passed to
# ``shr_flux_adjust_constants`` by seq_flux_mct.F90); the module default of 2
# in shr_flux_mod.F90 is overridden.  With ``flux_convergence = 0.0`` (f09)
# every one of the 5 passes runs.  A loop count: never config / trainable.
_CESM_FLUX_MAX_ITER = 5
# --- cold-air-outbreak wind enhancement (Mahrt & Sun 1995, MWR) ---
# shr_flux_mod.F90 module PARAMETERS ``alpha``, ``maxscl``, ``td0``; switched on
# by ``coldair_outbreak_mod`` = .true. (CESM2.1 default for cesm,
# namelist_definition_drv.xml).
_CESM_COA_ALPHA = 1.4      # wind-scaling slope [K^-1/2 m/s]
_CESM_COA_MAXSCL = 2.0     # maximum wind scaling factor [-]
_CESM_COA_TD0 = -10.0      # tbot - ts at which the scaling starts [K]


def _sam_cdn(u10: jnp.ndarray) -> jnp.ndarray:
    """SAM/CESM neutral 10 m drag coefficient (``oceflx.f90`` ``cdn``).

    ``cdn(U) = 0.0027/U + 0.000142 + 0.0000764·U``.  ``U`` is floored at
    the SAM minimum wind ``umin = 1 m/s`` so the ``1/U`` term stays bounded
    (and AD-safe).
    """
    u = jnp.maximum(u10, 1.0)
    return _cesm_cdn(u)


def _cesm_cdn(u10: jnp.ndarray) -> jnp.ndarray:
    """CESM ``shr_flux_mod`` ``cdn(Umps)`` — the same Large & Pond fit with NO
    wind floor (the caller floors ``vmag`` at ``seq_flux_atmocn_minwind``)."""
    return 0.0027 / u10 + 0.000142 + 0.0000764 * u10


def compute_sam_oceflx_fluxes(
    u_atm: jnp.ndarray,
    v_atm: jnp.ndarray,
    theta_atm: jnp.ndarray,
    q_atm: jnp.ndarray,
    T_sfc: jnp.ndarray,
    q_sfc: jnp.ndarray,
    rho: jnp.ndarray,
    z_bot: jnp.ndarray | float,
    exner_sfc: jnp.ndarray | float = 1.0,
    wd: jnp.ndarray | float = 0.0,
    n_iter: int | None = None,
    *,
    variant: str = "sam",
    minwind: float = _CESM_MINWIND,
    return_2m: bool = False,
    z_diag: float = 2.0,
    t_bot: jnp.ndarray | None = None,
    return_wind_speed: bool = False,
) -> tuple[jnp.ndarray, ...]:
    """SAM ocean surface fluxes — faithful port of ``oceflx.f90`` (CESM1).

    ``variant`` selects the oracle (static Python string, dispatch-hardened):

    * ``"sam"`` (default, byte-identical): gSAM ``oceflx.f90`` — ``vmag``
      floored at 1 m/s, the same floor inside ``cdn``, dry ``c_pd``.
    * ``"cesm"``: CIME ``shr_flux_mod.F90::shr_flux_atmOcn`` (cime5.6.47, the
      CAM6/CESM2 coupler law) — ``vmag`` floored at ``minwind``
      (``seq_flux_atmocn_minwind``, CESM2 default 0.5 m/s), NO floor inside
      ``cdn``, and the moist ``cp = c_pd (1 + cpvir ssq)`` = ``c_pd + (c_pv -
      c_pd) q_sfc`` on the sensible heat.  Stability iteration, coefficients
      and flux algebra are otherwise identical.  The CESM2.1 driver settings
      are the defaults: ``flux_max_iteration = 5`` with ``flux_convergence =
      0`` (f09) -> ``n_iter = 5`` passes; ``gust_fac = 0``; and the
      cold-air-outbreak wind enhancement ON (``coldair_outbreak_mod``: where
      ``t_bot - T_sfc < -10 K`` the wind is scaled by ``min(1 + 1.4
      sqrt(|t_bot - T_sfc + 10|)/vmag, 2)``), which needs the ABSOLUTE
      lowest-level air temperature ``t_bot`` (required).  ``ssq`` is
      taken from ``q_sfc`` (the caller's saturation curve and salinity
      factor; CESM's own ``0.98 * 640380/exp(5107.4/T)`` fit is NOT
      re-derived here).  With ``return_2m=True`` the CESM ``tref`` 2 m
      temperature diagnostic (potential-to-temperature corrected) is appended.

    Iterative Monin–Obukhov bulk scheme with SAM's exact neutral transfer
    coefficients and Businger–Dyer stability functions:

    - ``vmag = max(1.0, sqrt(|U|² + wd²))`` — 1 m/s minimum, optional gust
      enhancement ``wd`` (SAM default 0; NOT the Wing-2018 5 m/s floor).
    - Neutral drag ``rdn² = cdn(U10)`` (:func:`_sam_cdn`).
    - Neutral Stanton ``rhn = 0.0327`` (unstable) / ``0.018`` (stable);
      neutral Dalton ``ren = 0.0346``.
    - ``n_iter`` (SAM uses 2) stability iterations: Obukhov ratio
      ``hol = κ g z (t*/θ + q*/(1/ε+q)) / u*²`` (clipped |hol|≤10), then
      the coefficients are shifted to the model level via
      ``r = rn / (1 + rn/κ·(ln(z/z_ref) − ψ))``.

    Fluxes are returned in legoESM's UPWARD-POSITIVE W/m² convention
    (surface warmer/moister ⇒ positive), matching
    :func:`simple_bulk_fluxes`:

        SHF = −ρ c_pd u* t*,   LHF = −ρ L_v u* q*,   τ = ρ u*²

    Parameters
    ----------
    u_atm, v_atm : array
        Lowest-level wind components [m/s].
    theta_atm : array
        Lowest-level POTENTIAL temperature [K] (SAM ``thbot``).
    q_atm : array
        Lowest-level specific humidity [kg/kg].
    T_sfc : array
        Surface temperature [K].  The surface POTENTIAL temperature
        ``θ_sfc = T_sfc / exner_sfc`` is formed for the sensible-heat
        gradient (Codex iter-5 HIGH: ``exner_sfc`` differs from 1 by
        ~0.4 % over the ocean ⇒ ~1 K offset in ``θ_sfc``, comparable to
        the air–sea disequilibrium and able to flip the stable/unstable
        classification near neutral — so do NOT use ``T_sfc`` as
        ``θ_sfc`` directly).
    q_sfc : array
        Surface saturation specific humidity [kg/kg] (saturation at the
        absolute SST; see :func:`sam_ocean_surface_q`).
    rho : array
        Air density at the lowest level [kg/m³].
    z_bot : array or float
        Lowest model-level height [m] (SAM ``zbot``).
    exner_sfc : array or float
        Surface Exner function ``(p_sfc/p_ref)^κ`` used to convert
        ``T_sfc`` to the surface potential temperature.  Default 1.0
        reproduces SAM's ``ts``-as-``θ`` approximation.
    wd : array or float
        Gust-enhancement wind [m/s] added in quadrature to ``vmag``
        (SAM ``wd``, default 0).
    n_iter : int or None
        Number of MO stability iterations.  None = the oracle's: 2 for
        ``"sam"``, 5 for ``"cesm"`` (CESM2.1 ``flux_max_iteration``).
    t_bot : array or None
        ``"cesm"`` only, REQUIRED there: lowest-level ABSOLUTE air
        temperature [K] (CESM ``tbot``), read by the cold-air-outbreak
        wind enhancement.  Ignored by ``"sam"``.

    Returns
    -------
    tau_x, tau_y : array
        Surface stress [Pa] (opposes wind).
    shflx : array
        Sensible heat flux [W/m²] (positive upward = surface warmer).
    lhflx : array
        Latent heat flux [W/m²] (positive upward = surface moister).
    ustar : array
        Friction velocity [m/s].
    """
    if variant not in ("sam", "cesm"):
        raise ValueError(
            f"Unknown oceflx variant {variant!r}; expected 'sam' or 'cesm'.")
    karman = KAPPA
    eps_v = 1.0 / constants.epsilon - 1.0
    z_ref = 10.0
    umin = 1.0 if variant == "sam" else minwind
    _cdn = _sam_cdn if variant == "sam" else _cesm_cdn
    if n_iter is None:
        n_iter = 2 if variant == "sam" else _CESM_FLUX_MAX_ITER
    if variant == "cesm" and t_bot is None:
        raise ValueError(
            "compute_sam_oceflx_fluxes(variant='cesm') needs t_bot, the "
            "absolute lowest-level air temperature: CESM2.1's cold-air-"
            "outbreak wind enhancement (coldair_outbreak_mod) reads tbot - ts.")

    # Safe sqrt so the calm-wind (u=v=wd=0) reverse-mode gradient stays
    # finite — bare sqrt(0) gives a 0·inf NaN even though the value is floored
    # to umin (Codex iter-5).  Double where, not an additive eps: a 1e-12 m²/s²
    # eps moved ustar by up to 1.5e-12 relative at ~1 m/s winds vs CESM.
    wind2 = u_atm ** 2 + v_atm ** 2 + wd ** 2
    windy = wind2 != 0.0   # NaN stays NaN (GLM review)
    vmag = jnp.maximum(
        umin, jnp.where(windy, jnp.sqrt(jnp.where(windy, wind2, 1.0)), 0.0)
    )
    if variant == "cesm":
        # shr_flux_atmOcn cold-air-outbreak block (use_coldair_outbreak_mod):
        # tdiff = tbot - ts; where tdiff < td0 both vmag and vmag_old (the
        # stress denominator, the same array here since gust_fac = 0) are
        # scaled by vscl.
        # The radicand is double-where'd (oracle row 57): where the block is
        # off it is replaced by 1.0 before the square root, so the unused
        # branch's d sqrt(x)/dx = inf at tdiff == td0 cannot turn the zero
        # cotangent into a NaN gradient.  Forward value unchanged: the
        # substituted branch is never selected.
        tdiff = t_bot - T_sfc
        coa_on = tdiff < _CESM_COA_TD0
        radicand = jnp.where(coa_on, jnp.abs(tdiff - _CESM_COA_TD0), 1.0)
        vscl = jnp.minimum(
            1.0 + _CESM_COA_ALPHA * (radicand ** 0.5 / jnp.abs(vmag)),
            _CESM_COA_MAXSCL)
        vmag = jnp.where(coa_on, vmag * vscl, vmag)
    theta_sfc = T_sfc / exner_sfc             # surface potential temperature
    delt = theta_atm - theta_sfc             # SAM thbot - ts (pot-T diff)
    delq = q_atm - q_sfc                      # spec-humidity diff
    alz = jnp.log(z_bot / z_ref)

    # Businger–Dyer unstable stability integrals (SAM psimhu / psixhu).
    def psimhu(xd):
        return (
            jnp.log((1.0 + xd * (2.0 + xd)) * (1.0 + xd * xd) / 8.0)
            - 2.0 * jnp.arctan(xd) + 1.571
        )

    def psixhu(xd):
        return 2.0 * jnp.log((1.0 + xd * xd) / 2.0)

    # --- neutral first guess ---
    # Fortran ``sign(0.5,x)`` treats x==0 as POSITIVE ⇒ stable=1 at exact
    # neutral; ``where(x>=0,1,0)`` matches that (0.5+0.5*sign would give
    # 0.5 — a non-SAM averaged branch).
    stable = jnp.where(delt >= 0.0, 1.0, 0.0)
    rdn = jnp.sqrt(_cdn(vmag))
    rhn = (1.0 - stable) * 0.0327 + stable * 0.018
    ren = jnp.full_like(jnp.asarray(rdn), 0.0346)
    u_star = rdn * vmag
    t_star = rhn * delt
    q_star = ren * delq

    # --- MO stability iterations (SAM does 2) ---
    # CESM: ``do while (abs((ustar-ustar_prev)/ustar) > flux_con_tol .and.
    # iter < flux_con_max_iter)`` with flux_con_tol = 0 (f09): a column stops
    # iterating once ustar repeats EXACTLY, keeping that pass's values (which
    # can differ from a further pass when the stability flag still flips).
    u_star_prev = 2.0 * u_star
    going = True
    hol = psixh = jnp.zeros_like(u_star)
    rh = rhn
    for _ in range(n_iter):
        if variant == "cesm":
            going = going & (u_star != u_star_prev)
            u_star_prev = u_star
            old = (rdn, u_star, t_star, q_star, hol, stable, rh, psixh)
        hol = (
            karman * G * z_bot
            * (t_star / theta_atm + q_star / (1.0 / eps_v + q_atm))
            / jnp.maximum(u_star ** 2, 1e-12)
        )
        # jnp.clip (not sign*min(abs)) clamps hol to [-10, 10] with the SAME
        # forward values but a SMOOTH, nonzero gradient in (-10, 10): the old
        # sign*min(abs) form has a zero-gradient flat spot at hol=0 (neutral)
        # that severs d(flux)/d(state) sensitivity there under jax.grad.
        hol = jnp.clip(hol, -10.0, 10.0)
        stable = jnp.where(hol >= 0.0, 1.0, 0.0)
        xsq = jnp.maximum(jnp.sqrt(jnp.abs(1.0 - 16.0 * hol)), 1.0)
        xqq = jnp.sqrt(xsq)
        psimh = -5.0 * hol * stable + (1.0 - stable) * psimhu(xqq)
        psixh = -5.0 * hol * stable + (1.0 - stable) * psixhu(xqq)
        # Shift wind, recompute neutral coeffs at u10n, then shift all.
        rd = rdn / (1.0 + rdn / karman * (alz - psimh))
        u10n = vmag * rd / rdn
        rdn = jnp.sqrt(_cdn(u10n))
        rhn = (1.0 - stable) * 0.0327 + stable * 0.018
        ren = jnp.full_like(jnp.asarray(rdn), 0.0346)
        rd = rdn / (1.0 + rdn / karman * (alz - psimh))
        rh = rhn / (1.0 + rhn / karman * (alz - psixh))
        re = ren / (1.0 + ren / karman * (alz - psixh))
        u_star = rd * vmag
        t_star = rh * delt
        q_star = re * delq
        if variant == "cesm":
            rdn, u_star, t_star, q_star, hol, stable, rh, psixh = (
                jnp.where(going, new, prev) for new, prev in zip(
                    (rdn, u_star, t_star, q_star, hol, stable, rh, psixh), old))

    # --- fluxes (legoESM upward-positive W/m²) ---
    tau = rho * u_star ** 2
    tau_x = -tau * u_atm / vmag
    tau_y = -tau * v_atm / vmag
    # CESM: cp = cpdair*(1 + cpvir*ssq), cpvir = cpwv/cpdair - 1.
    cp = (constants.c_pd + (constants.c_pv - constants.c_pd) * q_sfc
          if variant == "cesm" else constants.c_pd)
    shflx = -rho * cp * u_star * t_star
    lhflx = -rho * constants.L_v * u_star * q_star
    # ``return_wind_speed``: the floored speed these fluxes used (vmag),
    # appended LAST, for a closure pairing it with this u* (WRF MYNN drag).
    _wind_out = (vmag,) if return_wind_speed else ()
    if not return_2m:
        return (tau_x, tau_y, shflx, lhflx, u_star) + _wind_out
    # CESM ``tref`` (shr_flux_atmOcn diagnostics block): re-evaluate the
    # stability function at ztref, integrate the theta profile from zbot down
    # to ztref, then the 0.01 K/m potential-to-temperature correction.
    al2 = jnp.log(z_ref / z_diag)
    hol2 = hol * z_diag / z_bot
    xsq2 = jnp.maximum(1.0, jnp.sqrt(jnp.abs(1.0 - 16.0 * hol2)))
    xqq2 = jnp.sqrt(xsq2)
    psix2 = -5.0 * hol2 * stable + (1.0 - stable) * psixhu(xqq2)
    fac = (rh / karman) * (alz + al2 - psixh + psix2)
    tref = theta_atm - delt * fac - 0.01 * z_diag  # coeff-ok: CESM 0.01 K/m theta->T
    return (tau_x, tau_y, shflx, lhflx, u_star, tref) + _wind_out


@jax.custom_jvp
def sqrt_zero_subgradient(value):
    """Exact ``SQRT`` primal; finite zero subgradient at 0 (gradient-only guard)."""
    return jnp.sqrt(value)


@sqrt_zero_subgradient.defjvp
def _sqrt_zero_subgradient_jvp(primals, tangents):
    (value,), (value_dot,) = primals, tangents
    root = jnp.sqrt(value)
    safe = jnp.where(value > 0.0, root, 1.0)
    return root, jnp.where(value > 0.0, 0.5 * value_dot / safe, 0.0)


class NemoSI3BlkIce1(NamedTuple):
    wndm_ice: jax.Array
    zsipt: jax.Array
    Cd_ice: jax.Array
    Ch_ice: jax.Array
    Ce_ice: jax.Array
    theta_zu_i: jax.Array
    q_zu_i: jax.Array
    utau_ice: jax.Array   # putaui, interior (before icesbc's lbc_lnk)
    vtau_ice: jax.Array


def nemo_si3_blk_ice_1_cst(pwndi, pwndj, ptair, pqair, pslp, ptsui, rhoa, rn_Cd_ia, rn_Ch_ia, rn_Ce_ia):
    """``blk_ice_1``, constant-coefficient arm with ``ln_blk`` (``sbcblk.f90:1081-1098,1136-1139``).

    NEMO source order with source-order barriers.  ``zsipt`` (``:1086``) is
    returned although this arm never reads it (only the AN05/LU12/LG15 arms,
    ``:1102,1107,1112``, do).  Stress is NEMO's air-to-ice sign.
    """
    from legoesm.thermo import nemo_theta_exner

    wndm = sqrt_zero_subgradient(sr(sr(pwndi * pwndi) + sr(pwndj * pwndj)))   # :1082
    zsipt = nemo_theta_exner(ptsui, pslp)                                       # :1086
    cd = jnp.full_like(wndm, rn_Cd_ia)                                          # :1093
    ch = jnp.full_like(wndm, rn_Ch_ia)                                          # :1094
    ce = jnp.full_like(wndm, rn_Ce_ia)                                          # :1095
    zztmp = sr(sr(rhoa * cd) * wndm)                                            # :1137
    return NemoSI3BlkIce1(
        wndm_ice=wndm, zsipt=zsipt, Cd_ice=cd, Ch_ice=ch, Ce_ice=ce,
        theta_zu_i=jnp.asarray(ptair), q_zu_i=jnp.asarray(pqair),              # :1097-1098
        utau_ice=sr(zztmp * pwndi), vtau_ice=sr(zztmp * pwndj),                 # :1138-1139
    )


class NemoSI3IceTurbulent(NamedTuple):
    zsq: jax.Array
    zsipt: jax.Array
    dq_sat: jax.Array
    z_qsb: jax.Array
    z_dqsb: jax.Array
    qla_ice: jax.Array
    dqla_ice: jax.Array


def nemo_si3_ice_turbulent(
    ptsu, pslp, rhoa, wndm_ice, Ch_ice, Ce_ice, theta_zu_i, q_zu_i, goff_floor_width_K=0.0,
):
    """``blk_ice_2`` saturation and turbulent statements (``sbcblk.f90:1224-1225,1246-1256``).

    Elementwise; a category axis is carried by broadcasting the caller's arrays.
    ``goff_floor_width_K > 0`` smooths the 180 K saturation floor; 0 is NEMO's source order.
    """
    from legoesm.thermo import (
        nemo_si3_dq_sat_dt_ice,
        nemo_si3_q_sat_ice,
        nemo_si3_saturation_over_ice,
        nemo_theta_exner,
    )

    if goff_floor_width_K > 0.0:
        zsq, dq_sat = nemo_si3_saturation_over_ice(ptsu, pslp, goff_floor_width_K)
    else:
        zsq = nemo_si3_q_sat_ice(ptsu, pslp)                                    # :1224
        dq_sat = nemo_si3_dq_sat_dt_ice(ptsu, pslp)
    zsipt = nemo_theta_exner(ptsu, pslp)                                        # :1225
    zzblk = sr(rhoa * wndm_ice)                                                 # :1246
    zztmp1 = sr(sr(zzblk * constants.c_p_air_ice_nemo) * Ch_ice)                # :1249
    z_qsb = sr(zztmp1 * sr(zsipt - theta_zu_i))                                 # :1250
    z_dqsb = zztmp1                                                             # :1251
    zztmp1 = sr(sr(zzblk * constants.L_sub_nemo) * Ce_ice)                      # :1254
    qla = sr(zztmp1 * sr(zsq - q_zu_i))                                         # :1255
    dqla = sr(zztmp1 * dq_sat)                                                  # :1256
    return NemoSI3IceTurbulent(zsq=zsq, zsipt=zsipt, dq_sat=dq_sat, z_qsb=z_qsb, z_dqsb=z_dqsb, qla_ice=qla, dqla_ice=dqla)


def nemo_si3_constant_fluxes(
    u_air: jnp.ndarray,
    v_air: jnp.ndarray,
    theta_air: jnp.ndarray,
    q_air: jnp.ndarray,
    T_ice: jnp.ndarray,
    p_surface: jnp.ndarray,
    rho_air: jnp.ndarray,
    Cd: float,
    Ch: float,
    Ce: float,
    goff_floor_width_K: float,
) -> tuple[jnp.ndarray, ...]:
    """Executing constant-coefficient SI3 air--ice bulk core.

    Transcribes NEMO 5.0.2 ``sbcblk.F90:1085-1168,1231-1273`` and
    ``sbc_phy.F90:321-358,665-790``.  ``theta_air`` is already potential
    temperature, as at NEMO's ``blk_ice_1/2`` boundary.  Returned stress uses
    NEMO's air-to-ice sign; callers adapting to legoESM's atmospheric reaction
    convention negate it explicitly.

    Returns ``(tau_x, tau_y, wind, theta_ice, q_sat, dq_sat_dT,
    sensible, latent, dq_sensible_dT, dq_latent_dT)``.
    """
    from legoesm.thermo import nemo_si3_saturation_over_ice

    wind = jnp.sqrt(u_air * u_air + v_air * v_air)
    theta_ice = T_ice * (
        constants.p_ref / p_surface
    ) ** (constants.R_gas_molar / (constants.M_dry_air * constants.c_p_dry_air_nemo))
    q_sat, dq_sat_dT = nemo_si3_saturation_over_ice(
        T_ice, p_surface, floor_width_K=goff_floor_width_K
    )
    rho_wind = rho_air * wind
    stress_scale = rho_wind * Cd
    tau_x = stress_scale * u_air
    tau_y = stress_scale * v_air
    sensible_scale = rho_wind * constants.c_p_air_ice_nemo * Ch
    latent_scale = rho_wind * constants.L_sub_nemo * Ce
    sensible = sensible_scale * (theta_ice - theta_air)
    latent = latent_scale * (q_sat - q_air)
    dq_sensible_dT = sensible_scale
    dq_latent_dT = latent_scale * dq_sat_dT
    return (
        tau_x, tau_y, wind, theta_ice, q_sat, dq_sat_dT,
        sensible, latent, dq_sensible_dT, dq_latent_dT,
    )


def simple_bulk_fluxes(
    u_lowest: jnp.ndarray,
    v_lowest: jnp.ndarray,
    T_lowest: jnp.ndarray,
    q_lowest: jnp.ndarray,
    T_sfc: jnp.ndarray,
    q_sfc: jnp.ndarray,
    rho: jnp.ndarray,
    wind_speed: jnp.ndarray,
    Cd: float,
    Ch: float,
    L_latent: float | None = None,
) -> tuple[jnp.ndarray, jnp.ndarray, jnp.ndarray, jnp.ndarray]:
    """Simple bulk-aerodynamic surface fluxes with constant coefficients.

    Parameters
    ----------
    u_lowest, v_lowest : array
        Lowest-level wind components [m/s].
    T_lowest : array
        Lowest-level air temperature [K].
    q_lowest : array
        Lowest-level specific humidity [kg/kg].
    T_sfc : array
        Surface temperature [K].
    q_sfc : array
        Surface specific humidity [kg/kg].
    rho : array
        Air density at lowest level [kg/m3].
    wind_speed : array
        Wind speed (with minimum floor applied) [m/s].
    Cd : float
        Drag coefficient for momentum.
    Ch : float
        Transfer coefficient for heat and moisture.

    Returns
    -------
    tau_x, tau_y : array
        Surface stress [Pa] (opposes wind).
    shflx : array
        Sensible heat flux [W/m2] (positive upward = surface warmer).
    lhflx : array
        Latent heat flux [W/m2] (positive upward = surface moister).
    """
    from legoesm.thermo import latent_heat_vaporization
    _L = latent_heat_vaporization(T_sfc) if L_latent is None else L_latent
    tau_x = -rho * Cd * wind_speed * u_lowest
    tau_y = -rho * Cd * wind_speed * v_lowest
    shflx = rho * constants.c_pd * Ch * wind_speed * (T_sfc - T_lowest)
    lhflx = rho * _L * Ch * wind_speed * (q_sfc - q_lowest)
    return tau_x, tau_y, shflx, lhflx
