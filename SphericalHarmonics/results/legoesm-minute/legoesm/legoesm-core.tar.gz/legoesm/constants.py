"""Physical constants for legoESM.

All constants are in SI units unless otherwise noted.
"""

import jax.numpy as jnp

# ==============================================================================
# Fundamental Constants
# ==============================================================================
g = 9.80616                     # Gravitational acceleration [m/s^2]
Omega = 7.292e-5                # Earth rotation rate [rad/s]
R_earth = 6.371229e6            # Earth mean radius [m]

# ==============================================================================
# Dry Air Thermodynamics
# ==============================================================================
R_d = 287.05                    # Gas constant for dry air [J/(kg*K)]
c_pd = 1004.64                  # Specific heat at constant pressure [J/(kg*K)]
# Enforce the thermodynamic identity ``R_d = c_pd - c_vd`` exactly so
# the compressible Euler EOS (``pressure_from_eos``: p_0 · (R_d·ρ·θ/p_0)^(c_p/c_v))
# is consistent.  An earlier hardcoded value of 717.56 violated the
# identity by 0.03 J/(kg·K), introducing a ~0.01 % bias in p that
# compounded in tendencies.  Audit cycle iter-39 finding MEDIUM #6.
c_vd = c_pd - R_d               # Specific heat at constant volume [J/(kg*K)] = 717.59
kappa = R_d / c_pd              # Poisson constant R_d/c_pd (~0.2857)
p_ref = 1.0e5                   # Reference pressure [Pa] (1000 hPa)
p_atm_std = 101325.0            # Standard atmosphere [Pa] (1013.25 hPa)

# ==============================================================================
# Water Thermodynamics
# ==============================================================================
R_v = 461.51                    # Gas constant for water vapor [J/(kg*K)]
c_pv = 1846.0                   # Specific heat of water vapor [J/(kg*K)]
c_pw = 4218.0                   # Specific heat of liquid water [J/(kg*K)]
c_pi = 2106.0                   # Specific heat of ice [J/(kg*K)]
L_v = 2.501e6                   # Latent heat of vaporization at 0C [J/kg]
# Temperature dependence of L_v/L_s/L_f is Kirchhoff's relation from the
# specific heats above: see legoesm.thermo.latent_heat_vaporization.
L_f = 3.337e5                   # Latent heat of fusion at 0C [J/kg]
# Sublimation is DERIVED so the three latent heats close identically
# (L_s - L_v - L_f == 0); the former independent 2.834e6 disagreed by 700 J/kg.
L_s = L_v + L_f                 # Latent heat of sublimation at 0C [J/kg] (2.8347e6)
rho_water = 1000.0              # Density of liquid water [kg/m^3]
rho_ice = 917.0                 # Density of ice [kg/m^3]
rho_snow = 330.0                # Density of dry snow on sea ice [kg/m^3] (CICE default)
rho_snow_land = 250.0           # Bulk density of seasonal LAND snow [kg/m^3]: SWE -> depth for
                                # the CLM5 burial of short plants (user-chosen 2026-10-03)
rho_air = 1.225                 # Reference dry-air density at sea level [kg/m^3]
rho_ocean = 1025.0              # Reference seawater density [kg/m^3] (= ocean.eos.rho_0)
rho_ocean_nemo = 1026.0         # NEMO rau0 [kg/m^3] (phycst.F90; GYRE/DINO/ORCA all use 1026)
rho_soil_particle = 2700.0      # Mineral soil particle (quartz) density [kg/m^3] (de Vries 1963)
c_sw = 3994.0                   # Specific heat of seawater [J/(kg*K)] (Gill 1982)
c_snow = 2090.0                 # Specific heat of snow [J/(kg*K)] (≈ c_pi, CICE default)
k_ice_default = 2.04            # Thermal conductivity of pure ice [W/(m*K)]
k_snow = 0.31                   # Thermal conductivity of dry snow [W/(m*K)] (CICE default)
T_freeze = 273.15               # Freezing point of water [K]
T_min_atmosphere = 200.0        # Lower-bound floor for atmospheric temperature [K]
                                # Used as safety floor in hypsometric psl extrapolation
                                # to avoid division by near-zero T in clear-sky columns.
                                # Matches Held-Suarez T_MIN and DCMIP lower bounds.
T_freeze_ocean = 271.35         # Freezing point of seawater [K] (~-1.8 C)
T_zero_zhao_carr = 273.16       # [K] Zhao-Carr precpd temperature origin: NCAR/ccpp-physics
                                # v7.0.1 (da75531b) zhaocarr_precpd.f:348 ``tmt0 = t - 273.16``
                                # (oracle-literal; NOT T_freeze)
# Saturation specific humidity over sea water, as a fraction of the value over
# fresh water at the same temperature: the water activity of salt water at the
# ocean's typical salinity (S ~ 35 psu) lowers the saturation vapour pressure
# by ~2%.  Standard in every bulk air-sea flux algorithm (COARE 3.0, Fairall
# et al. 2003; Liu-Katsaros-Businger 1979).  Regional salinity of 33-37 psu
# moves this in the third decimal, which is why it is a constant and not a
# function of a salinity field.
q_sat_saline_fraction = 0.98
T_hom_freeze = 233.15           # Homogeneous freezing threshold [K] (~-40 C): all
                                # condensate is ice below; standard mixed-phase
                                # partition ramp spans [T_hom_freeze, T_freeze]
                                # (Pruppacher & Klett 1997; Morrison/IFS-style
                                # linear liquid fraction).
S_ice_bulk_default = 4.0        # Default bulk ice salinity [g/kg or PSU] (CICE-style)
S_ocean_ref = 34.7              # Reference ocean salinity [g/kg or PSU] (~WOA mean)
mu_ice_freeze = 0.054           # Liquidus slope / freezing-point depression [degC/PSU] (Bitz-Lipscomb 1999, CICE)
beta_ice_cond = 0.13            # Brine thermal-conductivity coefficient [W/(m*PSU)] (Untersteiner 1964; k = k0 + beta*S/T)
T_deep_ocean_ref_C = 1.5        # Global mean deep-ocean potential T [degC]
                                # (WOCE / WOA18 abyssal climatology — used as
                                # fallback fill when an interpolated profile
                                # has no valid data, e.g. below bathymetry)
S_deep_ocean_ref_psu = 34.7     # Global mean deep-ocean practical salinity
                                # [PSU] (WOCE / WOA18 abyssal climatology)
# Freshwater EOS local-parabolic fit (Kell 1975 / Jones-Harris)
T_freshwater_max_density = 277.133  # Max-density temperature [K] (~3.983 C)
rho_freshwater_curvature = 8.0e-6   # ρ-anomaly curvature [K^-2] from d²ρ/dT² at T_max

# Molar masses (g/mol) — used for CO2 ↔ mixing-ratio conversions, etc.
# Dry-air mean molar mass (CODATA / Mohr et al. 2024 = 28.96546 g/mol).
# The kg/mol forms ``M_dry`` and ``M_h2o`` (below) are derived from these
# via ``* 1e-3`` so future drift between g/mol and kg/mol forms is impossible.
M_air = 28.96546        # [g/mol] dry air (CODATA)
M_C   = 12.011          # [g/mol] atomic mass of carbon (IUPAC 2021)
M_CO2 = 44.01           # [g/mol] CO2
M_H2O = 18.01528        # [g/mol] water

# ecRad's own molar masses [g/mol] (ecRad radiation_gas_constants.F90:42-55,
# AirMolarMass and GasMolarMass), used to turn input4MIPs mole fractions into
# the mass mixing ratios the IFS hands ecRad, the exact inverse of ecRad's own
# unit conversion (vote L15a).  Not the CODATA values above, on purpose.
M_air_ecrad = 28.970
M_gas_ecrad = {
    "o3": 47.9982, "co2": 44.011, "ch4": 16.043, "n2o": 44.013,
    "cfc11": 137.3686, "cfc12": 120.914, "hcfc22": 86.469, "ccl4": 153.823,
}

# ==============================================================================
# Moisture Parameters
# ==============================================================================
epsilon = R_d / R_v              # Molecular weight ratio (~0.622)

# CAM6 Goff-Gratch saturation reference temperatures (ESCOMP/CAM
# cam_cesm2_1_rel_60, used by thermo.saturation_*_goff_gratch).
T_triple_cam = 273.16           # [K] h2otrip = shr_const_mod.F90:37 SHR_CONST_TKTRIP
T_boil_cam = 373.16             # [K] tboil, wv_saturation.F90:71

# ==============================================================================
# Cloud-microphysics material properties
# (diffusional droplet growth: Super-Droplet Method, bin/bulk condensation)
# ==============================================================================
D_vapor = 2.21e-5               # Water-vapor diffusivity in air [m^2/s]
                                # (Pruppacher & Klett 1997; CONST value)
k_air = 2.40e-2                 # Thermal conductivity of air [W/(m*K)]
                                # (Pruppacher & Klett 1997)
sigma_water = 0.0728            # Surface tension of the water-air interface [N/m]
                                # at ~293 K (Pruppacher & Klett 1997) — Kelvin
                                # curvature term in Köhler droplet growth
# CAM6 droplet-activation (ndrop.F90 ndrop_init) scheme constants: CAM evaluates
# the Kelvin term ONCE at a fixed reference temperature with its own surface
# tension, aten = 2*M_w*surften/(R*t0*rho_w) (ndrop.F90:120-122).  Distinct from
# sigma_water above on purpose (user decision 2026-10-16: keep CAM's value).
surften_cam6_activation = 0.076     # [N/m] CAM6 ndrop surften (ndrop.F90:121)
T_ref_cam6_activation = 273.0       # [K]  CAM6 ndrop t0 (ndrop.F90:120); NOT T_freeze

# ==============================================================================
# Turbulence
# ==============================================================================
# Von Kármán constant for the log-law.
# REVISIT: literature best estimates 0.38-0.41 (Andreas et al. 2006 0.387±0.003;
# Högström 1996 0.40±0.01; Bailey et al. 2014 0.40±0.02; Lee & Moser 2015 ~0.384;
# 2024 reviews argue non-universal). Kept 0.4 (user 2026-10-25) because reference
# ports (CESM, CAM, COARE, KPP, NEMO, CLM5) use 0.4; a change needs fixtures
# regenerated or per-port config.
kappa_von_karman = 0.4
lmd94_c_star = 10.0             # C*, KPP nonlocal-flux constant (Large, McWilliams &
                                # Doney 1994, Rev. Geophys.: value with eq. 19, used in eq. 20)
nemo_mxl0_z0_m = 0.1            # z0 [m] in the factorisation rn_mxl0 = kappa*z0 of NEMO's
                                # surface mixing-length minimum. NEMO itself sets the literal
                                # rn_mxl0 = 0.04 (namelist_ref, zdftke.F90; ln_mxl0 comment
                                # "F(kappa*z)"); z0 = 0.04/0.4 is inferred, not a NEMO parameter.
nu_ocean_molecular = 1.4e-6     # Molecular kinematic viscosity of seawater
                                # [m^2/s] (~10 degC; NEMO phycst/zdfiwm ``rnu``)
kappa_T_ocean_molecular = 1.4e-7  # Molecular thermal diffusivity of seawater
                                  # [m^2/s] (= nu_ocean_molecular / Pr, Pr~10;
                                  # NEMO zdfiwm lower bound on wave-driven Kz)


# ==============================================================================
# Radiation
# ==============================================================================
sigma_sb = 5.670374419e-8       # Stefan-Boltzmann constant [W/(m^2*K^4)]
S_0 = 1361.0                    # Total solar irradiance [W/m^2]

# Present-day (≈ year 2000) Earth orbital elements for the realistic
# (AMIP-II / CMIP) insolation.  Berger (1978) convention as used by CESM
# ``shr_orb_mod`` / climlab: the longitude of perihelion is measured from
# the moving vernal equinox.  Used only when orbital insolation is enabled;
# the idealized default keeps a circular orbit (eccentricity = 0).
orbital_eccentricity = 0.016704         # [-] orbital eccentricity (year ~2000)
orbital_obliquity_deg = 23.439          # [deg] obliquity of the ecliptic
orbital_long_perihelion_deg = 282.895   # [deg] longitude of perihelion from VE

# Broadband longwave emissivities — the source of truth for the CENTRALIZED
# surface-tile emissivity defaults: ``driver/config.py`` (ExperimentConfig),
# ``driver/physics_pipeline.py``, and ``land/config.py`` reference these
# (enforced by test_constants_consistency.
# test_surface_emissivity_defaults_reference_constants).  Scheme-specific
# radiation keeps its own convention (gray uses a black surface eps=1.0);
# ``ice/config.py`` independently shares the 0.97 fresh-ice value.  Sea-water
# and fresh ice/snow are near-blackbody in the thermal-IR window; generic
# land ~0.95.
emissivity_ocean = 0.97         # [-] open ocean / lake water
emissivity_ice = 0.97           # [-] fresh sea ice / fresh snow
emissivity_land = 0.95          # [-] generic land surface
# NEMO/aerobulk sea-water thermal-IR emissivity (sbc_phy.F90 ``emiss_w``),
# used in the KIRCHHOFF net-longwave form ``Q_lw = eps*(LW_down - sigma*T^4)``
# (same eps as IR absorptivity AND emissivity).  The OMIP/CORE-II faithful
# ocean forcing path uses this; ``emissivity_ocean`` (0.97, emission-only
# convention) predates it and keeps its existing consumers.
emissivity_seawater_lw = 0.98   # [-] NEMO sbc_phy emiss_w

# Seawater specific heat used by NEMO (TEOS-10, eosbn2.F90 ``rcp``).  The
# OMIP-faithful surface-flux path uses it for the precipitation/evaporation
# heat-content terms of the non-solar flux so they match NEMO bit-for-bit.
c_p_seawater = 3991.86795711963  # [J/(kg*K)] NEMO TEOS-10 rcp

# Seawater specific heat used by the Jenkins (1991) / ISOMIP+ ice-shelf
# basal-melt intercomparison (Asay-Davis et al. 2016, GMD 9, 2471-2497).
# Deliberately the ISOMIP+ reference value (distinct from Gill-1982 ``c_sw``
# and NEMO's ``c_p_seawater``) so the linearised Jenkins melt rate reproduces
# the ISOMIP+ intercomparison numbers bit-for-bit.
c_p_seawater_isomip = 3974.0     # [J/(kg*K)] Jenkins 1991 / ISOMIP+

# NEMO/aerobulk moist-air heat-capacity pair (sbc_phy.F90 rCp_dry/rCp_vap),
# used by the NCAR bulk algorithm's sensible-heat flux
# ``cp_air(q) = rCp_dry + rCp_vap*q``.  Deliberately separate from the
# atmosphere's ``c_pd`` (1004.64): these are NEMO-parity coefficients of the
# CORE-II/OMIP faithful flux path, not legoESM's atmospheric thermodynamics.
c_p_dry_air_nemo = 1005.0       # [J/(kg*K)] NEMO sbc_phy rCp_dry
c_p_vapor_nemo = 1860.0         # [J/(kg*K)] NEMO sbc_phy rCp_vap

# NEMO 5.0.2 SI3 air--ice bulk-flux constants.  These are deliberately
# separate from the atmosphere-wide constants above: sbc_phy.F90:37-62 uses
# this historical set in blk_ice_1/2, and the selectable ``nemo_si3_constant``
# path must not silently mix it with modern CODATA values.
c_p_air_ice_nemo = 1000.5       # [J/(kg*K)] sbc_phy.F90:37 rCp_air
albedo_ocean_nemo = 0.066       # [-] sbc_phy.F90:38 albo
emissivity_ice_nemo = 0.996     # [-] sbc_phy.F90:56 emiss_i
wind_floor_ice_nemo = 0.2       # [m/s] sbc_phy.F90:58
T_triple_nemo = 273.16          # [K] sbc_phy.F90:62 rtt0
sigma_sb_nemo = 5.67e-8         # [W/(m2*K4)] phycst.F90 stefan
L_sub_nemo = 2.8344e6           # [J/kg] phycst.F90 rLsub

# Goff saturation over ice, sbc_phy.F90:74-79,665-711.
goff_ice_A_nemo = -9.09718
goff_ice_B_nemo = -3.56654
goff_ice_C_nemo = 0.876793
goff_ice_D_pressure_hpa_nemo = 6.1071
T_goff_floor_nemo = 180.0       # [K]

# ORCA1-resolved SI3 surface/bulk selections used by C1D_OMIP_L3.
bulk_transfer_ice_default = 1.5e-3
bulk_transfer_ice_orca1 = 1.0e-3
ice_ocean_drag_orca1 = 5.0e-3
snow_cover_depth_nemo = 0.02    # [m] icevar.F90:1583
snow_blow_exponent_orca1 = 0.66
precip_factor_orca1 = 1.0       # [-] namsbc_blk rn_pfac
evap_factor_orca1 = 1.0         # [-] namsbc_blk rn_efac
ice_sw_clear_nemo = 0.18
ice_sw_cloudy_nemo = 0.35
ice_sw_thin_threshold_nemo = 0.1  # [m]
ice_sw_thin_inverse_nemo = 10.0   # [m-1]
ice_ocean_heat_transfer_nemo = 0.0057
ice_supercool_volume_stop_nemo = 20.0  # [m] icesbc.F90:376-381
ice_landfast_speed_stop_nemo = 5.0e-3  # [m/s] icesbc.F90:421
ice_full_cover_margin_nemo = 1.0e-3
ice_landfast_margin_nemo501 = 1.0e-2  # [-] NEMO 5.0.1 icesbc.F90:412 rn_amax - 0.01
ice_growth_thickness_stop_nemo = 3.0  # [m]

# WRF v4.8.0 Thompson microphysics (phys/module_mp_thompson.F, commit
# 06d4240ae989cc3e50af412bb472df3d9048783c) carries its OWN thermodynamic
# constants; the faithful port (microphysics/thompson_wrf.py) uses these so
# it reproduces the running scheme.  Line numbers are in that file.
R_v_wrf_thompson = 461.5         # [J/(kg*K)] :202 Rv
R_d_wrf_thompson = 287.04        # [J/(kg*K)] :204 R
c_p_wrf_thompson = 1004.0        # [J/(kg*K)] :205 Cp (times 1+0.887 q_v in use)
L_s_wrf_thompson = 2.834e6       # [J/kg] :216 lsub
L_v0_wrf_thompson = 2.5e6        # [J/kg] :217 lvap0 (lvap = lvap0 + (c_pi - c_pw) T_C)
epsilon_wrf_thompson = 0.622     # [-] literal in rho (:1234, :1802), RSLF/RSIF, t_dew
T_flatau_wrf_thompson = 273.16   # [K] Flatau et al. (1992) fit origin in RSLF/RSIF (:5398, :5433)

# ERF super-droplet physics (erf-model/ERF tag 26.09,
# 6d09aeb120eb4eac388106004bfaaa7f795a2e26) carries its OWN constants; the
# faithful SDM port (microphysics/sdm/) uses these so it reproduces the running
# scheme.  Source/ERF_Constants.H unless noted.
L_v_erf = 2.5e6                  # [J/kg] l.59 L_v (water m_lat_vap, MaterialProperties.cpp:175)
R_v_erf = 461.505                # [J/(kg*K)] l.48 R_v (water m_Rv)
g_erf = 9.81                     # [m/s^2] l.64 CONST_GRAV (TerminalVelocity.H CloudRainShima)
k_B_erf = 1.38065e-23            # [J/K] l.105 boltz (Brownian kernel)
N_A_erf_kmol = 6.02214e26        # [1/kmol] l.106 avogadro (per KILOmole)
M_air_erf = 28.966               # [kg/kmol] l.107 mwdair
sigma_water_erf = 0.076148325    # [N/m] MaterialProperties.H surfaceTension(), water
b_solute_water_erf = 4.3e-6      # [m^3/mol] MaterialProperties.H coeffVPSolute(), water
T_flatau_erf = 273.16            # [K] Flatau et al. (1992) fit origin in erf_esatw (Utils/ERF_MicrophysicsUtils.H)

# WRF v4.8.0 fast spectral-bin microphysics (phys/module_mp_fast_sbm.F, commit
# 06d4240ae989cc3e50af412bb472df3d9048783c) carries its OWN thermodynamic
# literals; the faithful FSBM building blocks (microphysics/fast_sbm/) use these
# so they reproduce the running scheme.  CGS values converted to SI exactly.
epsilon_fast_sbm = 0.622            # [-] :4596 EW1N=QQ*PP/(0.622+0.378*QQ), :2871 OPER2
one_minus_epsilon_fast_sbm = 0.378  # [-] same statements (literal, not 1-0.622)
aa1_fast_sbm = 2.53e11              # [Pa] :1724 POLYSVP AA1_MY = 2.53E12 dyn/cm^2
bb1_fast_sbm = 5.42e3               # [K] :1724 POLYSVP BB1_MY (also B5L=BB1_MY/T^2 in ONECOND1)
lv_over_cp_fast_sbm = 2500.0        # [K] :6830 ONECOND1 DATA AL1 /2500./ (T update, RW)
lf_over_cp_fast_sbm = 333.0         # [K] :6627 FREEZ / :6741 J_W_MELT ARG_1=333.*SUM_ICE/RO
R_v_fast_sbm = 461.5                # [J/(kg*K)] :1768 JERRATE_KS RV_MY=461.5D4 erg/(g*K)
L_v_fast_sbm = 2.5e6                # [J/kg] :1816 JERRATE_KS AL1_MY(1)=2.5D10 erg/g
k_air_fast_sbm = 2.4e-2             # [W/(m*K)] :1768 JERRATE_KS CF_MY=2.4D3 erg/(cm*s*K)
p_zero_fast_sbm = 101300.0          # [Pa] :1782 JERRATE_KS PZERO=1.013D6 dyn/cm^2
# WRF v4.8.0 MYNN-EDMF (phys/MYNN-EDMF/module_bl_mynnedmf.F90, submodule
# 8f8e8b59021249949c04d1686edc5a02ca325627): qsat_blend writes the vapour/dry-air
# molecular-weight ratio as a literal, not as R_d/R_v; the faithful port
# (turbulence/mynnedmf_wrf.py) uses it there.
epsilon_wrf_mynn = 0.622         # [-] qsat_blend literal

# Active no-pond ice_alb identity, icealb.F90:124-185 and accepted namalb.
albedo_snow_dry_orca1 = 0.85
albedo_snow_melt_orca1 = 0.75
albedo_ice_dry_orca1 = 0.64
albedo_ice_melt_orca1 = 0.53
albedo_ice_thin_nemo = 0.18
albedo_ice_pivot_orca1 = 1.0    # [m]
albedo_ice_thin_break_nemo = 0.05  # [m]
albedo_snow_decay_dry_nemo = 0.02  # [m]
albedo_snow_decay_melt_nemo = 0.03  # [m]
albedo_cloud_quad_nemo = -0.1010
albedo_cloud_linear_nemo = 0.1933
albedo_cloud_offset_nemo = -0.0148

# Remaining NEMO-parity constants of the CORE-II/OMIP faithful flux path
# (values verbatim from NEMO 5.0.1 phycst.F90 / sbc_phy.F90).  They differ
# from legoESM's globals in the 4th-5th digit; the faithful path uses these
# so flux-level golden tests against the NEMO formulas close exactly.
g_nemo = 9.80665                # [m/s^2]  NEMO phycst grav
# gSAM 1.8.8 gravity (SRC/consts.f90 ``ggr``).  Used only where a gSAM port
# must repeat the oracle's operations (radiation/ozone_mls.py: it cancels
# analytically there).
g_gsam = 9.79764                # [m/s^2]  gSAM consts.f90 ggr
# ecRad (OpenIFS 49r1 bundled) gravity, radiation_constants.F90:26
# ``AccelDueToGravity``; used only by the ecrad_ifs port.
g_ecrad = 9.80665               # [m/s^2]
# ecRad dry-air gas constant, radiation_constants.F90:30 ``GasConstantDryAir``
# (cloud overlap parameter from decorrelation length); ecrad_ifs port only.
R_d_ecrad = 287.058             # [J/(kg*K)]
# OpenIFS 49r1 YOMCST (arpifs/module/yomcst.F90 SETUP_CONSTANTS, LAPE=F
# branch), formed by yomcst's own expressions so the derived values carry the
# same rounding: used only by the ecrad_ifs IFS-interface port (vote IF8).
k_B_ifs = 1.380658e-23          # [J/K]      RKBOL, yomcst.F90:511
N_A_ifs = 6.0221367e23          # [1/mol]    RNAVO, :512
c_light_ifs = 299792458.0       # [m/s]      RCLUM, :509
h_planck_ifs = 6.6260755e-34    # [J s]      RHPLA, :510
M_dry_air_ifs = 28.9644         # [g/mol]    RMD, :581
M_water_ifs = 18.0153           # [g/mol]    RMV, :582
g_ifs = 9.80665                 # [m/s^2]    RG, :553
R_d_ifs = 1000.0 * (N_A_ifs * k_B_ifs) / M_dry_air_ifs   # RD = 1000*R/RMD, R = RNAVO*RKBOL (:580,:584)
R_v_ifs = 1000.0 * (N_A_ifs * k_B_ifs) / M_water_ifs     # RV = 1000*R/RMV
c_pd_ifs = 3.5 * R_d_ifs                                  # RCPD = 3.5*RD (:586)
T_triple_ifs = 273.16           # [K]        RTT, :623
L_v_ifs = 2.5008e6              # [J/kg]     RLVTT, :625
L_s_ifs = 2.8345e6              # [J/kg]     RLSTT, :626
# RSIGMA = 2*RPI**5*(RKBOL/RHPLA)**3*RKBOL/(15*RCLUM**2) (:564); integer powers
# as the repeated products gfortran expands them to.
_pi_ifs = float(jnp.pi)         # RPI = 2*ASIN(1) (:508), the same double
_pi2_ifs = _pi_ifs * _pi_ifs
_kh_ifs = k_B_ifs / h_planck_ifs
sigma_sb_ifs = (2.0 * (_pi2_ifs * _pi2_ifs * _pi_ifs) * (_kh_ifs * _kh_ifs * _kh_ifs)
                * k_B_ifs / (15.0 * (c_light_ifs * c_light_ifs)))  # [W/(m^2*K^4)]
R_v_nemo = 461.495              # [J/(kg*K)] NEMO sbc_phy R_vap (ours: 461.51)
L_fus_nemo = 0.3333601e6        # [J/kg]   NEMO phycst rLfus (ours L_f: 3.337e5)
L_fus_isf_nemo = 0.334e6        # [J/kg]   NEMO isf_oce rLfusisf (ISF melt latent
                                #          heat — deliberately NOT rLfus)
c_p_ice_nemo = 2096.7           # [J/(kg*K)] NEMO phycst rcpi (ours c_pi: 2106)
# Universal molar constants used by NEMO's barometric 10-m pressure
# (sbc_phy pres_temp): molar gas constant + dry-air/water molar masses.
R_gas_molar = 8.314510          # [J/(mol*K)] universal molar gas constant
M_dry_air = 28.9647e-3          # [kg/mol] dry-air molar mass
M_water = 18.0153e-3            # [kg/mol] water molar mass

# Broadband sea-ice / snow surface albedos used as Delta-Eddington
# fallback or for the constant-albedo configuration.  Values follow
# CICE6 conventions (Briegleb & Light 2007).  Spectral splits:
#   - VIS = 0.2–0.7 μm (visible band)
#   - NIR = 0.7–5.0 μm (near-IR band, decays faster with melt / wetness)
alpha_snow_cold_vis = 0.98      # Dry cold snow, visible band
alpha_snow_cold_nir = 0.70      # Dry cold snow, near-IR band
alpha_snow_melt_vis = 0.80      # Melting snow, visible band
alpha_snow_melt_nir = 0.55      # Melting snow, near-IR band
alpha_ice_cold_vis = 0.78       # Bare cold sea ice, visible band
alpha_ice_cold_nir = 0.36       # Bare cold sea ice, near-IR band
alpha_ice_melt_vis = 0.68       # Melting bare ice, visible band
alpha_ice_melt_nir = 0.30       # Melting bare ice, near-IR band
alpha_pond_max_vis = 0.27       # Deep melt pond, visible band (Briegleb-Light)
alpha_pond_max_nir = 0.07       # Deep melt pond, near-IR band
i0_vis = 0.70                   # Fraction of incident VIS that penetrates bare ice
i0_nir = 0.0                    # NIR has negligible penetration

# Broadband (VIS+NIR integrated) surface shortwave albedos for the coarse OMIP
# ocean-only SW-reduction surrogate (no spectral split): the effective albedo at
# a cell is alpha_ocean_broadband*(1-siconc) + alpha_ice_broadband_cold*siconc,
# with siconc the prescribed sea-ice concentration.  The open-ocean value is the
# broadband reflectance that was previously MISSING (the ocean absorbed 100% of
# downwelling SW); the sea-ice value is the snow-free-to-snow broadband mean
# (CICE6 / Briegleb-Light, ~mean of the cold VIS/NIR ice+snow albedos above).
alpha_ocean_broadband = 0.06        # [-] open-ocean broadband albedo
alpha_ice_broadband_cold = 0.65     # [-] cold (snow-covered) sea-ice broadband
alpha_ice_broadband_warm = 0.45     # [-] melting sea-ice broadband (phase-2 blend)

# ==============================================================================
# Molecular Weights (kg/mol)
# ==============================================================================
# These are needed by forcing loaders to convert between mass-mixing-ratio
# (kg/kg) and volume-mixing-ratio (mol/mol) when an external file uses
# one convention and the radiation kernel expects the other.  CMIP6
# input4MIPs ozone uses ``vmro3`` in mol/mol (no conversion required), but
# older NCAR/E3SM pathways supply ``tro3`` in kg/kg, which has to be
# multiplied by ``M_dry / M_o3`` to land back in mol/mol before the
# radiation solver consumes it.  Values are derived from the g/mol forms
# above via ``* 1e-3`` so the two views never drift.
M_dry = M_air * 1e-3            # [kg/mol] = 0.02896546 (CODATA dry air)
M_o3 = 0.0479982                # [kg/mol] ozone (NIST CODATA / IUPAC)
M_h2o = M_H2O * 1e-3            # [kg/mol] = 0.01801528 (water)

# Avogadro's number (CODATA 2019 SI redefinition — exact value).
N_A = 6.02214076e23             # [1/mol] particles per mole

# Universal gas constant (CODATA 2018 / SI redefinition — exact).
# Used by biochemistry / photosynthesis (Arrhenius temperature factors)
# and any other code that needs R independent of a specific gas (R_d,
# R_v are gas-specific = R / M).
R_universal = 8.314462618       # [J/(mol·K)] ≈ N_A·k_B (value truncated at
                                # 10 digits; exact product is 8.31446261815324)
# Boltzmann constant — exact by SI definition (2019 redefinition). Defined as
# its own literal rather than R_universal/N_A because the R_universal literal
# above is truncated (deriving would be off by ~2e-11 relative).
k_B = 1.380649e-23              # [J/K] (exact, SI)

# Planck constant and speed of light — exact by the 2019 SI redefinition.
# Needed to convert a spectral radiance / irradiance [W/m^2] into a photon flux
# [mol photons / m^2 / s] through the photon energy E = h*c/lambda — e.g. the
# satellite-SIF radiance -> emitted-photon-flux conversion in
# scripts/data/build_sif_observations.py (and any PAR / quantum-yield code).
h_planck = 6.62607015e-34       # [J·s]  Planck constant        (exact, SI 2019)
c_light = 2.99792458e8          # [m/s]  speed of light in vacuum (exact, SI)

# ==============================================================================
# Mathematical Constants
# ==============================================================================
PI = jnp.pi
TWO_PI = 2.0 * jnp.pi
DEG_TO_RAD = jnp.pi / 180.0
RAD_TO_DEG = 180.0 / jnp.pi

# ==============================================================================
# Turbulence
# ==============================================================================
nu_air = 1.5e-5                 # Kinematic viscosity of air at 15°C [m^2/s]
prandtl_air = 0.71              # Molecular Prandtl number of air ν/α [-] (DNS
                                # heat diffusion κ = ν / Pr). Schmidt number of
                                # water vapour in air is ~0.6 (close); reuse this
                                # for the DNS scalar leg unless set separately.

# ==============================================================================
# Shallow Water Test Case Constants
# ==============================================================================
H_MEAN = 1.0e4                  # Mean fluid depth for shallow water [m]

# ==============================================================================
# CLM-ml multilayer canopy (CLM-ml v1 Fortran oracle)
# ==============================================================================
lapse_rate_clmml = 0.0098       # [K/m] MLclm_varcon.F90:26 lapse_rate (CLM-ml v1);
                                # NOT g/c_pd (0.00976): the oracle value is used for
                                # the reference-height potential temperature.
