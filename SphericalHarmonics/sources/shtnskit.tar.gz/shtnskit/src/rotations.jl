#=
================================================================================
rotations.jl - Rotations of Spherical Harmonic Expansions
================================================================================

This file implements rotation operations on spherical harmonic coefficients.
Rotations can be applied directly in spectral space without going through
physical space, which is efficient for rotating fields on the sphere.

WHY SPECTRAL ROTATIONS?
-----------------------
Rotating a function on the sphere in physical space requires:
1. Synthesize to grid: O((lmax)² × nlon)
2. Interpolate to new grid positions: O(nlat × nlon)
3. Analyze back: O((lmax)² × nlon)

Spectral rotation is more direct:
- Rotation of Y_l^m produces a linear combination of Y_l^{m'} for |m'| ≤ l
- The mixing is given by Wigner-d matrices d^l_{mm'}(β)
- Complexity: O((lmax)³) but exact with no interpolation errors

EULER ANGLE CONVENTIONS
-----------------------
Rotations are specified using Euler angles (α, β, γ) in either:
- ZYZ convention (default): R = Rz(α) Ry(β) Rz(γ)
- ZXZ convention: R = Rz(α) Rx(β) Rz(γ)

Special cases implemented efficiently:
- Z-rotation: Just phase multiplication (m-dependent), O(nlm)
- Y-rotation: Requires full Wigner-d matrix application
- 90° rotations: Common in coordinate transformations

WIGNER-D MATRICES
-----------------
The little Wigner-d matrix d^l_{mm'}(β) gives the transformation of
spherical harmonics under rotation by angle β about the y-axis:

    R_y(β) Y_l^m = Σ_{m'} d^l_{m m'}(β) Y_l^{m'}

Full rotation R(α,β,γ) in ZYZ convention:
    a'_{lm} = Σ_{m'} e^{-imα} d^l_{mm'}(β) e^{-im'γ} a_{lm'}

FUNCTIONS
---------
Fast axis rotations:
    SH_Zrotate(cfg, Qlm, α, Rlm)     : Z-axis rotation (very fast)
    SH_Yrotate(cfg, Qlm, α, Rlm)     : Y-axis rotation
    SH_Xrotate90(cfg, Qlm, Rlm)      : X-axis 90° rotation
    SH_Yrotate90(cfg, Qlm, Rlm)      : Y-axis 90° rotation

General rotations:
    SHTRotation                       : Rotation specification struct
    shtns_rotation_set_angles_ZYZ     : Set Euler angles (ZYZ)
    shtns_rotation_apply_real         : Apply to real-field coefficients
    shtns_rotation_apply_cplx         : Apply to complex-field coefficients

Wigner-d computation:
    wigner_d_matrix(l, β)            : Compute d^l_{mm'}(β) matrix
    wigner_d_matrix_deriv(l, β)      : Derivative ∂d^l/∂β

USAGE EXAMPLE
-------------
```julia
cfg = create_gauss_config(32, 64)
Qlm = pack_alm(cfg, alm)  # Original coefficients
Rlm = similar(Qlm)        # Output

# Z-rotation by 45°
SH_Zrotate(cfg, Qlm, π/4, Rlm)

# General rotation using Euler angles
rot = SHTRotation(cfg.lmax, cfg.mmax)
shtns_rotation_set_angles_ZYZ(rot, α=π/6, β=π/3, γ=π/4)
shtns_rotation_apply_real(rot, Qlm, Rlm)
```

DEBUGGING
---------
```julia
# Z-rotation should just multiply by exp(-imα)
# For m=2 mode, rotation by α should multiply by exp(-2iα)
rot_coeff = Rlm[idx] / Qlm[idx]  # where idx is a mode with m=2
@assert rot_coeff ≈ cis(-2 * α)
```

================================================================================
=#

"""
Rotations of spherical harmonic expansions.

Currently supports fast rotation around the Z-axis by angle `alpha` in radians.
"""

"""
    SH_Zrotate(cfg::SHTConfig, Qlm::AbstractVector{<:Complex}, alpha::Real, Rlm::AbstractVector{<:Complex})

Rotate a real-field SH expansion around the Z-axis by angle `alpha`.
Input and output are packed `Qlm` vectors (LM order, m ≥ 0). In-place supported if `Rlm === Qlm`.

# Sign convention

`R_lm = Q_lm · exp(-i m α)`. This is the **active** rotation of the field by `+α`
about `ẑ`: the rotated field is `g(θ, φ) = f(θ, φ - α)`. Equivalently, a feature
at longitude `φ₀` moves to `φ₀ + α`.

Three things pin this sign and would all break if it were flipped to `+imα`
(which is the *passive* convention, `f(θ, φ + α)`):

  * the spatial rotation above, verified directly in
    `test/serial/test_rotations.jl` against an FFT-grid φ shift;
  * the general Wigner engine — `shtns_rotation_apply_real` with
    `ZYZ(α, 0, 0)` (or `ZYZ(0, 0, α)`) must equal this function, and it builds
    `diag(e^{-imα}) · d(β) · diag(e^{-imγ})`;
  * the distributed twins `dist_SH_Zrotate` and every rotation `rrule`.
"""
function SH_Zrotate(::CPU, cfg::SHTConfig, Qlm::AbstractVector{<:Complex},
                    alpha::Real, Rlm::AbstractVector{<:Complex})
    _require_cpu_storage(:SH_Zrotate, Qlm)
    _require_cpu_storage(:SH_Zrotate, Rlm)
    length(Qlm) == cfg.nlm || throw(DimensionMismatch("Qlm length must be nlm=$(cfg.nlm)"))
    length(Rlm) == cfg.nlm || throw(DimensionMismatch("Rlm length must be nlm=$(cfg.nlm)"))
    isfinite(alpha) || throw(ArgumentError("rotation angle must be finite"))
    lmax = cfg.lmax; mres = cfg.mres
    @inbounds for m in 0:cfg.mmax
        (m % mres == 0) || continue
        phase = cis(-m * alpha)
        for l in m:lmax
            lm = LM_index(lmax, mres, l, m) + 1
            Rlm[lm] = Qlm[lm] * phase
        end
    end
    return Rlm
end

SH_Zrotate(cfg::SHTConfig, Qlm::AbstractVector{<:Complex}, alpha::Real,
           Rlm::AbstractVector{<:Complex}) =
    SH_Zrotate(CPU(), cfg, Qlm, alpha, Rlm)

"""
    struct SHTRotation
Holds Euler angles and target sizes for rotation.
- `lmax, mmax`: degrees/orders supported by the rotation.
- `α, β, γ`: Euler angles (ZYZ by default) in radians.
- `conv`: `:ZYZ` or `:ZXZ` convention.
"""
Base.@kwdef mutable struct SHTRotation
    lmax::Int
    mmax::Int
    α::Float64 = 0.0
    β::Float64 = 0.0
    γ::Float64 = 0.0
    conv::Symbol = :ZYZ
    norm::Symbol = :orthonormal
    cs_phase::Bool = true
    real_norm::Bool = false
    # SHTns' setter arguments name intrinsic rotations in call order, while
    # the coefficient kernel consumes the outer Z factors in reverse order.
    # Direct constructors retain the package's historical matrix convention.
    reverse_outer::Bool = false
end

# Convenient outer constructor with keyword defaults (to mirror SHTns usage)
function SHTRotation(lmax::Integer, mmax::Integer; α::Real=0.0, β::Real=0.0,
                     γ::Real=0.0, conv::Symbol=:ZYZ,
                     norm::Symbol=:orthonormal, cs_phase::Bool=true,
                     real_norm::Bool=false)
    lmax ≥ 0 || throw(ArgumentError("lmax must be nonnegative"))
    0 ≤ mmax ≤ lmax || throw(ArgumentError("mmax must satisfy 0 ≤ mmax ≤ lmax"))
    conv in (:ZYZ, :ZXZ) || throw(ArgumentError("conv must be :ZYZ or :ZXZ"))
    norm in (:orthonormal, :fourpi, :schmidt) ||
        throw(ArgumentError("unsupported rotation normalization: $norm"))
    all(isfinite, (α, β, γ)) || throw(ArgumentError("rotation angles must be finite"))
    return SHTRotation(Int(lmax), Int(mmax), float(α), float(β), float(γ),
                       conv, norm, cs_phase, real_norm, false)
end

# Preserve the pre-convention positional constructor generated by the original
# six-field public struct.
SHTRotation(lmax::Integer, mmax::Integer, α::Real, β::Real, γ::Real,
            conv::Symbol) =
    SHTRotation(lmax, mmax; α, β, γ, conv)

"""
    SH_Yrotate(cfg::SHTConfig, Qlm::AbstractVector{<:Complex}, alpha::Real, Rlm::AbstractVector{<:Complex})

Rotate a real-field SH expansion around the Y-axis by angle `alpha`.
Uses Wigner-d mixing per l; dispatches to the general rotation engine.
"""
function SH_Yrotate(::CPU, cfg::SHTConfig, Qlm::AbstractVector{<:Complex},
                    alpha::Real, Rlm::AbstractVector{<:Complex})
    _require_cpu_storage(:SH_Yrotate, Qlm)
    _require_cpu_storage(:SH_Yrotate, Rlm)
    length(Qlm) == cfg.nlm || throw(DimensionMismatch("Qlm length must be nlm=$(cfg.nlm)"))
    length(Rlm) == cfg.nlm || throw(DimensionMismatch("Rlm length must be nlm=$(cfg.nlm)"))
    cfg.mres == 1 || throw(ArgumentError(
        "SH_Yrotate requires mres==1 (got mres=$(cfg.mres)); a Y-rotation mixes orders and cannot be represented in an mres-strided layout",
    ))
    r = SHTRotation(cfg.lmax, cfg.mmax)
    shtns_rotation_set_angles_ZYZ(r, 0.0, float(alpha), 0.0)
    canonical = _uses_canonical_convention(cfg) ? Qlm :
        convert_alm_norm!(similar(Qlm), Qlm, cfg; to_internal=true)
    shtns_rotation_apply_real(CPU(), r, canonical, Rlm)
    return _externalize_coefficients!(Rlm, cfg)
end


SH_Yrotate(cfg::SHTConfig, Qlm::AbstractVector{<:Complex}, alpha::Real,
           Rlm::AbstractVector{<:Complex}) =
    SH_Yrotate(CPU(), cfg, Qlm, alpha, Rlm)

"""
    SH_Yrotate90(cfg::SHTConfig, Qlm::AbstractVector{<:Complex}, Rlm::AbstractVector{<:Complex})
"""
SH_Yrotate90(::CPU, cfg::SHTConfig, Qlm::AbstractVector{<:Complex},
             Rlm::AbstractVector{<:Complex}) =
    SH_Yrotate(CPU(), cfg, Qlm, π/2, Rlm)
SH_Yrotate90(cfg::SHTConfig, Qlm::AbstractVector{<:Complex},
             Rlm::AbstractVector{<:Complex}) =
    SH_Yrotate90(CPU(), cfg, Qlm, Rlm)

"""
    SH_Xrotate90(cfg::SHTConfig, Qlm::AbstractVector{<:Complex}, Rlm::AbstractVector{<:Complex})

Rotate around X-axis by 90 degrees using ZYZ equivalence: Rz(π/2)·Ry(π/2)·Rz(-π/2).
"""
function SH_Xrotate90(::CPU, cfg::SHTConfig, Qlm::AbstractVector{<:Complex},
                      Rlm::AbstractVector{<:Complex})
    _require_cpu_storage(:SH_Xrotate90, Qlm)
    _require_cpu_storage(:SH_Xrotate90, Rlm)
    length(Qlm) == cfg.nlm || throw(DimensionMismatch("Qlm length must be nlm=$(cfg.nlm)"))
    length(Rlm) == cfg.nlm || throw(DimensionMismatch("Rlm length must be nlm=$(cfg.nlm)"))
    cfg.mres == 1 || throw(ArgumentError(
        "SH_Xrotate90 requires mres==1 (got mres=$(cfg.mres)); an X-rotation mixes orders and cannot be represented in an mres-strided layout",
    ))
    r = SHTRotation(cfg.lmax, cfg.mmax)
    # Setters use intrinsic call order, so `_rotation_zyz_angles` reverses the
    # outer factors to (-π/2, π/2, π/2), matching the angle-axis extractor.
    shtns_rotation_set_angles_ZYZ(r, π/2, π/2, -π/2)
    canonical = _uses_canonical_convention(cfg) ? Qlm :
        convert_alm_norm!(similar(Qlm), Qlm, cfg; to_internal=true)
    shtns_rotation_apply_real(CPU(), r, canonical, Rlm)
    return _externalize_coefficients!(Rlm, cfg)
end

SH_Xrotate90(cfg::SHTConfig, Qlm::AbstractVector{<:Complex},
             Rlm::AbstractVector{<:Complex}) =
    SH_Xrotate90(CPU(), cfg, Qlm, Rlm)

"""
    shtns_rotation_set_angle_axis(r::SHTRotation, theta::Real, Vx::Real, Vy::Real, Vz::Real)

Define rotation from angle-axis (theta around vector V).
Angles are set in ZYZ convention.
"""
function shtns_rotation_set_angle_axis(r::SHTRotation, theta::Real, Vx::Real, Vy::Real, Vz::Real)
    all(isfinite, (theta, Vx, Vy, Vz)) ||
        throw(ArgumentError("rotation angle and axis must be finite"))
    θ = float(theta)
    v = collect(float.((Vx, Vy, Vz)))
    n = hypot(v[1], hypot(v[2], v[3]))
    if n == 0
        r.α = 0.0; r.β = 0.0; r.γ = 0.0; r.conv = :ZYZ; r.reverse_outer = false
        return nothing
    end
    kx, ky, kz = v ./ n
    c = cos(θ); s = sin(θ); t = 2sin(θ / 2)^2
    
    # Rotation matrix R = c I + s [k]_x + t k k^T
    R11 = c + t*kx*kx
    R12 = t*kx*ky - s*kz
    R13 = t*kx*kz + s*ky
    R21 = t*ky*kx + s*kz
    R22 = c + t*ky*ky
    R23 = t*ky*kz - s*kx
    R31 = t*kz*kx - s*ky
    R32 = t*kz*ky + s*kx
    R33 = c + t*kz*kz
    
    # Extract ZYZ Euler angles
    # For R = Rz(α)Ry(β)Rz(γ): R13 = cα*sβ, R23 = sα*sβ, R31 = -sβ*cγ, R32 = sβ*sγ
    # acos(R33) loses small tilts when cos(theta) rounds to one. The
    # off-diagonal entries retain their first-order signal, including for
    # Float32 angles, so use them to recover beta and resolve the outer
    # angles whenever the tilt is nonzero. At beta=pi, preserve the canonical
    # gamma=0 representation despite the sine's roundoff-sized residual.
    sinβ = hypot(R13, R23)
    β = atan(sinβ, R33)
    at_pi = R33 < 0 && sinβ <= 2eps(typeof(θ))
    if sinβ > 0 && !at_pi
        α = atan(R23, R13)    # atan2(sα*sβ, cα*sβ) = α
        γ = atan(R32, -R31)   # atan2(sβ*sγ, sβ*cγ) = γ
    elseif R33 > 0
        # β ≈ 0: only α+γ is identifiable. Choose γ=0.
        α = atan(R21, R11)
        γ = zero(β)
    else
        # β ≈ π: only α-γ is identifiable. With γ=0 the ZYZ matrix has
        # R11=-cos(α), R12=-sin(α), so extract that difference directly.
        α = atan(-R12, -R11)
        γ = zero(β)
    end
    r.α = α; r.β = β; r.γ = γ; r.conv = :ZYZ; r.reverse_outer = false
    return nothing
end

"""
    wigner_d_matrix!(d::AbstractMatrix{Float64}, l::Int, beta::Float64)

In-place computation of little Wigner-d matrix d^l_{m m'}(β). Writes into the
top-left (2l+1)×(2l+1) block of `d`. Caller must ensure `size(d,1) ≥ 2l+1`.
"""
function wigner_d_matrix!(d::AbstractMatrix{T}, l::Int, beta::Real) where {T<:AbstractFloat}
    l ≥ 0 || throw(ArgumentError("l must be ≥ 0"))
    work = Matrix{T}(undef, 2l + 1, 2l + 1)
    return _wigner_d_matrix_stable!(d, work, l, T(beta))
end

"""
    wigner_d_matrix!(d, l, beta, lg)

Compatibility overload for callers that supplied the former log-factorial
scratch buffer. The stable recurrence no longer consumes those values.
"""
function wigner_d_matrix!(d::AbstractMatrix{T}, l::Int, beta::Real,
                          lg::AbstractVector{T}) where {T<:AbstractFloat}
    l ≥ 0 || throw(ArgumentError("l must be ≥ 0"))
    length(lg) ≥ 2l + 1 || throw(ArgumentError("lg must have length ≥ 2l+1"))
    work = Matrix{T}(undef, 2l + 1, 2l + 1)
    return _wigner_d_matrix_stable!(d, work, l, T(beta))
end

"""Scratch-matrix overload used by repeated rotations."""
function wigner_d_matrix!(d::AbstractMatrix{T}, l::Int, beta::Real,
                          work::AbstractMatrix{T}) where {T<:AbstractFloat}
    l ≥ 0 || throw(ArgumentError("l must be ≥ 0"))
    return _wigner_d_matrix_stable!(d, work, l, T(beta))
end

"""
Build `dˡ(β)` by repeatedly coupling the current representation with spin 1/2.

The Clebsch--Gordan recurrence only combines bounded rotation entries with
coefficients in `[0,1]`; unlike the factorial sum, it never forms huge terms
that must cancel to produce an O(1) answer.
"""
function _wigner_d_matrix_stable!(d::AbstractMatrix{T},
                                  work::AbstractMatrix{T},
                                  l::Int, beta::T) where {T<:AbstractFloat}
    n = 2l + 1
    size(d, 1) ≥ n && size(d, 2) ≥ n ||
        throw(DimensionMismatch("d must contain a (2l+1)×(2l+1) block"))
    size(work, 1) ≥ n && size(work, 2) ≥ n ||
        throw(DimensionMismatch("work must contain a (2l+1)×(2l+1) block"))

    d[1, 1] = one(T)
    l == 0 && return d

    cb = cos(beta / T(2))
    sb = sin(beta / T(2))
    src = d
    dest = work

    # `two_j_new` grows 0 -> 1/2 -> 1 -> ... -> l.
    for two_j_new in 1:(2l)
        _wigner_half_step!(dest, src, two_j_new, cb, sb)
        src, dest = dest, src
    end

    # There are 2l (an even number of) half-steps, so the final result is in d.
    return d
end

"""
One spin-1/2 coupling step of the recurrence: `dest` receives `d^{J}(β)` from
`d^{J-1/2}(β)` in `src`, where `two_j_new = 2J` and `(cb, sb) = (cos β/2, sin β/2)`.
Only the leading `(2J+1)×(2J+1)` block of `dest` and `(2J)×(2J)` block of `src`
are touched.
"""
@inline function _wigner_half_step!(dest::AbstractMatrix{T}, src::AbstractMatrix{T},
                                    two_j_new::Int, cb::T, sb::T) where {T<:AbstractFloat}
    # Rows/columns are ordered s=-1/2,+1/2, matching this file's convention.
    dhalf = (cb, sb, -sb, cb)
    # Coupling coefficients are sqrt((J ± M)/(2J)); doubled integer indices
    # avoid half-integer arithmetic.
    two_j_old = two_j_new - 1
    denom = T(2two_j_new)
    @inbounds for i in 0:two_j_new
        two_m = -two_j_new + 2i
        for j in 0:two_j_new
            two_mp = -two_j_new + 2j
            acc = zero(T)
            for si in 1:2
                two_s = 2si - 3
                two_m_old = two_m - two_s
                abs(two_m_old) ≤ two_j_old || continue
                old_i = (two_m_old + two_j_old) ÷ 2 + 1
                ci = sqrt(T(two_j_new + two_s * two_m) / denom)
                for sj in 1:2
                    two_sp = 2sj - 3
                    two_mp_old = two_mp - two_sp
                    abs(two_mp_old) ≤ two_j_old || continue
                    old_j = (two_mp_old + two_j_old) ÷ 2 + 1
                    cj = sqrt(T(two_j_new + two_sp * two_mp) / denom)
                    dh = dhalf[2(si - 1) + sj]
                    acc += ci * cj * src[old_i, old_j] * dh
                end
            end
            dest[i + 1, j + 1] = acc
        end
    end
    return dest
end

"""
    _wigner_d_advance!(d, work, l, beta) -> d

Advance the leading block of `d` from `d^{l-1}(β)` to `dˡ(β)`; `l == 0` starts
the sequence. `work` is scratch of the same size.

Rebuilding every `dˡ` from `d⁰` replays `2l` half-steps of `O(l²)` each, so a
loop over `l = 0:lmax` costs `O(lmax⁴)`. The half-step chain passes through each
integer degree, so a loop that visits `l = 0, 1, 2, …` in order with the same
buffers only needs the two newest steps: `O(l²)` per degree, `O(lmax³)` per
sweep, the same order as applying the matrices. The result is bitwise identical
to `wigner_d_matrix(l, β)` because it runs the very same arithmetic.
"""
function _wigner_d_advance!(d::AbstractMatrix{T}, work::AbstractMatrix{T},
                            l::Int, beta::T) where {T<:AbstractFloat}
    if l == 0
        d[1, 1] = one(T)
        return d
    end
    n = 2l + 1
    size(d, 1) ≥ n && size(d, 2) ≥ n && size(work, 1) ≥ n && size(work, 2) ≥ n ||
        throw(DimensionMismatch("d and work must contain a (2l+1)×(2l+1) block"))
    cb = cos(beta / T(2))
    sb = sin(beta / T(2))
    _wigner_half_step!(work, d, 2l - 1, cb, sb)
    _wigner_half_step!(d, work, 2l, cb, sb)
    return d
end

"""
    wigner_d_matrix(l::Int, beta::Float64) -> Matrix{Float64}

Compute little Wigner-d matrix d^l_{m m'}(β) with m,m' in [-l..l], returned as a
(2l+1)×(2l+1) real matrix where index is `m+l+1, m'+l+1`.
"""
function wigner_d_matrix(l::Int, beta::T) where {T<:AbstractFloat}
    n = 2l + 1
    d = Matrix{T}(undef, n, n)
    return wigner_d_matrix!(d, l, beta)
end

"""
    WignerCache(lmax::Int, β::Real) -> WignerCache

Precompute Wigner-d matrices `d^l(β)` for `l = 0:lmax` and hand them out via
[`wigner_d(cache, l)`]. Reuse across many rotations at fixed β (e.g.
time-stepping), amortizing the per-call construction cost.
"""
struct WignerCache
    β::Float64
    matrices::Vector{Matrix{Float64}}
end

function WignerCache(lmax::Int, β::Real)
    lmax ≥ 0 || throw(ArgumentError("lmax must be ≥ 0"))
    βf = float(β)
    mats = Vector{Matrix{Float64}}(undef, lmax + 1)
    d = Matrix{Float64}(undef, 2lmax + 1, 2lmax + 1)
    work = similar(d)
    for l in 0:lmax
        _wigner_d_advance!(d, work, l, Float64(βf))
        mats[l + 1] = d[1:(2l + 1), 1:(2l + 1)]
    end
    return WignerCache(βf, mats)
end

"""
    wigner_d(cache::WignerCache, l::Int) -> Matrix{Float64}

Retrieve cached `d^l(β)`. Errors if `l` exceeds the cache's `lmax`.
"""
@inline function wigner_d(cache::WignerCache, l::Int)
    (0 ≤ l < length(cache.matrices)) || throw(ArgumentError("l=$l outside cache (lmax=$(length(cache.matrices) - 1))"))
    return cache.matrices[l + 1]
end

"""
    wigner_d_matrix_deriv(l::Int, beta::Float64) -> Matrix{Float64}

Derivative d/dβ of little Wigner-d matrix d^l_{m m'}(β).
"""
function wigner_d_matrix_deriv(l::Int, beta::T) where {T<:AbstractFloat}
    l ≥ 0 || throw(ArgumentError("l must be ≥ 0"))
    n = 2l + 1
    return _wigner_d_deriv!(Matrix{T}(undef, n, n), wigner_d_matrix(l, beta), l)
end

"""
    _wigner_d_deriv!(dβ, d, l) -> dβ

Write `∂dˡ/∂β` into the leading `(2l+1)×(2l+1)` block of `dβ`, given `dˡ(β)` in
the leading block of `d`, so a loop that advances `d` with `_wigner_d_advance!`
gets the derivative without rebuilding `dˡ`.
"""
function _wigner_d_deriv!(dβ::AbstractMatrix{T}, d::AbstractMatrix{T},
                          l::Int) where {T<:AbstractFloat}
    half = inv(T(2))
    # d(β)=exp(βG), where G is the real skew-symmetric y-rotation
    # generator. Therefore ḋ=Gd, which is stable and O(l²) once d is known.
    @inbounds for m in -l:l, mp in -l:l
        value = zero(T)
        if m > -l
            value -= half * sqrt(T((l + m) * (l - m + 1))) *
                     d[m + l, mp + l + 1]
        end
        if m < l
            value += half * sqrt(T((l - m) * (l + m + 1))) *
                     d[m + l + 2, mp + l + 1]
        end
        dβ[m + l + 1, mp + l + 1] = value
    end
    return dβ
end

"""
    shtns_rotation_create(lmax::Integer, mmax::Integer, norm::Integer) -> SHTRotation
"""
function shtns_rotation_create(lmax::Integer, mmax::Integer, norm::Integer)
    value = Int(norm)
    base = value & 0xff
    normalization = base == 0 ? :orthonormal :
                    base == 1 ? :fourpi :
                    base == 2 ? :schmidt :
                    throw(ArgumentError("unsupported SHTns normalization code: $base"))
    supported = 0xff | (256 * 4) | (256 * 8)
    value & ~supported == 0 || throw(ArgumentError(
        "rotation normalization contains unsupported flags",
    ))
    return SHTRotation(
        Int(lmax), Int(mmax); norm=normalization,
        cs_phase=(value & (256 * 4)) == 0,
        real_norm=(value & (256 * 8)) != 0,
    )
end

"""shtns_rotation_destroy(r::SHTRotation)"""
shtns_rotation_destroy(::SHTRotation) = nothing

"""shtns_rotation_set_angles_ZYZ(r, alpha, beta, gamma)"""
function shtns_rotation_set_angles_ZYZ(r::SHTRotation, alpha::Real, beta::Real, gamma::Real)
    all(isfinite, (alpha, beta, gamma)) || throw(ArgumentError("rotation angles must be finite"))
    r.α = float(alpha); r.β = float(beta); r.γ = float(gamma); r.conv = :ZYZ
    r.reverse_outer = true
    return nothing
end

"""shtns_rotation_set_angles_ZXZ(r, alpha, beta, gamma)"""
function shtns_rotation_set_angles_ZXZ(r::SHTRotation, alpha::Real, beta::Real, gamma::Real)
    all(isfinite, (alpha, beta, gamma)) || throw(ArgumentError("rotation angles must be finite"))
    r.α = float(alpha); r.β = float(beta); r.γ = float(gamma); r.conv = :ZXZ
    r.reverse_outer = true
    return nothing
end

"""
    shtns_rotation_wigner_d_matrix(r::SHTRotation, l::Integer, mx::AbstractVector{<:Real}) -> Int

Fill `mx` (length ≥ (2l+1)^2) with d^l in row-major order. Returns size 2l+1.
"""
function shtns_rotation_wigner_d_matrix(r::SHTRotation, l::Integer, mx::AbstractVector{<:Real})
    l = Int(l)
    0 ≤ l ≤ r.lmax || throw(ArgumentError("l must satisfy 0 ≤ l ≤ lmax"))
    n = 2l + 1
    length(mx) ≥ n*n || throw(DimensionMismatch("mx must have length ≥ (2l+1)^2"))
    T = eltype(mx)
    d = wigner_d_matrix(l, T(r.β))
    @inbounds for i in 1:n, j in 1:n
        mx[(i-1)*n + j] = d[i, j]
    end
    return n
end

"""
    _lmcplx_ybasis_signs(lmax, mmax) -> Vector{Float64}

The diagonal ε relating this package's LM_cplx layout to the Y_l^m basis that
the Wigner-d engine works in: `ε_m = (-1)^m` for `m < 0`, `1` otherwise.

Both signs of m share the SAME P̄_l^{|m|} row in this layout, so a real field
satisfies `a_{-m} = conj(a_m)` with no CS factor — unlike the Y_l^m convention,
whose rule is `a_{-m} = (-1)^m conj(a_m)`. ε is real and self-inverse, so
`ε ∘ P ∘ ε` is the rotation expressed in the packed layout, and because
`|ε x| = |x|` any norm-based loss is unchanged by it (which is why the angle
gradients only need ε applied to their inputs).
"""
function _lmcplx_ybasis_signs(lmax::Integer, mmax::Integer)
    lmax = Int(lmax); mmax = Int(mmax)
    v = ones(Float64, nlm_cplx_calc(lmax, mmax, 1))
    for l in 0:lmax, m in -min(l, mmax):-1
        isodd(m) && (v[LM_cplx_index(lmax, mmax, l, m) + 1] = -1.0)
    end
    return v
end

"""
    shtns_rotation_apply_cplx(r::SHTRotation, Zlm::AbstractVector{<:Complex}, Rlm::AbstractVector{<:Complex})

Apply rotation with Euler angles (ZYZ/ZXZ) to complex SH coefficients in LM_cplx packing (mres==1).
"""
@inline function _rotation_zyz_angles(r::SHTRotation, ::Type{T}) where {T<:AbstractFloat}
    all(isfinite, (r.α, r.β, r.γ)) ||
        throw(ArgumentError("rotation angles must be finite"))
    if r.conv === :ZYZ
        return r.reverse_outer ? (T(r.γ), T(r.β), T(r.α)) :
                                 (T(r.α), T(r.β), T(r.γ))
    elseif r.conv === :ZXZ
        return r.reverse_outer ?
            (T(r.γ) - T(pi / 2), T(r.β), T(r.α) + T(pi / 2)) :
            (T(r.α) + T(pi / 2), T(r.β), T(r.γ) - T(pi / 2))
    end
    throw(ArgumentError("rotation convention must be :ZYZ or :ZXZ"))
end

@inline function _rotation_coefficient_scale(r::SHTRotation, l::Int, m::Int)
    scale = norm_scale_from_orthonormal(l, abs(m), r.norm)
    r.real_norm && m != 0 && (scale *= inv(sqrt(2.0)))
    scale *= cs_phase_factor(abs(m), true, r.cs_phase)
    return scale
end

"""Typed flattened Wigner blocks and phases for one immutable rotation."""
function _rotation_host_blocks(r::SHTRotation, ::Type{T}) where {T<:AbstractFloat}
    α, β, γ = _rotation_zyz_angles(r, T)
    offsets = Vector{Int32}(undef, r.lmax + 2)
    total = sum((2l + 1)^2 for l in 0:r.lmax)
    values = Vector{T}(undef, total)
    cursor = 1
    d = Matrix{T}(undef, 2r.lmax + 1, 2r.lmax + 1)
    work = similar(d)
    @inbounds for l in 0:r.lmax
        offsets[l + 1] = Int32(cursor)
        _wigner_d_advance!(d, work, l, β)
        for m in -l:l, mp in -l:l
            values[cursor] = d[m + l + 1, mp + l + 1]
            cursor += 1
        end
    end
    offsets[end] = Int32(cursor)
    input_scales = Vector{T}(undef, nlm_cplx_calc(r.lmax, r.mmax, 1))
    output_scales = similar(input_scales)
    @inbounds for l in 0:r.lmax, m in -min(l, r.mmax):min(l, r.mmax)
        k = LM_cplx_index(r.lmax, r.mmax, l, m) + 1
        scale = T(_rotation_coefficient_scale(r, l, m))
        input_scales[k] = scale
        output_scales[k] = inv(scale)
    end
    return (; offsets, values, input_scales, output_scales, alpha=α, gamma=γ)
end

"""
    _rotation_exceeds_orders(lmax, mmax, β) -> Bool

Whether a rotation through `β` produces orders `|m′| > mmax` that an `mmax < lmax`
layout cannot store. `β ≡ 0 (mod π)` keeps every `|m|`. Shared by the CPU, GPU and
distributed rotation paths so they accept and reject the same rotations.
"""
@inline _rotation_exceeds_orders(lmax::Integer, mmax::Integer, β::Real) =
    mmax < lmax && abs(sin(float(β))) > 1e-12

"""
    _require_full_m_range(r::SHTRotation, β::Real)

Reject an order-mixing rotation on a layout that cannot hold every order it
produces.

A Wigner-d rotation through a general `β` couples `Y_l^m` to every `Y_l^{m′}`
with `|m′| ≤ l`. If the storage stops at `mmax < lmax`, the `|m′| > mmax`
components have nowhere to go and were silently dropped — measured at
`lmax = 8`, that quietly discarded **14.8 %** of the field’s energy at
`mmax = 5` and **24.0 %** at `mmax = 3`, with no error and no warning.

The two degenerate angles are exempt because their `d^l` is not order-mixing:
`β ≡ 0` is diagonal, and `β ≡ π` is anti-diagonal (`m′ = -m`), so `|m′| = |m|`
and a truncated layout still holds the result. That keeps pure Z-rotations
expressed as `ZYZ(α, 0, γ)` working at any `mmax`.

Mirrors the `mres > 1` restriction stated by `dist_SH_Yrotate` and the packed
distributed rotations, for the same reason.
"""
function _require_full_m_range(r::SHTRotation, β::Real)
    _rotation_exceeds_orders(r.lmax, r.mmax, β) || return nothing
    throw(ArgumentError(
        "rotation with β=$(β) mixes azimuthal orders, but this configuration " *
        "stores only m ≤ mmax=$(r.mmax) with lmax=$(r.lmax); the |m| > mmax " *
        "components such a rotation generates cannot be represented and would " *
        "be silently discarded. Use a configuration with mmax == lmax for " *
        "Y/X rotations and general Euler angles. Pure Z-rotations (β ≡ 0 mod π) " *
        "are unaffected and still work at any mmax."))
end

"""
    _rotation_packed_length_check(v, expected, name, r)

Length guard for the packed rotation inputs, with an `mres`-aware message.
"""
function _rotation_packed_length_check(v::AbstractVector, expected::Int,
                                       name::AbstractString, r::SHTRotation)
    length(v) == expected && return nothing
    throw(DimensionMismatch(
        "$name has length $(length(v)), expected $expected for the packed (mres=1) " *
        "layout at lmax=$(r.lmax), mmax=$(r.mmax). A Y/X rotation mixes azimuthal " *
        "orders, so it cannot be represented in an mres-strided layout at all — an " *
        "mres>1 config produces a shorter packed vector and lands here. Use mres=1 " *
        "for rotations other than SH_Zrotate."))
end

function _rotation_apply_cplx_canonical!(r::SHTRotation,
                                         Zlm::AbstractVector{<:Complex},
                                         Rlm::AbstractVector{<:Complex})
    r.lmax ≥ 0 || return Rlm
    RT = typeof(real(zero(eltype(Rlm))))
    α, β, γ = _rotation_zyz_angles(r, RT)
    # The stored Float64 β: rounding π to Float32 leaves sin(β) ≈ 9e-8, which
    # would reject the exact half-turn this check is meant to allow.
    _require_full_m_range(r, r.β)

    # Pre-allocate working arrays at maximum size to avoid per-l allocations
    nmax = 2 * r.lmax + 1
    b = Vector{Complex{RT}}(undef, nmax)
    c = Vector{Complex{RT}}(undef, nmax)
    dl = Matrix{RT}(undef, nmax, nmax)  # Reusable Wigner d-matrix buffer
    dwork = similar(dl)

    # Apply R = diag(e^{-i m α}) * d^l(β) * diag(e^{-i m γ}) for each l
    for l in 0:r.lmax
        mm = min(l, r.mmax)
        n = 2l + 1
        # Build input vector b_m' = e^{-i m' γ} A_{m'} for m' in [-mm..mm].
        #
        # The Wigner-d machinery below is written for the Y_l^m basis, whose
        # Hermitian rule is a_{-m} = (-1)^m conj(a_m). This package's LM_cplx
        # layout is NOT that basis: both signs of m share the SAME P̄_l^{|m|} row,
        # so a real field there satisfies a_{-m} = conj(a_m) with no (-1)^m (see
        # `synthesis_packed_cplx` / `SH_to_lat_cplx`). The two differ by the
        # diagonal ε_m = (-1)^m on m < 0 only, applied on the way in and undone
        # on the way out.
        #
        # Without it this function was a valid rotation in the wrong basis: it
        # stayed unitary (per-l norm preserved), so nothing caught it, but
        # rotating a REAL field produced a complex one — a_{l,0} came back with a
        # non-zero imaginary part. Verified against a spatial-rotation reference.
        # ε is diagonal and commutes with the α/γ phase diagonals, so pure
        # Z-rotations are unaffected.
        fill!(view(b, 1:n), zero(Complex{RT}))
        for mp in -mm:mm
            idx = LM_cplx_index(r.lmax, r.mmax, l, mp) + 1
            εp = (mp < 0 && isodd(mp)) ? -one(RT) : one(RT)
            b[mp + l + 1] = (εp * Zlm[idx]) * cis(-mp * γ)
        end
        # Multiply with d^l(β), advanced in place from the previous degree
        _wigner_d_advance!(dl, dwork, l, β)
        fill!(view(c, 1:n), zero(Complex{RT}))
        # c_m = sum_{m'} d_{m m'} b_{m'}
        for mi in -l:l
            acc = zero(Complex{RT})
            for mp in -l:l
                acc += dl[mi + l + 1, mp + l + 1] * b[mp + l + 1]
            end
            c[mi + l + 1] = acc
        end
        # Apply phase e^{-i m α} and write back only for allowed |m| ≤ mm,
        # undoing the ε basis change applied when b was built.
        for m in -mm:mm
            idx = LM_cplx_index(r.lmax, r.mmax, l, m) + 1
            εm = (m < 0 && isodd(m)) ? -one(RT) : one(RT)
            Rlm[idx] = εm * (c[m + l + 1] * cis(-m * α))
        end
    end
    return Rlm
end

function shtns_rotation_apply_cplx(::CPU, r::SHTRotation,
                                   Zlm::AbstractVector{<:Complex},
                                   Rlm::AbstractVector{<:Complex})
    _require_cpu_storage(:shtns_rotation_apply_cplx, Zlm)
    _require_cpu_storage(:shtns_rotation_apply_cplx, Rlm)
    length(Zlm) == length(Rlm) || throw(DimensionMismatch("Zlm and Rlm length mismatch"))
    expected = nlm_cplx_calc(r.lmax, r.mmax, 1)
    length(Zlm) == expected || throw(DimensionMismatch("LM_cplx size mismatch"))
    eltype(Zlm) === eltype(Rlm) || throw(ArgumentError(
        "rotation input and output element types must match",
    ))
    source = Base.mightalias(Zlm, Rlm) ? copy(Zlm) : Zlm
    canonical = if r.norm === :orthonormal && !r.real_norm && r.cs_phase
        source
    else
        result = similar(source)
        @inbounds for l in 0:r.lmax, m in -min(l, r.mmax):min(l, r.mmax)
            k = LM_cplx_index(r.lmax, r.mmax, l, m) + 1
            result[k] = _rotation_coefficient_scale(r, l, m) * source[k]
        end
        result
    end
    _rotation_apply_cplx_canonical!(r, canonical, Rlm)
    if !(r.norm === :orthonormal && !r.real_norm && r.cs_phase)
        @inbounds for l in 0:r.lmax, m in -min(l, r.mmax):min(l, r.mmax)
            k = LM_cplx_index(r.lmax, r.mmax, l, m) + 1
            Rlm[k] /= _rotation_coefficient_scale(r, l, m)
        end
    end
    return Rlm
end

shtns_rotation_apply_cplx(r::SHTRotation,
                          Zlm::AbstractVector{<:Complex},
                          Rlm::AbstractVector{<:Complex}) =
    shtns_rotation_apply_cplx(CPU(), r, Zlm, Rlm)

"""
    shtns_rotation_apply_real(r::SHTRotation, Qlm::AbstractVector{<:Complex}, Rlm::AbstractVector{<:Complex})

Apply rotation to real-field SH coefficients in packed LM layout (m ≥ 0). Requires `mres==1`.
"""
function shtns_rotation_apply_real(::CPU, r::SHTRotation,
                                   Qlm::AbstractVector{<:Complex},
                                   Rlm::AbstractVector{<:Complex})
    _require_cpu_storage(:shtns_rotation_apply_real, Qlm)
    _require_cpu_storage(:shtns_rotation_apply_real, Rlm)
    expected = nlm_calc(r.lmax, r.mmax, 1)
    # A length mismatch here is almost always an `mres > 1` config reaching a
    # rotation that mixes orders, which no mres-strided layout can represent.
    # Say that, rather than reporting a bare size mismatch the caller has to
    # reverse-engineer. (`dist_SH_Yrotate` and the packed distributed rotations
    # state the same restriction up front.)
    _rotation_packed_length_check(Qlm, expected, "Qlm", r)
    _rotation_packed_length_check(Rlm, expected, "Rlm", r)
    eltype(Qlm) === eltype(Rlm) || throw(ArgumentError(
        "rotation input and output element types must match",
    ))
    source = Base.mightalias(Qlm, Rlm) ? copy(Qlm) : Qlm
    # Build LM_cplx array Zlm from real-packed Qlm using this layout's Hermitian
    # rule a_{-m} = conj(a_m) — NO (-1)^m; see the note at the write below and
    # `_lmcplx_ybasis_signs` for why the CS factor lives inside apply_cplx now.
    RT = typeof(real(zero(eltype(Rlm))))
    Z = Vector{Complex{RT}}(undef, nlm_cplx_calc(r.lmax, r.mmax, 1))
    
    # initialize zeros
    fill!(Z, zero(Complex{RT}))
    for l in 0:r.lmax
        mm = min(l, r.mmax)
        # m = 0
        idxp = LM_index(r.lmax, 1, l, 0) + 1
        idxc = LM_cplx_index(r.lmax, r.mmax, l, 0) + 1
        Z[idxc] = source[idxp]
        for m in 1:mm
            idxp = LM_index(r.lmax, 1, l, m) + 1
            idxc_p = LM_cplx_index(r.lmax, r.mmax, l, m) + 1
            idxc_n = LM_cplx_index(r.lmax, r.mmax, l, -m) + 1
            Am = source[idxp]
            Z[idxc_p] = Am
            # LM_cplx here is the P̄_l^{|m|} layout, whose real-field rule carries
            # NO (-1)^m; `shtns_rotation_apply_cplx` now converts to/from the
            # Y_l^m basis itself, so this must not pre-apply that factor too.
            Z[idxc_n] = conj(Am)
        end
    end
    R = similar(Z)
    shtns_rotation_apply_cplx(CPU(), r, Z, R)
    # Pack back to positive-m layout
    for l in 0:r.lmax
        mm = min(l, r.mmax)
        idxp0 = LM_index(r.lmax, 1, l, 0) + 1
        idxc0 = LM_cplx_index(r.lmax, r.mmax, l, 0) + 1
        Rlm[idxp0] = R[idxc0]
        for m in 1:mm
            idxp = LM_index(r.lmax, 1, l, m) + 1
            idxc = LM_cplx_index(r.lmax, r.mmax, l, m) + 1
            Rlm[idxp] = R[idxc]
        end
    end
    return Rlm
end


shtns_rotation_apply_real(r::SHTRotation,
                          Qlm::AbstractVector{<:Complex},
                          Rlm::AbstractVector{<:Complex}) =
    shtns_rotation_apply_real(CPU(), r, Qlm, Rlm)

"""
    _rotation_apply_real_adjoint(r::SHTRotation, ȳ::AbstractVector) -> Q̄

Adjoint of `Q ↦ shtns_rotation_apply_real(r, Q, R)` under the real inner product
`Re Σ conj(aₖ)·bₖ` that ChainRules and Zygote use for complex arrays.

The packed real rotation is ℝ-linear, not ℂ-linear: its negative orders are the
conjugates of the stored ones. On real-field vectors (real m = 0 entries) the
adjoint coincides with `W·R⁻¹·W⁻¹`, `W = diag(1, 2, 2, …)`, but a cotangent with
imaginary m = 0 entries — `sum(abs2, R .- T)` with a complex target `T` — lies
outside that subspace, and the shortcut then returned wrong gradients. This
places the cotangent on the stored orders of the full complex layout, applies
the transposed Wigner action there, and folds the negative orders back through
their conjugate relation. Shared by the ChainRules and Zygote extensions.
"""
function _rotation_apply_real_adjoint(r::SHTRotation, ȳ::AbstractVector)
    lmax, mmax = r.lmax, r.mmax
    length(ȳ) == nlm_calc(lmax, mmax, 1) || throw(DimensionMismatch(
        "rotation cotangent must have the packed (mres=1) length $(nlm_calc(lmax, mmax, 1))"))
    α, β, γ = _rotation_zyz_angles(r, Float64)
    WT = promote_type(complex(float(real(eltype(ȳ)))), ComplexF64)
    Q̄ = zeros(complex(float(real(eltype(ȳ)))), length(ȳ))
    nmax = 2lmax + 1
    cbar = Vector{WT}(undef, nmax)
    dl = Matrix{Float64}(undef, nmax, nmax)
    dwork = similar(dl)
    for l in 0:lmax
        mm = min(l, mmax)
        n = 2l + 1
        # Canonical cotangent of the stored orders with the output phase undone;
        # the forward never writes negative orders, so they receive none.
        fill!(view(cbar, 1:n), zero(WT))
        for m in 0:mm
            k = LM_index(lmax, 1, l, m) + 1
            cbar[m + l + 1] = ȳ[k] / _rotation_coefficient_scale(r, l, m) * cis(m * α)
        end
        _wigner_d_advance!(dl, dwork, l, β)
        for mp in 0:mm
            # Transposed Wigner action and input phase at orders ±m'.
            bp = zero(WT); bn = zero(WT)
            for m in 0:mm
                bp += dl[m + l + 1, mp + l + 1] * cbar[m + l + 1]
                bn += dl[m + l + 1, -mp + l + 1] * cbar[m + l + 1]
            end
            q = bp * cis(mp * γ)
            # The forward builds order -m' as (-1)^m' conj(A_m') in the Wigner basis.
            mp > 0 && (q += (-1)^mp * conj(bn * cis(-mp * γ)))
            Q̄[LM_index(lmax, 1, l, mp) + 1] = q * _rotation_coefficient_scale(r, l, mp)
        end
    end
    return Q̄
end
