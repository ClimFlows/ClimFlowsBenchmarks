#=
================================================================================
kernels.jl - Legendre Accumulation Kernels for Spherical Harmonic Transforms
================================================================================

Low-level kernel functions that perform per-latitude Legendre polynomial
accumulation. These are the innermost loops of all SHT transforms, extracted
here as a single source of truth.

Each kernel handles one latitude point for one azimuthal mode m.
Table variants receive precomputed Legendre values; on-the-fly variants
compute them via Plm_row! or Plm_dPdtheta_over_sinth_row!.

All kernels are @inline to allow the compiler to fuse them into the
orchestrator's loop without function-call overhead.
================================================================================
=#

# ============================================================================
# SCALAR ANALYSIS KERNELS
# ============================================================================

"""Scalar analysis kernel using Nlm-fused tables (`NP[l+1, i] = Nlm * P_l^m`)."""
@inline function _scalar_analysis_kernel!(alm, cfg, Fph, NP, i, col, m, lmax, scale_phi)
    Fi = Fph[i, col]
    wi = cfg.w[i]
    @inbounds for l in m:lmax
        alm[l+1, col] += (wi * NP[l+1, i] * scale_phi) * Fi
    end
end

"""Scalar analysis kernel computing Legendre polynomials on the fly."""
@inline function _scalar_analysis_kernel_otf!(alm, cfg, Fph, P, i, col, m, lmax, scale_phi)
    Plm_norm_row!(P, cfg.x[i], lmax, m)
    Fi = Fph[i, col]
    wi = cfg.w[i]
    @inbounds for l in m:lmax
        alm[l+1, col] += (wi * P[l+1] * scale_phi) * Fi
    end
end

# ============================================================================
# SCALAR SYNTHESIS KERNELS
# ============================================================================

"""Scalar synthesis kernel using Nlm-fused tables (`NP[l+1, i] = Nlm * P_l^m`)."""
@inline function _scalar_synthesis_kernel(cfg, alm, NP, i, col, m, lmax,
                                          scale_matrix=nothing)
    acc = zero(eltype(alm))
    @inbounds for l in m:lmax
        acc += NP[l+1, i] * _canonical_coefficient(alm, scale_matrix, l, col)
    end
    return acc
end

"""Scalar synthesis kernel computing Legendre polynomials on the fly. Returns accumulated value."""
@inline function _scalar_synthesis_kernel_otf(cfg, alm, P, i, col, m, lmax,
                                              scale_matrix=nothing)
    Plm_norm_row!(P, cfg.x[i], lmax, m)   # P now holds orthonormal P̄ (= Nlm·rawP)
    acc = zero(eltype(alm))
    @inbounds for l in m:lmax
        acc += P[l+1] * _canonical_coefficient(alm, scale_matrix, l, col)
    end
    return acc
end

# ============================================================================
# POLE HELPERS (moved from sphtor_transforms.jl)
# ============================================================================

"""Compute dP_l^m/dtheta * N at a pole (x = +/-1) using analytical limits."""
@inline function _dPdtheta_at_pole(l::Int, m::Int, x::Float64, N::Float64)
    if m == 0
        return 0.0
    elseif m == 1
        if x > 0
            return N * (-Float64(l * (l + 1)) / 2)
        else
            return N * Float64((-1)^(l+1)) * l * (l + 1) / 2
        end
    else
        return 0.0
    end
end

"""Compute P_l^m/sin(theta) * N at a pole (x = +/-1) using analytical limits."""
@inline function _P_over_sinth_at_pole(l::Int, m::Int, x::Float64, N::Float64)
    if m == 0
        return 0.0
    elseif m == 1
        if x > 0
            return N * (-Float64(l * (l + 1)) / 2)
        else
            return N * Float64((-1)^l) * l * (l + 1) / 2
        end
    else
        return 0.0
    end
end

# ============================================================================
# SPHTOR SYNTHESIS KERNELS
# ============================================================================

"""
    SphtorKernelCtx(NP, NdP, i, col, m, ltr)

Bundles the per-(m, i) loop context sphtor kernels receive. Julia compiles
field access for free; this keeps the kernel signatures readable and avoids
6-way positional-argument ordering bugs. Callers may still use the old
positional form — methods accepting both remain defined.
"""
struct SphtorKernelCtx{TP,TD}
    NP::TP
    NdP::TD
    i::Int
    col::Int
    m::Int
    ltr::Int
end

"""Sphtor synthesis kernel using Nlm-fused tables (`NP = Nlm*P_l^m`, `NdP = Nlm*dP_l^m/dx`)."""
@inline function _sphtor_synthesis_kernel(cfg, Slm, Tlm, ctx::SphtorKernelCtx)
    return _sphtor_synthesis_kernel(cfg, Slm, Tlm, ctx.NP, ctx.NdP, ctx.i, ctx.col, ctx.m, ctx.ltr)
end

@inline function _sphtor_synthesis_kernel(cfg, Slm, Tlm, NP, NdP, i, col, m, ltr)
    x = cfg.x[i]
    s_theta = sqrt(max(0.0, 1 - x*x))
    is_pole = s_theta < POLE_TOLERANCE_FACTOR * eps(Float64)
    inv_s_theta = is_pole ? 0.0 : 1.0 / s_theta
    # Accumulator eltype follows the inputs so AD types propagate.
    CT = promote_type(eltype(Slm), eltype(Tlm), ComplexF64)
    g_theta = zero(CT)
    g_phi = zero(CT)
    Nlm = cfg.Nlm  # hoist field read out of the hot loop (cfg is mutable, so the compiler can't lift it)
    @inbounds for l in max(1, m):ltr
        if is_pole
            N = Nlm[l+1, col]  # pole-safe closed forms still need N explicitly
            dtheta_Y = _dPdtheta_at_pole(l, m, x, N)
            Y_over_s = _P_over_sinth_at_pole(l, m, x, N)
        else
            dtheta_Y = -s_theta * NdP[l+1, i]
            Y_over_s = NP[l+1, i] * inv_s_theta
        end
        Sl = Slm[l+1, col]; Tl = Tlm[l+1, col]
        g_theta += dtheta_Y * Sl - 1.0im * m * Y_over_s * Tl
        g_phi += 1.0im * m * Y_over_s * Sl + dtheta_Y * Tl
    end
    return g_theta, g_phi
end

"""Sphtor synthesis kernel computing Legendre on the fly. Returns (g_theta, g_phi).
`Pb` is a caller-supplied scratch of length ≥ lmax+2 used by the normalized dθ recurrence."""
@inline function _sphtor_synthesis_kernel_otf(cfg, Slm, Tlm, P, dPdtheta, P_over_sinth, Pb, i, col, m, ltr)
    Plm_norm_dPdtheta_over_sinth_row!(P, dPdtheta, P_over_sinth, cfg.x[i], cfg.lmax, m, Pb)
    # Accumulator eltype follows the inputs so AD types propagate.
    CT = promote_type(eltype(Slm), eltype(Tlm), ComplexF64)
    g_theta = zero(CT)
    g_phi = zero(CT)
    @inbounds for l in max(1, m):ltr
        dtheta_Y = dPdtheta[l+1]      # already orthonormal-normalized
        Y_over_s = P_over_sinth[l+1]
        Sl = Slm[l+1, col]; Tl = Tlm[l+1, col]
        g_theta += dtheta_Y * Sl - 1.0im * m * Y_over_s * Tl
        g_phi += 1.0im * m * Y_over_s * Sl + dtheta_Y * Tl
    end
    return g_theta, g_phi
end

# ============================================================================
# SPHTOR ANALYSIS KERNELS
# ============================================================================

"""Sphtor analysis kernel using Nlm-fused tables. Accumulates into Sacc, Tacc."""
@inline function _sphtor_analysis_kernel!(Sacc, Tacc, cfg, Ftheta_i, Fphi_i, wi, ctx::SphtorKernelCtx, scale_phi)
    return _sphtor_analysis_kernel!(Sacc, Tacc, cfg, Ftheta_i, Fphi_i, wi,
                                     ctx.NP, ctx.NdP, ctx.i, ctx.col, ctx.m, ctx.ltr, scale_phi)
end

@inline function _sphtor_analysis_kernel!(Sacc, Tacc, cfg, Ftheta_i, Fphi_i, wi, NP, NdP, i, col, m, ltr, scale_phi)
    x = cfg.x[i]
    s_theta = sqrt(max(0.0, 1 - x*x))
    is_pole = s_theta < POLE_TOLERANCE_FACTOR * eps(Float64)
    inv_s_theta = is_pole ? 0.0 : 1.0 / s_theta
    Nlm = cfg.Nlm  # hoist field read out of the hot loop (cfg is mutable, so the compiler can't lift it)
    @inbounds for l in max(1, m):ltr
        if is_pole
            N = Nlm[l+1, col]
            dtheta_Y = _dPdtheta_at_pole(l, m, x, N)
            Y_over_s = _P_over_sinth_at_pole(l, m, x, N)
        else
            dtheta_Y = -s_theta * NdP[l+1, i]
            Y_over_s = NP[l+1, i] * inv_s_theta
        end
        coeff = wi * scale_phi / (l * (l + 1))
        term = 1.0im * m * Y_over_s
        Sacc[l+1] += coeff * (Ftheta_i * dtheta_Y + conj(term) * Fphi_i)
        Tacc[l+1] += coeff * (-conj(term) * Ftheta_i + dtheta_Y * Fphi_i)
    end
end

"""Sphtor analysis kernel computing Legendre on the fly. Accumulates into Sacc, Tacc.
`Pb` is a caller-supplied scratch of length ≥ lmax+2 used by the normalized dθ recurrence."""
@inline function _sphtor_analysis_kernel_otf!(Sacc, Tacc, cfg, Ftheta_i, Fphi_i, wi, P, dPdtheta, P_over_sinth, Pb, i, col, m, ltr, scale_phi)
    Plm_norm_dPdtheta_over_sinth_row!(P, dPdtheta, P_over_sinth, cfg.x[i], cfg.lmax, m, Pb)
    @inbounds for l in max(1, m):ltr
        dtheta_Y = dPdtheta[l+1]      # already orthonormal-normalized
        Y_over_s = P_over_sinth[l+1]
        coeff = wi * scale_phi / (l * (l + 1))
        term = 1.0im * m * Y_over_s
        Sacc[l+1] += coeff * (Ftheta_i * dtheta_Y + conj(term) * Fphi_i)
        Tacc[l+1] += coeff * (-conj(term) * Ftheta_i + dtheta_Y * Fphi_i)
    end
end
