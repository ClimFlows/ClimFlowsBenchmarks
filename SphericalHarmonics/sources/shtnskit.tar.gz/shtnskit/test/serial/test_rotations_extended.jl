# SHTnsKit.jl - Extended rotation tests
# Covers bits of src/rotations.jl not in test_rotations.jl:
# - WignerCache
# - wigner_d_matrix_deriv finite-difference check
# - shtns_rotation_wigner_d_matrix (row-major fill)
# - shtns_rotation_create / destroy
# - ZXZ convention application
# - Composed rotations vs. direct Euler

using Test
using Random
using LinearAlgebra
using SHTnsKit

@isdefined(VERBOSE) || (const VERBOSE = get(ENV, "SHTNSKIT_TEST_VERBOSE", "0") == "1")

@testset "Rotations (extended)" begin
    @testset "WignerCache consistency with direct build" begin
        lmax = 5
        β = 0.37
        cache = SHTnsKit.WignerCache(lmax, β)
        @test cache.β == β
        for l in 0:lmax
            d_cached = SHTnsKit.wigner_d(cache, l)
            d_direct = SHTnsKit.wigner_d_matrix(l, β)
            @test d_cached == d_direct
            @test size(d_cached) == (2l + 1, 2l + 1)
        end
        @test_throws ArgumentError SHTnsKit.wigner_d(cache, lmax + 1)
        @test_throws ArgumentError SHTnsKit.WignerCache(-1, β)
    end

    @testset "in-order Wigner sweep reproduces direct builds exactly" begin
        # Rotations advance one dˡ to the next (O(l²)) instead of rebuilding
        # each from d⁰ (O(l³)); the sweep must be the same arithmetic.
        lmax = 24
        for T in (Float32, Float64), β in (0.0, 0.7, -2.3, π)
            d = Matrix{T}(undef, 2lmax + 1, 2lmax + 1)
            work = similar(d)
            dβ = similar(d)
            exact = true
            for l in 0:lmax
                n = 2l + 1
                SHTnsKit._wigner_d_advance!(d, work, l, T(β))
                exact &= d[1:n, 1:n] == SHTnsKit.wigner_d_matrix(l, T(β))
                SHTnsKit._wigner_d_deriv!(dβ, d, l)
                exact &= dβ[1:n, 1:n] == SHTnsKit.wigner_d_matrix_deriv(l, T(β))
            end
            @test exact
        end
    end

    @testset "Wigner-d remains stable at high degree" begin
        d = SHTnsKit.wigner_d_matrix(64, 0.7)
        @test opnorm(transpose(d) * d - I, Inf) < 1e-10

        # Differentiating dᵀd = I gives this skew-tangent identity. It catches
        # both overflow/cancellation in d and instability in its derivative.
        dβ = SHTnsKit.wigner_d_matrix_deriv(64, 0.7)
        @test opnorm(transpose(d) * dβ + transpose(dβ) * d, Inf) < 1e-9
    end

    @testset "Wigner-d preserves caller precision" begin
        β = Float32(0.37)
        d = SHTnsKit.wigner_d_matrix(8, β)
        dβ = SHTnsKit.wigner_d_matrix_deriv(8, β)
        @test eltype(d) === Float32
        @test eltype(dβ) === Float32
        @test opnorm(transpose(d) * d - I, Inf) < 2f-5
    end

    @testset "wigner_d_matrix_deriv: finite-difference check" begin
        h = 1e-6
        for l in 0:3
            β = 0.4
            d_plus  = SHTnsKit.wigner_d_matrix(l, β + h)
            d_minus = SHTnsKit.wigner_d_matrix(l, β - h)
            dd_fd = (d_plus .- d_minus) ./ (2h)
            dd = SHTnsKit.wigner_d_matrix_deriv(l, β)
            @test isapprox(dd, dd_fd; rtol=1e-5, atol=1e-7)
        end
    end

    @testset "wigner_d_matrix_deriv: l=0 is zero" begin
        dd = SHTnsKit.wigner_d_matrix_deriv(0, 0.5)
        @test size(dd) == (1, 1)
        @test dd[1, 1] == 0.0
    end

    @testset "shtns_rotation_wigner_d_matrix row-major layout" begin
        lmax = 3
        r = SHTRotation(lmax, lmax)
        β = 0.6
        shtns_rotation_set_angles_ZYZ(r, 0.0, β, 0.0)
        for l in 0:lmax
            n = 2l + 1
            buf = zeros(n * n)
            ret = shtns_rotation_wigner_d_matrix(r, l, buf)
            @test ret == n
            d_ref = SHTnsKit.wigner_d_matrix(l, β)
            # Row-major unpack
            for i in 1:n, j in 1:n
                @test buf[(i - 1) * n + j] ≈ d_ref[i, j]
            end
        end
        # Buffer-too-small → DimensionMismatch
        @test_throws DimensionMismatch shtns_rotation_wigner_d_matrix(r, 3, zeros(1))
    end

    @testset "shtns_rotation_create / destroy" begin
        r = shtns_rotation_create(4, 4, 0)
        @test r isa SHTRotation
        @test r.lmax == 4
        @test r.mmax == 4
        @test shtns_rotation_destroy(r) === nothing
        fourpi = shtns_rotation_create(4, 4, 1)
        @test fourpi.norm === :fourpi
        schmidt = shtns_rotation_create(4, 4, 2 | (256 * 4) | (256 * 8))
        @test schmidt.norm === :schmidt
        @test !schmidt.cs_phase
        @test schmidt.real_norm
        @test_throws ArgumentError shtns_rotation_create(4, 4, 3)
    end

    @testset "ZYZ vs ZXZ: 90° x-rotation consistency" begin
        lmax = 4
        cfg = create_gauss_config(lmax, lmax + 2; nlon=2*lmax + 1)
        rng = MersenneTwister(400)
        Qlm = randn(rng, ComplexF64, cfg.nlm)
        Qlm[1:lmax + 1] .= real.(Qlm[1:lmax + 1])

        Rlm_x = similar(Qlm)
        SH_Xrotate90(cfg, Qlm, Rlm_x)
        # Energy must be preserved
        @test isapprox(energy_scalar_packed(cfg, Rlm_x),
                       energy_scalar_packed(cfg, Qlm); rtol=1e-10)

        # Four 90° X-rotations return to identity
        tmp1 = similar(Qlm); tmp2 = similar(Qlm); tmp3 = similar(Qlm); tmp4 = similar(Qlm)
        SH_Xrotate90(cfg, Qlm, tmp1)
        SH_Xrotate90(cfg, tmp1, tmp2)
        SH_Xrotate90(cfg, tmp2, tmp3)
        SH_Xrotate90(cfg, tmp3, tmp4)
        @test isapprox(tmp4, Qlm; rtol=1e-8, atol=1e-10)
    end

    @testset "Fast axis helpers use the general rotation orientation" begin
        lmax = 4
        cfg = create_gauss_config(lmax, lmax + 2; nlon=2*lmax + 1)
        rng = MersenneTwister(405)
        Qlm = randn(rng, ComplexF64, cfg.nlm)
        Qlm[1:lmax + 1] .= real.(Qlm[1:lmax + 1])

        α = 0.37
        rz = SHTRotation(lmax, lmax)
        shtns_rotation_set_angles_ZYZ(rz, α, 0.0, 0.0)
        z_general = similar(Qlm)
        z_fast = similar(Qlm)
        shtns_rotation_apply_real(rz, Qlm, z_general)
        SH_Zrotate(cfg, Qlm, α, z_fast)
        @test z_fast ≈ z_general rtol=2e-13 atol=2e-13

        rx = SHTRotation(lmax, lmax)
        shtns_rotation_set_angle_axis(rx, π/2, 1.0, 0.0, 0.0)
        x_general = similar(Qlm)
        x_fast = similar(Qlm)
        shtns_rotation_apply_real(rx, Qlm, x_general)
        SH_Xrotate90(cfg, Qlm, x_fast)
        @test x_fast ≈ x_general rtol=2e-13 atol=2e-13
    end

    @testset "Serial axis wrappers honor configured coefficient conventions" begin
        lmax = 4
        canonical_cfg = create_gauss_config(lmax, lmax + 2; nlon=2*lmax + 1)
        cfg = create_gauss_config(lmax, lmax + 2; nlon=2*lmax + 1,
                                  norm=:schmidt, real_norm=true, cs_phase=false)
        rng = MersenneTwister(406)
        Qcanonical = randn(rng, ComplexF64, canonical_cfg.nlm)
        Qcanonical[1:lmax + 1] .= real.(Qcanonical[1:lmax + 1])
        Qconfigured = similar(Qcanonical)
        SHTnsKit.convert_alm_norm!(Qconfigured, Qcanonical, cfg; to_internal=false)

        rotations = (
            (q, out, c) -> SH_Yrotate(c, q, 0.41, out),
            (q, out, c) -> SH_Yrotate90(c, q, out),
            (q, out, c) -> SH_Xrotate90(c, q, out),
        )
        for rotate! in rotations
            expected = similar(Qcanonical)
            rotate!(Qcanonical, expected, canonical_cfg)
            got_configured = similar(Qconfigured)
            rotate!(Qconfigured, got_configured, cfg)
            got_canonical = similar(Qcanonical)
            SHTnsKit.convert_alm_norm!(got_canonical, got_configured, cfg; to_internal=true)
            @test got_canonical ≈ expected rtol=2e-12 atol=2e-12
        end
    end

    @testset "SHTns setter outer-Z argument order" begin
        lmax = 3
        a, b, g = 0.23, 0.41, -0.17
        setter = SHTRotation(lmax, lmax)
        shtns_rotation_set_angles_ZYZ(setter, a, b, g)
        matrix_order = SHTRotation(lmax, lmax; α=g, β=b, γ=a)
        q = randn(MersenneTwister(405), ComplexF64, nlm_calc(lmax, lmax, 1))
        q[1:lmax + 1] .= real.(q[1:lmax + 1])
        got = similar(q)
        expected = similar(q)
        shtns_rotation_apply_real(setter, q, got)
        shtns_rotation_apply_real(matrix_order, q, expected)
        @test got ≈ expected atol=2e-12 rtol=2e-12

        z = randn(MersenneTwister(406), ComplexF64, nlm_cplx_calc(lmax, lmax, 1))
        zg = similar(z)
        ze = similar(z)
        shtns_rotation_apply_cplx(setter, z, zg)
        shtns_rotation_apply_cplx(matrix_order, z, ze)
        @test zg ≈ ze atol=2e-12 rtol=2e-12
    end

    @testset "Composition: two Y-rotations = single Y-rotation" begin
        lmax = 4
        cfg = create_gauss_config(lmax, lmax + 2; nlon=2*lmax + 1)
        rng = MersenneTwister(401)
        Qlm = randn(rng, ComplexF64, cfg.nlm)
        Qlm[1:lmax + 1] .= real.(Qlm[1:lmax + 1])

        β1, β2 = 0.3, 0.5
        t1 = similar(Qlm); t2 = similar(Qlm); direct = similar(Qlm)
        SH_Yrotate(cfg, Qlm, β1, t1)
        SH_Yrotate(cfg, t1, β2, t2)
        SH_Yrotate(cfg, Qlm, β1 + β2, direct)

        @test isapprox(t2, direct; rtol=1e-9, atol=1e-11)
    end

    @testset "General rotation identity (α=β=γ=0)" begin
        lmax = 4
        cfg = create_gauss_config(lmax, lmax + 2; nlon=2*lmax + 1)
        rng = MersenneTwister(402)
        Qlm = randn(rng, ComplexF64, cfg.nlm)
        Qlm[1:lmax + 1] .= real.(Qlm[1:lmax + 1])

        r = SHTRotation(lmax, lmax)  # default α=β=γ=0
        Rlm = similar(Qlm)
        shtns_rotation_apply_real(r, Qlm, Rlm)
        @test isapprox(Rlm, Qlm; rtol=1e-12, atol=1e-14)
    end

    @testset "Rotation energy preservation (real field, packed)" begin
        lmax = 4
        cfg = create_gauss_config(lmax, lmax + 2; nlon=2*lmax + 1)
        rng = MersenneTwister(403)
        Qlm = randn(rng, ComplexF64, cfg.nlm)
        Qlm[1:lmax + 1] .= real.(Qlm[1:lmax + 1])

        r = SHTRotation(lmax, lmax)
        shtns_rotation_set_angles_ZYZ(r, 0.7, 1.1, -0.4)
        Rlm = similar(Qlm)
        shtns_rotation_apply_real(r, Qlm, Rlm)

        @test isapprox(energy_scalar_packed(cfg, Rlm),
                       energy_scalar_packed(cfg, Qlm); rtol=1e-9)
    end

    @testset "Angle-axis with zero-length axis → identity" begin
        r = SHTRotation(3, 3)
        r.α = 0.9; r.β = 0.9; r.γ = 0.9
        shtns_rotation_set_angle_axis(r, 1.2, 0.0, 0.0, 0.0)
        @test r.α == 0.0 && r.β == 0.0 && r.γ == 0.0
        @test r.conv == :ZYZ
    end

    @testset "Angle-axis preserves small tilts" begin
        cfg = create_gauss_config(1, 3)
        Q = zeros(ComplexF64, cfg.nlm)
        Q[LM_index(1, 1, 1, 0) + 1] = 1
        for theta in (1e-9, -1e-9, Float32(1e-4), Float32(-1e-4)),
            axis in ((0, 1, 0), (1, 0, 0), (1, 2, 3))
            r = SHTRotation(1, 1)
            shtns_rotation_set_angle_axis(r, theta, axis...)
            actual = similar(Q)
            shtns_rotation_apply_real(r, Q, actual)

            # A rotated Y_1^0 is proportional to the rotated z direction.
            # Rodrigues' formula gives an independent first-degree oracle.
            kx, ky, kz = collect(axis) ./ norm(collect(axis))
            angle = Float64(theta)
            c, s = cos(angle), sin(angle)
            t = 2sin(angle / 2)^2
            rx = t*kx*kz + s*ky
            ry = t*ky*kz - s*kx
            rz = c + t*kz*kz
            @test actual[2] ≈ rz atol=2e-14 rtol=2e-14
            @test actual[3] ≈ complex(-rx, ry)/sqrt(2) atol=2e-14 rtol=2e-7
            @test abs(actual[3]) > 0
        end
    end

    @testset "Dimension checks on rotation apply" begin
        lmax, mmax = 3, 3
        r = SHTRotation(lmax, mmax)
        expected = nlm_calc(lmax, mmax, 1)
        @test_throws DimensionMismatch shtns_rotation_apply_real(r,
            zeros(ComplexF64, expected - 1), zeros(ComplexF64, expected))
        @test_throws DimensionMismatch shtns_rotation_apply_real(r,
            zeros(ComplexF64, expected), zeros(ComplexF64, expected + 1))

        nlmc = nlm_cplx_calc(lmax, mmax, 1)
        @test_throws DimensionMismatch shtns_rotation_apply_cplx(r,
            zeros(ComplexF64, nlmc), zeros(ComplexF64, nlmc - 1))
    end

    @testset "ZXZ convention differs from ZYZ for β≠0" begin
        # Sanity: setting same numerical (α,β,γ) under ZXZ vs ZYZ should (generally) give
        # different rotated coefficients. Current code only treats the conv label; we still
        # verify the label is stored and the rotation runs cleanly.
        lmax = 3
        r_xz = SHTRotation(lmax, lmax)
        shtns_rotation_set_angles_ZXZ(r_xz, 0.3, 0.5, 0.2)
        @test r_xz.conv == :ZXZ

        cfg = create_gauss_config(lmax, lmax + 2; nlon=2*lmax + 1)
        rng = MersenneTwister(404)
        Qlm = randn(rng, ComplexF64, cfg.nlm)
        Qlm[1:lmax + 1] .= real.(Qlm[1:lmax + 1])

        Rlm = similar(Qlm)
        shtns_rotation_apply_real(r_xz, Qlm, Rlm)
        @test all(isfinite, Rlm)
        # Energy still preserved
        @test isapprox(energy_scalar_packed(cfg, Rlm),
                       energy_scalar_packed(cfg, Qlm); rtol=1e-9)
    end
end
