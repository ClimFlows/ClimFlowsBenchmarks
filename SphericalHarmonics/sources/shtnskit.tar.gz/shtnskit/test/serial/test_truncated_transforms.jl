# SHTnsKit.jl - Truncated and Mode-Limited Transform Tests
# Tests for degree-limited and single-mode transforms

using Test
using Random
using SHTnsKit

@isdefined(VERBOSE) || (const VERBOSE = get(ENV, "SHTNSKIT_TEST_VERBOSE", "0") == "1")

@testset "Truncated and Mode-Limited Transforms" begin
    @testset "Degree-limited analysis" begin
        lmax = 8
        nlat = lmax + 2
        nlon = 2*lmax + 1
        cfg = create_gauss_config(lmax, nlat; nlon=nlon)
        rng = MersenneTwister(45)

        # Random spatial field
        f = randn(rng, nlat, nlon)
        Qlm_full = analysis_packed(cfg, vec(f))

        # Truncated analysis
        ltr = lmax - 2
        Qlm_trunc = analysis_packed_l(cfg, vec(f), ltr)

        # Verify truncation: modes l > ltr should be zero
        for m in 0:cfg.mmax
            for l in m:cfg.lmax
                idx = LM_index(cfg.lmax, cfg.mres, l, m) + 1
                if l <= ltr
                    @test isapprox(Qlm_trunc[idx], Qlm_full[idx]; rtol=1e-10, atol=1e-12)
                else
                    @test Qlm_trunc[idx] == 0
                end
            end
        end
    end

    @testset "Degree-limited synthesis" begin
        lmax = 8
        nlat = lmax + 2
        nlon = 2*lmax + 1
        cfg = create_gauss_config(lmax, nlat; nlon=nlon)
        rng = MersenneTwister(46)
        ltr = lmax - 2

        # Random packed coefficients
        Qlm_full = randn(rng, ComplexF64, cfg.nlm)
        Qlm_full[1:lmax+1] .= real.(Qlm_full[1:lmax+1])  # m=0 real

        # Truncated synthesis
        f_trunc = synthesis_packed_l(cfg, Qlm_full, ltr)

        # Should match synthesis of zeroed-out high modes
        Qlm_zeroed = copy(Qlm_full)
        for m in 0:cfg.mmax
            for l in max(m, ltr+1):cfg.lmax  # Only zero modes where l > ltr and l >= m
                idx = LM_index(cfg.lmax, cfg.mres, l, m) + 1
                Qlm_zeroed[idx] = 0
            end
        end
        f_zeroed = synthesis_packed(cfg, Qlm_zeroed)
        @test isapprox(f_trunc, f_zeroed; rtol=1e-10, atol=1e-12)
    end

    @testset "Point evaluation" begin
        lmax = 6
        nlat = lmax + 2
        nlon = 2*lmax + 1
        cfg = create_gauss_config(lmax, nlat; nlon=nlon)

        # Single spherical harmonic: Y_2^0 ∝ (3cos²θ - 1)/2
        alm = zeros(ComplexF64, lmax+1, lmax+1)
        alm[3, 1] = 1.0  # l=2, m=0

        # Evaluate at specific point and verify against known value
        # Y_2^0(θ,φ) = N_2^0 * P_2^0(cosθ) where P_2^0(x) = (3x²-1)/2
        # N_2^0 = sqrt((2*2+1)/(4π)) = sqrt(5/(4π))
        N20 = sqrt(5 / (4π))
        for cost in [-0.8, -0.3, 0.0, 0.3, 0.5, 0.8]
            P20 = (3 * cost^2 - 1) / 2
            expected = cfg.Nlm[3, 1] * P20  # Use the normalization from config
            for phi in [0.0, π/4, π/2, π, 3π/2]
                val = synthesis_point(cfg, alm, cost, phi)
                @test !isnan(val) && !isinf(val)
                # m=0 mode is independent of phi, so all phi give same value
                @test isapprox(val, expected; rtol=1e-10, atol=1e-12)
            end
        end
    end

    @testset "Latitude evaluation" begin
        lmax = 6
        nlat = lmax + 2
        nlon = 2*lmax + 1
        cfg = create_gauss_config(lmax, nlat; nlon=nlon)
        rng = MersenneTwister(47)

        # Random coefficients
        Qlm = randn(rng, ComplexF64, cfg.nlm)
        Qlm[1:lmax+1] .= real.(Qlm[1:lmax+1])  # m=0 real

        cost = 0.3
        lat_vals = SH_to_lat(cfg, Qlm, cost)

        @test length(lat_vals) == nlon

        # Verify consistency with full synthesis at this latitude
        # The latitude values should match a row of the full synthesis
        f_full = reshape(synthesis_packed(cfg, Qlm), nlat, nlon)

        # Find closest latitude in grid
        idx = argmin(abs.(cfg.x .- cost))
        if abs(cfg.x[idx] - cost) < 1e-10
            @test isapprox(lat_vals, f_full[idx, :]; rtol=1e-9, atol=1e-11)
        end
    end

    @testset "Mode-limited transforms" begin
        lmax = 6
        nlat = lmax + 2
        nlon = 2*lmax + 1
        cfg = create_gauss_config(lmax, nlat; nlon=nlon)
        rng = MersenneTwister(48)

        # Test dimensions and validity of output
        for im in 0:3
            ltr = lmax - 1
            len = ltr - im + 1

            if len > 0
                # Random coefficients for this m mode
                Ql = randn(rng, ComplexF64, len)

                # Mode synthesis - verify output dimensions and validity
                f_ml = synthesis_packed_ml(cfg, im, Ql, ltr)
                @test length(f_ml) == nlat
                @test all(!isnan, f_ml)
                @test all(!isinf, f_ml)

                # Mode analysis - verify output dimensions
                Ql_back = analysis_packed_ml(cfg, im, f_ml, ltr)
                @test length(Ql_back) == len
                @test all(!isnan, Ql_back)
                @test all(!isinf, Ql_back)

                # Scalar mode-limited roundtrip should be exact
                @test isapprox(Ql_back, Ql; rtol=1e-9, atol=1e-11)
            end
        end
    end
end
