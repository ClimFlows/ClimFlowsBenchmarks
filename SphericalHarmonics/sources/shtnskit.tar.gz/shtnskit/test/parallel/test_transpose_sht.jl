using MPI; MPI.Init()
using SHTnsKit, PencilArrays, PencilFFTs, Test

const comm = MPI.COMM_WORLD
const rank = MPI.Comm_rank(comm)
const ParExt = Base.get_extension(SHTnsKit, :SHTnsKitParallelExt)

@testset "DistTransposePlan construction" begin
    lmax = 32; nlat = lmax + 2; nlon = 2 * lmax + 1
    cfg = create_gauss_config(lmax, nlat; nlon = nlon)

    plan = DistTransposePlan(cfg; comm = comm, nlev = 1, use_rfft = true)

    @test plan.nlat == nlat
    @test plan.nlon == nlon
    @test plan.lmax == lmax
    @test plan.mmax == lmax

    # Each rank must own at least one m and all must be in range
    @test !isempty(plan.m_local)
    @test all(0 .<= plan.m_local .<= cfg.mmax)

    # m ownership partitions 0:mmax exactly once across all ranks
    owned = MPI.Allreduce(length(plan.m_local), +, comm)
    @test owned == cfg.mmax + 1

    # Legendre tables: one (lmax+1, nlat) matrix per local m
    @test length(plan.NP) == length(plan.m_local)
    @test size(plan.NP[1]) == (lmax + 1, nlat)

    # allocate_spatial returns a real PencilArray
    fsp = allocate_spatial(plan)
    @test fsp isa PencilArray

    # allocate_spectral returns a complex PencilArray
    Alm = allocate_spectral(plan)
    @test Alm isa PencilArray

    rank == 0 && println("DistTransposePlan construction OK on $(MPI.Comm_size(comm)) rank(s)")
end

@testset "DistTransposePlan collective constructor validation" begin
    cfg = create_gauss_config(4, 7; nlon=10)
    world_pen = PencilArrays.Pencil(
        Array, (cfg.nlon, cfg.nlat), (2,), comm,
    )
    varying_prototype = if iseven(rank)
        PencilArray{Float32}(undef, world_pen, 1)
    else
        PencilArray{Float64}(undef, world_pen, 1)
    end
    caught = false
    try
        DistTransposePlan(cfg; comm, nlev=1, prototype=varying_prototype)
    catch error
        caught = error isa ArgumentError
    end
    @test MPI.Allreduce(caught ? 1 : 0, min, comm) == 1
    MPI.Barrier(comm)

    self_pen = PencilArrays.Pencil(
        Array, (cfg.nlon, cfg.nlat), (2,), MPI.COMM_SELF,
    )
    self_prototype = PencilArray{Float64}(undef, self_pen, 1)
    varying_comm_prototype = iseven(rank) ? self_prototype :
                             PencilArray{Float64}(undef, world_pen, 1)
    caught = false
    try
        DistTransposePlan(cfg; comm, nlev=1,
                          prototype=varying_comm_prototype)
    catch error
        caught = error isa ArgumentError
    end
    @test MPI.Allreduce(caught ? 1 : 0, min, comm) == 1
    MPI.Barrier(comm)

    # Presence and explicit array storage are collective constructor options;
    # rank-local branching here used to strand peers in Pencil construction.
    varying_presence = iseven(rank) ?
        PencilArray{Float64}(undef, world_pen, 1) : nothing
    caught = false
    try
        DistTransposePlan(
            cfg; comm, nlev=1, prototype=varying_presence,
            array_type=Array, real_type=Float64,
        )
    catch error
        caught = error isa ArgumentError
    end
    @test MPI.Allreduce(caught ? 1 : 0, min, comm) == 1
    MPI.Barrier(comm)

    varying_array_type = iseven(rank) ? Array : Matrix
    caught = false
    try
        DistTransposePlan(
            cfg; comm, nlev=1, array_type=varying_array_type,
            real_type=Float64,
        )
    catch error
        caught = error isa ArgumentError
    end
    @test MPI.Allreduce(caught ? 1 : 0, min, comm) == 1
    MPI.Barrier(comm)
end

@testset "DistTransposePlan exact call layouts" begin
    cfg = create_gauss_config(4, 7; nlon=10)
    plan = DistTransposePlan(cfg; comm, nlev=1)
    output = allocate_spectral(plan)
    input = allocate_spatial(plan)
    @test isdefined(ParExt, :_transpose_spatial_reference)
    if isdefined(ParExt, :_transpose_spatial_reference)
        spatial_reference = ParExt._transpose_spatial_reference(plan)
        @test spatial_reference === PencilFFTs.pencil_input(plan.fft_plan)
        for _ in 1:8
            ParExt._validate_transpose_call!(
                plan, :reused_spatial_reference;
                spatial=(input,), spectral=(output,),
            )
            @test ParExt._transpose_spatial_reference(plan) === spatial_reference
        end
    end
    transpose_source = read(joinpath(
        @__DIR__, "..", "..", "ext", "ParallelTransposeTransforms.jl",
    ), String)
    @test !occursin("spatial_reference = Pencil(", transpose_source)
    @test occursin("PencilFFTs.pencil_input(plan.fft_plan)", transpose_source)
    wrong_spatial_pen = PencilArrays.Pencil(
        Array, (plan.nlon, plan.nlat), (1,), comm,
    )
    wrong_spatial = PencilArray{Float64}(undef, wrong_spatial_pen, 1)
    fill!(parent(output), 19 + 3im)
    spectral_sentinel = copy(parent(output))
    @test_throws ArgumentError ParExt._validate_transpose_call!(
        plan, :wrong_spatial_layout;
        spatial=(wrong_spatial,), spectral=(output,),
    )
    @test parent(output) == spectral_sentinel
    MPI.Barrier(comm)

    wrong_spectral_pen = PencilArrays.Pencil(
        Array, PencilArrays.size_global(plan.spectral_pencil), (1,), comm,
    )
    wrong_spectral = PencilArray{ComplexF64}(
        undef, wrong_spectral_pen, 1,
    )
    fill!(parent(input), 23.0)
    spatial_sentinel = copy(parent(input))
    @test_throws ArgumentError ParExt._validate_transpose_call!(
        plan, :wrong_spectral_layout;
        spatial=(input,), spectral=(wrong_spectral,),
    )
    @test parent(input) == spatial_sentinel
    MPI.Barrier(comm)
end

@testset "transpose dist_analysis! vs serial (scalar)" begin
    for lmax in (32, 64)
        nlat = lmax + 2; nlon = 2 * lmax + 1
        cfg  = create_gauss_config(lmax, nlat; nlon = nlon)

        # Build reference: random spectral coefficients → serial synthesis → serial analysis
        a0 = zeros(ComplexF64, lmax + 1, lmax + 1)
        for m in 0:lmax, l in m:lmax
            sc = 1.0 / (1 + l)^2
            a0[l+1, m+1] = m == 0 ? complex(sc) : complex(sc, 0.5sc)
        end
        f_full = SHTnsKit.synthesis(cfg, a0; real_output = true)  # (nlat, nlon)
        a_ref  = SHTnsKit.analysis(cfg, f_full)                   # (lmax+1, mmax+1) reference

        # Build transpose plan and fill spatial PencilArray from f_full
        plan = DistTransposePlan(cfg; comm = comm, nlev = 1, use_rfft = true)
        f    = allocate_spatial(plan)   # real PencilArray, global (nlon, nlat), θ-distributed

        # range_local gives global index ranges for each logical dim:
        #   r[1] = φ range (1-based global column indices, typically 1:nlon on every rank)
        #   r[2] = θ range (1-based global row indices for this rank's slice)
        r = PencilArrays.range_local(pencil(f))
        # parent(f) layout: (n_phi_local, n_theta_local, nlev)
        for (il, ig) in enumerate(r[2]), (jl, jg) in enumerate(r[1])
            # f_full[ig, jg] = f_full[θ_global, φ_global]
            parent(f)[jl, il, 1] = f_full[ig, jg]
        end

        Alm = allocate_spectral(plan)
        dist_analysis!(plan, Alm, f)

        # Compare each rank's owned m-columns against the dense serial reference
        err = 0.0
        for (mi, m) in enumerate(plan.m_local), l in m:lmax
            err = max(err, abs(parent(Alm)[l+1, mi, 1] - a_ref[l+1, m+1]))
        end
        gerr = MPI.Allreduce(err, MPI.MAX, comm)
        rank == 0 && println("lmax=$lmax scalar analysis gerr=$gerr")
        @test gerr < 1e-8
    end
end

@testset "transpose dist_synthesis! round-trip (scalar)" begin
    for lmax in (32, 64)
        nlat = lmax + 2; nlon = 2 * lmax + 1
        cfg = create_gauss_config(lmax, nlat; nlon = nlon)

        # Build band-limited field from known spectral coefficients
        a0 = zeros(ComplexF64, lmax + 1, lmax + 1)
        for m in 0:lmax, l in m:lmax
            sc = 1.0 / (1 + l)^2
            a0[l+1, m+1] = m == 0 ? complex(sc) : complex(sc, 0.5sc)
        end
        f_full = SHTnsKit.synthesis(cfg, a0; real_output = true)  # (nlat, nlon) reference

        plan = DistTransposePlan(cfg; comm = comm, nlev = 1, use_rfft = true)

        # Fill distributed spatial field from serial reference
        f = allocate_spatial(plan)
        r = PencilArrays.range_local(pencil(f))   # r[1]=φ range, r[2]=θ range
        for (il, ig) in enumerate(r[2]), (jl, jg) in enumerate(r[1])
            parent(f)[jl, il, 1] = f_full[ig, jg]
        end

        # Forward: analysis
        Alm = allocate_spectral(plan)
        dist_analysis!(plan, Alm, f)

        # Reverse: synthesis — should recover f up to machine precision
        f2 = allocate_spatial(plan)
        dist_synthesis!(plan, f2, Alm)

        lerr = maximum(abs.(parent(f2) .- parent(f)))
        gerr = MPI.Allreduce(lerr, MPI.MAX, comm)
        rank == 0 && println("lmax=$lmax synthesis round-trip gerr=$gerr")
        @test gerr < 1e-8
    end
end

@testset "transpose SHT batched over levels (nlev>1)" begin
    lmax=48; nlat=lmax+2; nlon=2*lmax+1; nlev=4
    cfg=create_gauss_config(lmax,nlat;nlon=nlon)
    # distinct band-limited field per level
    a0 = [zeros(ComplexF64,lmax+1,lmax+1) for _ in 1:nlev]
    ffull = Vector{Matrix{Float64}}(undef, nlev)
    for lev in 1:nlev
        for m in 0:lmax,l in m:lmax; sc=(lev+0.3)/(1+l)^2; a0[lev][l+1,m+1]= m==0 ? complex(sc) : complex(sc,0.5sc); end
        ffull[lev]=SHTnsKit.synthesis(cfg,a0[lev];real_output=true)
    end
    plan=DistTransposePlan(cfg; comm=comm, nlev=nlev, use_rfft=true)
    f=allocate_spatial(plan); r=PencilArrays.range_local(pencil(f))  # (φ, θ, lev)
    for lev in 1:nlev, (il,ig) in enumerate(r[2]), (jl,jg) in enumerate(r[1])
        parent(f)[jl, il, lev] = ffull[lev][ig, jg]
    end
    Alm=allocate_spectral(plan); dist_analysis!(plan, Alm, f)
    # per-level analysis correctness vs serial
    err=0.0
    for lev in 1:nlev
        a_ref=SHTnsKit.analysis(cfg, ffull[lev])
        for (mi,m) in enumerate(plan.m_local), l in m:lmax
            err=max(err, abs(parent(Alm)[l+1, mi, lev] - a_ref[l+1, m+1]))
        end
    end
    gerr=MPI.Allreduce(err, MPI.MAX, comm); MPI.Comm_rank(comm)==0 && println("batched analysis gerr=$gerr")
    @test gerr < 1e-8
    # round-trip
    f2=allocate_spatial(plan); dist_synthesis!(plan, f2, Alm)
    rt=MPI.Allreduce(maximum(abs.(parent(f2).-parent(f))), MPI.MAX, comm)
    MPI.Comm_rank(comm)==0 && println("batched round-trip gerr=$rt")
    @test rt < 1e-8
end

@testset "transpose dist sphtor round-trip" begin
    for lmax in (32, 64)
        nlat=lmax+2; nlon=2*lmax+1; cfg=create_gauss_config(lmax,nlat;nlon=nlon)
        S0=zeros(ComplexF64,lmax+1,lmax+1); T0=copy(S0)
        for m in 0:lmax, l in max(1,m):lmax; sc=1/(1+l)^2; S0[l+1,m+1]=complex(sc, m==0 ? 0.0 : 0.5sc); T0[l+1,m+1]=complex(0.7sc, m==0 ? 0.0 : -0.3sc); end
        Vt_full, Vp_full = SHTnsKit.synthesis_sphtor(cfg, S0, T0; real_output=true)
        S_ref, T_ref = SHTnsKit.analysis_sphtor(cfg, Vt_full, Vp_full)   # serial reference
        plan=DistTransposePlan(cfg; comm=comm, nlev=1, use_rfft=true, with_vector=true)
        Vt=allocate_spatial(plan); Vp=allocate_spatial(plan)
        r=PencilArrays.range_local(pencil(Vt))   # (φ,θ,lev)
        for (il,ig) in enumerate(r[2]), (jl,jg) in enumerate(r[1])
            parent(Vt)[jl,il,1]=Vt_full[ig,jg]; parent(Vp)[jl,il,1]=Vp_full[ig,jg]
        end
        Slm=allocate_spectral(plan); Tlm=allocate_spectral(plan)
        dist_analysis_sphtor!(plan, Slm, Tlm, Vt, Vp)
        err=0.0
        for (mi,m) in enumerate(plan.m_local), l in max(1,m):lmax
            err=max(err, abs(parent(Slm)[l+1,mi,1]-S_ref[l+1,m+1]), abs(parent(Tlm)[l+1,mi,1]-T_ref[l+1,m+1]))
        end
        gerr=MPI.Allreduce(err, MPI.MAX, comm); MPI.Comm_rank(comm)==0 && println("lmax=$lmax sphtor analysis gerr=$gerr")
        @test gerr < 1e-7
        Vt2=allocate_spatial(plan); Vp2=allocate_spatial(plan)
        dist_synthesis_sphtor!(plan, Vt2, Vp2, Slm, Tlm)
        rt=MPI.Allreduce(max(maximum(abs.(parent(Vt2).-parent(Vt))), maximum(abs.(parent(Vp2).-parent(Vp)))), MPI.MAX, comm)
        MPI.Comm_rank(comm)==0 && println("lmax=$lmax sphtor round-trip gerr=$rt")
        @test rt < 1e-7
    end
end

@testset "transpose dist qst round-trip" begin
    lmax=48; nlat=lmax+2; nlon=2*lmax+1; cfg=create_gauss_config(lmax,nlat;nlon=nlon)
    Q0=zeros(ComplexF64,lmax+1,lmax+1); S0=copy(Q0); T0=copy(Q0)
    for m in 0:lmax, l in m:lmax; sc=1/(1+l)^2; Q0[l+1,m+1]= m==0 ? complex(sc) : complex(sc,0.4sc); end
    for m in 0:lmax, l in max(1,m):lmax; sc=1/(1+l)^2; S0[l+1,m+1]=complex(sc, m==0 ? 0.0 : 0.5sc); T0[l+1,m+1]=complex(0.7sc, m==0 ? 0.0 : -0.3sc); end
    Vr_full = SHTnsKit.synthesis(cfg, Q0; real_output=true)
    Vt_full, Vp_full = SHTnsKit.synthesis_sphtor(cfg, S0, T0; real_output=true)
    plan=DistTransposePlan(cfg; comm=comm, nlev=1, use_rfft=true, with_vector=true)
    Vr=allocate_spatial(plan); Vt=allocate_spatial(plan); Vp=allocate_spatial(plan)
    r=PencilArrays.range_local(pencil(Vr))
    for (il,ig) in enumerate(r[2]), (jl,jg) in enumerate(r[1])
        parent(Vr)[jl,il,1]=Vr_full[ig,jg]; parent(Vt)[jl,il,1]=Vt_full[ig,jg]; parent(Vp)[jl,il,1]=Vp_full[ig,jg]
    end
    Qlm=allocate_spectral(plan); Slm=allocate_spectral(plan); Tlm=allocate_spectral(plan)
    dist_analysis_qst!(plan, Qlm, Slm, Tlm, Vr, Vt, Vp)
    Vr2=allocate_spatial(plan); Vt2=allocate_spatial(plan); Vp2=allocate_spatial(plan)
    dist_synthesis_qst!(plan, Vr2, Vt2, Vp2, Qlm, Slm, Tlm)
    e = max(maximum(abs.(parent(Vr2).-parent(Vr))), maximum(abs.(parent(Vt2).-parent(Vt))), maximum(abs.(parent(Vp2).-parent(Vp))))
    gerr=MPI.Allreduce(e, MPI.MAX, comm); MPI.Comm_rank(comm)==0 && println("qst round-trip gerr=$gerr")
    @test gerr < 1e-7
end

@testset "transpose QST validates all six arrays before mutation" begin
    cfg = create_gauss_config(4, 7; nlon=12)
    plan = DistTransposePlan(
        cfg; comm=comm, nlev=1, use_rfft=true, with_vector=true,
    )
    Vr = allocate_spatial(plan)
    Vt = allocate_spatial(plan)
    Vp = allocate_spatial(plan)
    fill!(parent(Vr), 0.25)
    fill!(parent(Vt), -0.125)
    fill!(parent(Vp), 0.0625)
    Q = allocate_spectral(plan)
    S = allocate_spectral(plan)
    Tlm = allocate_spectral(plan)
    spectral_sentinel = ComplexF64(73, -19)
    fill!(parent(Q), spectral_sentinel)
    fill!(parent(S), spectral_sentinel)
    fill!(parent(Tlm), spectral_sentinel)
    bad_vp = PencilArray{Float32}(undef, pencil(Vp))
    fill!(parent(bad_vp), 0.0625f0)

    caught = false
    try
        dist_analysis_qst!(plan, Q, S, Tlm, Vr, Vt, bad_vp)
    catch error
        caught = error isa ArgumentError
    end
    @test MPI.Allreduce(caught ? 1 : 0, min, comm) == 1
    @test all(==(spectral_sentinel), parent(Q))
    @test all(==(spectral_sentinel), parent(S))
    @test all(==(spectral_sentinel), parent(Tlm))
    MPI.Barrier(comm)

    spatial_sentinel = 91.0
    fill!(parent(Vr), spatial_sentinel)
    fill!(parent(Vt), spatial_sentinel)
    fill!(parent(Vp), spatial_sentinel)
    bad_t = PencilArray{ComplexF32}(undef, pencil(Tlm))
    fill!(parent(bad_t), ComplexF32(0.1, -0.2))
    caught = false
    try
        dist_synthesis_qst!(plan, Vr, Vt, Vp, Q, S, bad_t)
    catch error
        caught = error isa ArgumentError
    end
    @test MPI.Allreduce(caught ? 1 : 0, min, comm) == 1
    @test all(==(spatial_sentinel), parent(Vr))
    @test all(==(spatial_sentinel), parent(Vt))
    @test all(==(spatial_sentinel), parent(Vp))
    MPI.Barrier(comm)
end

MPI.Finalize()
