@testset "synth and analys allocfree" begin

	L = 10
	cfg = SHTnsCfg(L)

	theta, phi = grid(cfg)

	y = cos.(theta)*sin.(phi)'

	x = analys(cfg, y)


	#test no-allocations
	b = @benchmark synth!($cfg,$x,$y)
	@test b.memory == 0
	b = @benchmark analys!($cfg,$y,$x)
	@test b.memory == 0

	y = complex(y)
	cfg = SHTnsCfg(L; transform=Complex)
	x = analys(cfg, y)

	b = @benchmark analys!($cfg,$y,$x)
	@test b.memory == 0
	b = @benchmark synth!($cfg,$x,$y)
	@test b.memory == 0

end

@testset "synth and analys" begin

	L = 32
	cfg = SHTnsCfg(L)

	for transform in (Real, Complex)
		cfg = SHTnsCfg(L; transform)
		q = zeros(ComplexF64, nlm(cfg))
		q[2:5] .= 1.0
		s = t = q

		
		x = synth(cfg, q)
		@test analys(cfg, x) ≈ q

		x,y = synth(cfg, q,s) 
		_q,_s = analys(cfg, x,y)
		@test _q ≈ q
		@test _s ≈ s
		
		x,y,z = synth(cfg, q,s,t) 
		_q,_s,_t = analys(cfg, x,y,z)
		@test _q ≈ q
		@test _s ≈ s
		@test _t ≈ t
	end
	
end

@testset "synth and analys batched" begin

	L = 32
	howmany = 10

	for transform in (Real, ) #Complex not working
		cfg = SHTnsCfg(L; howmany, transform)
	
		q = zeros(ComplexF64, howmany*nlm(cfg))
		for i in 0:howmany-1
			q[nlm(cfg)*i .+ 2:5] .= (i+1)*1.0 
		end
		s = t = q
		_q = similar(q)
		_s = similar(s)
		_t = similar(t)

		
		x = synth(cfg, q)
		analys!(cfg, x, _q)
		@test _q ≈ q
		# @test synth(cfg, q) ≈ x

		x,y = synth(cfg, q,s) 
		analys!(cfg, x, y, _s, _t)
		@test _s ≈ s
		@test _t ≈ t
		
		x,y,z = synth(cfg, q,s,t) 
		analys!(cfg, x, y, z, _q, _s, _t)
		# _q,_s,_t = analys(cfg, x,y,z)
		@test _q ≈ q
		@test _s ≈ s
		@test _t ≈ t


		q = zeros(ComplexF64, nlm(cfg), howmany)
		for i in 1:howmany
			q[2:5, i] .= i*1.0 
		end
		s = t = q
		_q = similar(q)
		_s = similar(s)
		_t = similar(t)

		
		x = synth(cfg, q)
		_q = analys(cfg, x)
		@test _q ≈ q
		# @test synth(cfg, q) ≈ x

		x,y = synth(cfg, q,s) 
		_s, _t = analys(cfg, x, y)
		@test _s ≈ s
		@test _t ≈ t
		
		x,y,z = synth(cfg, q,s,t) 
		_q, _s, _t = analys(cfg, x, y, z)
		@test _q ≈ q
		@test _s ≈ s
		@test _t ≈ t
	end
	
end

@testset "contiguous_phi=false vs. contiguous_phi=true" begin

	L = 32
	
	for transform in (Real,Complex), shtype in (SHTns.QuickInit(; contiguous_phi=false), SHTns.QuickInit(; contiguous_phi=true))
		cfg = SHTnsCfg(L; transform, shtype)
	
		q = zeros(ComplexF64, nlm(cfg))
		q[2:5] .= 1.0 
		s = t = q

		
		x = synth(cfg, q)
		@test analys(cfg, x) ≈ q
		# @test synth(cfg, q) ≈ x

		x,y = synth(cfg, q,s) 
		_q,_s = analys(cfg, x,y)
		@test _q ≈ q
		@test _s ≈ s
		
		x,y,z = synth(cfg, q,s,t) 
		_q,_s,_t = analys(cfg, x,y,z)
		@test _q ≈ q
		@test _s ≈ s
		@test _t ≈ t
	end
	
end

