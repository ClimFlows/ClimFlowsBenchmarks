using JLArrays
import Random

@testset "Grid types" begin
    # TODO: These grid/field types should be pulled out into constants rather than copy-pasted
    for G in (
            FullClenshawGrid,
            FullGaussianGrid,
            OctahedralGaussianGrid,
            OctahedralClenshawGrid,
            OctaminimalGaussianGrid,
            HEALPixGrid,
            OctaHEALPixGrid,
            FullHEALPixGrid,
            FullOctaHEALPixGrid,
        )

        full = RingGrids.full_grid_type(G)
        @test RingGrids.isfull(full)
        @test ~RingGrids.isreduced(full)
        @test full == RingGrids.full_grid_type(G)
        @test full <: RingGrids.AbstractFullGrid
        if ~(G <: RingGrids.AbstractFullGrid)
            @test G <: RingGrids.AbstractReducedGrid
        end
    end
end

@testset "Field types" begin
    # full ones
    for F in (
            FullClenshawField,
            FullGaussianField,
            FullHEALPixField,
            FullOctaHEALPixField,
        )

        @test RingGrids.isfull(F)
        @test ~RingGrids.isreduced(F)
        G = RingGrids.grid_type(F)
        @test RingGrids.isfull(G)
        @test RingGrids.field_type(RingGrids.grid_type(F)) <: F
    end

    for F in (
            OctahedralGaussianField,
            OctahedralClenshawField,
            OctaminimalGaussianField,
            HEALPixField,
            OctaHEALPixField,
        )

        @test RingGrids.isreduced(F)
        @test ~RingGrids.isfull(F)
        G = RingGrids.grid_type(F)
        @test RingGrids.isreduced(G)
        G = RingGrids.full_grid_type(F)
        @test RingGrids.isfull(G)
        @test RingGrids.field_type(RingGrids.grid_type(F)) <: F
    end
end

@testset "Grid indexing" begin
    for NF in (Float32, Float64)
        for Grid in (
                FullClenshawGrid,
                FullGaussianGrid,
                OctahedralGaussianGrid,
                OctahedralClenshawGrid,
                OctaminimalGaussianGrid,
                HEALPixGrid,
                OctaHEALPixGrid,
                FullHEALPixGrid,
                FullOctaHEALPixGrid,
            )
            for nlat_half in (4, 8, 16, 24, 32)

                npoints = RingGrids.get_npoints(Grid, nlat_half)
                grid = Grid(nlat_half)

                field1 = Field(grid)
                field2 = Field(zeros(npoints), grid)
                field3 = zeros(NF, Grid, nlat_half)

                @test size(field1) == size(field2) == size(field3)
                @test_throws DimensionMismatch Field(zeros(npoints - 1), grid)

                # getindex
                for ij in eachindex(field1)
                    field1[ij]
                end

                # setindex
                for ij in eachindex(field1)
                    field1[ij] = 0
                end

                @test all(field1 .== 0)
                @test field1 == field3
            end
        end
    end
end

@testset "Field generators" begin
    for NF in (Float32, Float64)
        for G in (
                FullClenshawGrid,
                FullGaussianGrid,
                OctahedralGaussianGrid,
                OctahedralClenshawGrid,
                OctaminimalGaussianGrid,
                HEALPixGrid,
                OctaHEALPixGrid,
                FullHEALPixGrid,
                FullOctaHEALPixGrid,
            )

            n = 4      # resolution parameter nlat_half
            grid = G(n)

            F1 = zeros(grid)
            F2 = zeros(grid, 1)
            F3 = zeros(NF, grid)
            F4 = zeros(NF, grid, 1)
            F5 = Field(zeros(NF, RingGrids.get_npoints(grid)), grid)
            F6 = Field(grid)
            F7 = Field(NF, grid)
            F8 = zero(F1)

            @test F1 == F2[:, 1]
            @test F1 == F3
            @test F1 == F4[:, 1]
            @test F1 == F5
            @test F1 == F6
            @test F1 == F7
            @test F1 == F8

            @test all(F1 .== F2)
            @test all(F2 .== F1)
            @test all(F1 .== F3)
            @test all(F1 .== F4)
            @test all(F1 .== F5)
            @test all(F1 .== F6)
            @test all(F1 .== F7)
            @test all(F1 .== F8)

            # check that they are deep copies
            F1[1] = 1
            @test F1[1] == 1
            @test F2[1] == 0
            @test F3[1] == 0
            @test F4[1] == 0
            @test F5[1] == 0
            @test F6[1] == 0
            @test F7[1] == 0
            @test F8[1] == 0

            @test eltype(F1) == eltype(F2) == eltype(F6) == eltype(F8)
            @test eltype(F3) == eltype(F4) == eltype(F5) == eltype(F7) == NF
        end
    end
end

@testset "Field{T, N, A, G}(data, grid) skips no-op cast" begin
    # Regression: under Reactant, `T.(data)` with `eltype(data) === T` traces as a
    # self-recursive `copy(::Broadcasted)` that blows the Julia stack. The constructor
    # must pass `data` through identity-ically when the eltype already matches.
    grid = HEALPixGrid(4)
    data = zeros(Float32, RingGrids.get_npoints(grid))
    F = typeof(Field(data, grid))   # Field{Float32, 1, Vector{Float32}, HEALPixGrid{...}}

    field_same = F(data, grid)
    @test field_same.data === data   # identity, no broadcast/copy

    data64 = zeros(Float64, RingGrids.get_npoints(grid))
    field_cast = F(data64, grid)
    @test eltype(field_cast) === Float32
    @test field_cast.data !== data64   # broadcast/cast ran
end

@testset "Field generators: ones" begin
    for NF in (Float32, Float64)
        for F in (
                FullClenshawField,
                FullGaussianField,
                OctahedralGaussianField,
                OctahedralClenshawField,
                OctaminimalGaussianField,
                HEALPixField,
                OctaHEALPixField,
                FullHEALPixField,
                FullOctaHEALPixField,
            )

            n = 4      # resolution parameter nlat_half
            f1 = ones(F, n)
            @test all(f1 .== 1)
            @test eltype(f1) == Float64

            f2 = ones(F{NF}, n)
            @test all(f2 .== 1)
            @test eltype(f2) == NF
        end
    end
end

@testset "Field generators: rand, randn" begin
    for NF in (Float32, Float64)
        for G in (
                FullClenshawGrid,
                FullGaussianGrid,
                OctahedralGaussianGrid,
                OctahedralClenshawGrid,
                OctaminimalGaussianGrid,
                HEALPixGrid,
                OctaHEALPixGrid,
                FullHEALPixGrid,
                FullOctaHEALPixGrid,
            )

            n = 4      # resolution parameter nlat_half
            G1 = rand(G, n)
            @test eltype(G1) == RingGrids.DEFAULT_NF # that's the default

            G1 = randn(G, n)
            @test eltype(G1) == RingGrids.DEFAULT_NF # that's the default

            G1 = rand(NF, G, n)
            @test eltype(G1) == NF

            G1 = randn(NF, G, n)
            @test eltype(G1) == NF
        end
    end
end

@testset "Field generators: rand, randn with rng" begin
    for f in (rand, randn)
        n = 4      # resolution parameter nlat_half
        grid = OctahedralGaussianGrid(n)

        # same seed = same field, reproducibility
        @test f(Random.Xoshiro(123), grid) == f(Random.Xoshiro(123), grid)
        @test f(Random.Xoshiro(123), grid, 2) == f(Random.Xoshiro(123), grid, 2)

        # rng doesn't change type or size compared to no rng
        for NF in (Float32, Float64)
            F1 = f(Random.Xoshiro(123), NF, grid, 2)
            F2 = f(NF, grid, 2)
            @test typeof(F1) == typeof(F2)
            @test size(F1) == size(F2)

            F1 = f(Random.Xoshiro(123), NF, OctahedralGaussianGrid, n)
            F2 = f(NF, OctahedralGaussianGrid, n)
            @test typeof(F1) == typeof(F2)
            @test size(F1) == size(F2)

            F1 = f(Random.Xoshiro(123), OctahedralGaussianField{NF}, n)
            F2 = f(OctahedralGaussianField{NF}, n)
            @test typeof(F1) == typeof(F2)
            @test size(F1) == size(F2)
        end
    end
end

@testset "Field generators: undef" begin
    for NF in (Float32, Float64)
        for F in (
                FullClenshawField,
                FullGaussianField,
                OctahedralGaussianField,
                OctahedralClenshawField,
                OctaminimalGaussianField,
                HEALPixField,
                OctaHEALPixField,
                FullHEALPixField,
                FullOctaHEALPixField,
            )

            n = 4      # resolution parameter nlat_half
            field1 = F(undef, n)
            @test eltype(field1) == RingGrids.DEFAULT_NF     # that's the default NF

            field2 = F{NF}(undef, n)
            @test eltype(field2) == NF
        end
    end
end

@testset "FullGrids conversions to/from Arrays" begin
    for idims in ((), (5,), (5, 5))
        NF = Float64
        N = length(idims) + 1
        data = rand(8, 4, idims...)
        field = FullGaussianField(data, input_as = Matrix)
        @test Array(field, as = Matrix) == data

        data = rand(8, 3, idims...)
        field = FullClenshawField(data, input_as = Matrix)
        @test Array(field, as = Matrix) == data

        data = rand(8, 3, idims...)
        field = FullHEALPixField(data, input_as = Matrix)
        @test Array(field, as = Matrix) == data

        data = rand(8, 3, idims...)
        field = FullOctaHEALPixField(data, input_as = Matrix)
        @test Array(field, as = Matrix) == data
    end
end

@testset "Grid indices" begin
    for G in (
            FullClenshawGrid,
            FullGaussianGrid,
            OctahedralGaussianGrid,
            OctahedralClenshawGrid,
            OctaminimalGaussianGrid,
            HEALPixGrid,
            OctaHEALPixGrid,
            FullHEALPixGrid,
            FullOctaHEALPixGrid,
        )

        n = 4      # resolution parameter nlat_half
        field = zeros(G, n)

        # precompute indices and boundscheck
        rings = RingGrids.eachring(field, field)

        for (j, ring) in enumerate(rings)
            for ij in ring
                field[ij] += 1
            end
        end

        for ij in RingGrids.eachgridpoint(field)
            @test field[ij] == 1
        end

        @test sum(field) == RingGrids.get_npoints(G, n)
    end
end

@testset "Ring indices" begin
    @testset for G in (
            FullClenshawGrid,
            FullGaussianGrid,
            OctahedralGaussianGrid,
            OctahedralClenshawGrid,
            OctaminimalGaussianGrid,
            HEALPixGrid,
            OctaHEALPixGrid,
            FullHEALPixGrid,
            FullOctaHEALPixGrid,
        )

        for n in [8, 16, 24, 32]      # resolution parameter nlat_half
            grid = G(n)

            # precompute indices and boundscheck
            rings = RingGrids.eachring(grid)
            rings2 = [RingGrids.each_index_in_ring(grid, j) for j in 1:RingGrids.get_nlat(grid)]

            @test rings == rings2
        end
    end
end

@testset "Ring indices from fields" begin

    f1 = zeros(OctahedralGaussianGrid, 2)
    f2 = zeros(OctahedralGaussianGrid, 2, 1)    # matches above
    f3 = zeros(OctahedralGaussianGrid, 2, 2)    # matches horizontally only
    f4 = zeros(OctahedralClenshawGrid, 2)       # does not match above

    @test eachring(f1) == eachring(f1, f2) == eachring(f1, f2, f2, f1)
    @test eachring(f1) == eachring(f2, f3)
    @test_throws DimensionMismatch eachring(f1, f4)
    @test_throws DimensionMismatch eachring(f2, f4)
    @test_throws DimensionMismatch eachring(f3, f4)

    @test RingGrids.fields_match(f1, f3) == false
    @test RingGrids.fields_match(f2, f3) == false
    @test RingGrids.fields_match(f1, f3, horizontal_only = true)
    @test RingGrids.fields_match(f2, f3, horizontal_only = true)
end

@testset "Ring indices from grids" begin
    g1 = OctahedralGaussianGrid(2)
    g2 = OctahedralClenshawGrid(2)

    @test eachring(g1) != eachring(g2)
    @test eachring(g1) == eachring(g1, g1)
    @test_throws DimensionMismatch eachring(g1, g2)
    @test_throws DimensionMismatch eachring(g2, g1)

    @test RingGrids.grids_match(g1, g1)
    @test RingGrids.grids_match(g1, g2) == false
end

@testset "Field broadcasting" begin
    n = 2
    @testset for F in (
            FullClenshawField,
            FullGaussianField,            # don't test all to speed up CI
            OctahedralGaussianField,
            # OctahedralClenshawGrid,
            # OctaminimalGaussianGrid,
            HEALPixField,
            # OctaHEALPixGrid,
            # FullHEALPixGrid,
            # FullOctaHEALPixGrid,
        )

        @test zeros(F, n) .+ 1 == ones(F, n)
        @test ones(F, n) .- 1 == zeros(F, n)
        @test ones(F, n) / 1 == ones(F, n)
        @test zeros(F, n) + ones(F, n) == ones(F, n)
        @test 2ones(F, n) == ones(F, n) + ones(F, n)

        # don't promote to Array
        for s in ((n,), (n, n), (n, n, n), (n, n, n, n))
            field = zeros(F, s...)
            @test (field + field) isa Field
            @test (field .+ field) isa Field
            @test (field - field) isa Field
            @test (field .- field) isa Field
            @test (field .* field) isa Field
            @test (field ./ field) isa Field
            @test 2field isa Field
        end

        # promote types, Field{Float16} -> Field{Float64} etc
        @test all(ones(F{Float16}, n) * 2.0 .=== 2.0)
        @test all(ones(F{Float16}, n) * 2.0f0 .=== 2.0f0)
        @test all(ones(F{Float32}, n) * 2.0 .=== 2.0)

        # promote types across grids
        @test all(ones(F{Float16}, n) + ones(F{Float32}, n) .=== 2.0f0)
        @test all(ones(F{Float16}, n) + ones(F{Float64}, n) .=== 2.0)
        @test all(ones(F{Float32}, n) + ones(F{Float64}, n) .=== 2.0)

        # promote types across grids
        @test all(ones(F{Float16}, n) - ones(F{Float32}, n) .=== 0.0f0)
        @test all(ones(F{Float16}, n) - ones(F{Float64}, n) .=== 0.0)
        @test all(ones(F{Float32}, n) - ones(F{Float64}, n) .=== 0.0)

        # promote types across grids
        # f3 = ones(F{Float16}, n) .* ones(F{Float32}, n)
        @test all((ones(F{Float16}, n) .* ones(F{Float32}, n)) .=== 1.0f0)
        @test all(ones(F{Float16}, n) .* ones(F{Float64}, n) .=== 1.0)
        @test all(ones(F{Float32}, n) .* ones(F{Float64}, n) .=== 1.0)

        # promote types across grids
        @test all(ones(F{Float16}, n) ./ ones(F{Float32}, n) .=== 1.0f0)
        @test all(ones(F{Float16}, n) ./ ones(F{Float64}, n) .=== 1.0)
        @test all(ones(F{Float32}, n) ./ ones(F{Float64}, n) .=== 1.0)

        # dimension mismatches, but still broadcasting
        field1 = rand(F, n)
        field2 = rand(F, n, 1)
        field2_2 = rand(F, n, 2)
        field3 = rand(F, n, 1, 1)

        @test (field1 .* field2)[:, 1] == (field1 .* field2[:, 1])
        @test (field2 .* field1)[:, 1] == (field1 .* field2[:, 1])
        @test (field2 .* field3)[:, 1, 1] == (field2[:, 1] .* field3[:, 1, 1])
        @test (field1 .* field2_2)[:, 1] == (field1 .* field2_2[:, 1])
        @test (field1 .* field2_2)[:, 2] == (field1 .* field2_2[:, 2])

        # mixed-rank broadcast promotes to the higher rank, order-independent
        # (a non-commutative BroadcastStyle rule would error or disagree here)
        @test ndims(field1 .* field2_2) == 2
        @test ndims(field2_2 .* field1) == 2
        @test (field1 .* field2_2) == (field2_2 .* field1)
    end
end

@testset "N-dimensional indexing" begin
    m, n, p = 2, 3, 4
    @testset for F in (
            FullClenshawField,
            FullGaussianField,
            OctahedralGaussianField,
            OctahedralClenshawField,
            OctaminimalGaussianField,
            HEALPixField,
            OctaHEALPixField,
            FullHEALPixField,
            FullOctaHEALPixField,
        )

        field = rand(F, m, n, p)
        @test field[:, 1, 1] isa F
        @test field[1] == field.data[1]
        @test field[1, 1, 1] == field.data[1, 1, 1]

        @test field[1:2, 1:2, 1:2] == field.data[1:2, 1:2, 1:2]
        @test field[1, 1, :] == field.data[1, 1, :]
        @test field[:, 1:2, 1:2].data == field.data[:, 1:2, 1:2]

        idx = CartesianIndex((1, 2, 3))
        @test field[idx] == field.data[idx]

        ids = CartesianIndices((m, n, p))
        @test field[ids] == field.data[ids]
        @test field[ids] isa Array
    end
end

@testset "Loop indexing" begin
    n = 2
    @testset for F in (
            FullClenshawField,
            FullGaussianField,
            OctahedralGaussianField,
            OctahedralClenshawField,
            OctaminimalGaussianField,
            HEALPixField,
            OctaHEALPixField,
            FullHEALPixField,
            FullOctaHEALPixField,
        )

        for s in ((n,), (n, n), (n, n, n), (n, n, n, n))
            field = zeros(F, s...)

            for k in eachlayer(field)
                for (j, ring) in enumerate(eachring(field))
                    for ij in ring
                        field[ij, k] = 1
                    end
                end
            end
            @test all(field .== 1)
        end
    end
end

@testset "AbstractField: GPU (JLArrays)" begin
    NF = Float32
    @testset for F in (
            FullClenshawField,
            # FullGaussianField,            # don't test all for CI speedup
            OctahedralGaussianField,
            # OctahedralClenshawField,
            # OctaminimalGaussianField,
            HEALPixField,
            # OctaHEALPixField,
            # FullHEALPixField,
            # FullOctaHEALPixField,
        )
        s = (2, 3, 4)
        ndims = length(s)

        field_cpu = randn(F{NF}, s...)
        jl_arch = architecture(JLArray)
        # constructors/adapt
        field = on_architecture(jl_arch, field_cpu)
        field2 = Field(on_architecture(jl_arch, field_cpu.data), field.grid)
        @test field == field2

        # broadcasting doesn't escape
        @test field + field isa Field{NF, ndims, JLArray{NF, ndims}}
        @test field .+ field isa Field{NF, ndims, JLArray{NF, ndims}}
        @test field_cpu + field_cpu isa Field{NF, ndims, Array{NF, ndims}}
        @test field_cpu .+ field_cpu isa Field{NF, ndims, Array{NF, ndims}}

        # getindex
        @test field[1, :, :] isa JLArray{NF, 2}
        @test field[:, 1, 1] isa Field{NF, 1, JLArray{NF, 1}}
        for ring in eachring(field)
            @test field[ring, :, :] == on_architecture(jl_arch, field_cpu[ring, :, :])
            @test Array(field[ring, :, :]) == field_cpu[ring, :, :]
        end

        # setindex!
        v = JLArray(rand(NF, s[3]))
        field[1, 1, :] .= v                # with .
        @test field[1, 1, :] == v

        v = JLArray(rand(NF, s[3]))
        field[2, 1, :] = v                 # without .
        @test field[2, 1, :] == v

        # with other field {Array}
        v = rand(F, s[1])
        field[:, 1, 1] = v                 # conversion to float64 -> float32
        @test Array(field[:, 1, 1].data) ≈ v

        # with other field {JLArray}
        v = on_architecture(jl_arch, rand(F, s[1]))
        field[:, 1, 2] = v
        @test field[:, 1, 2].data ≈ v.data

        # fill! (returns a Field, not the bare underlying array)
        filled = fill!(field, 2.0)
        @test all(field .== 2)
        @test filled isa Field{NF, ndims, JLArray{NF, ndims}}

        # clamp! (uses `field.data`'s clamp! to avoid scalar indexing on GPU)
        field3 = on_architecture(jl_arch, randn(F{NF}, s...))
        clamped = clamp!(field3, NF(-0.5), NF(0.5))
        @test clamped isa Field{NF, ndims, JLArray{NF, ndims}}
        @test all(-0.5 .<= clamped .<= 0.5)
    end
end

@testset "Zonal mean" begin
    @testset for NF in (Int32, Int64, Float16, Float32, Float64)
        @testset for Grid in (
                FullClenshawGrid,
                FullGaussianGrid,
                OctahedralGaussianGrid,
                OctahedralClenshawGrid,
                OctaminimalGaussianGrid,
                HEALPixGrid,
                OctaHEALPixGrid,
                FullHEALPixGrid,
                FullOctaHEALPixGrid,
            )
            nlat_half = 4
            grid = Grid(nlat_half)
            npoints = RingGrids.get_npoints(grid)
            field = Field(1:npoints, grid)

            zm = zonal_mean(field)

            for (j, m) in enumerate(zonal_mean(field))
                @test m == sum(RingGrids.eachring(field)[j]) / RingGrids.get_nlon_per_ring(grid, j)
            end
        end
    end
end

@testset "Field unaliascopy" begin
    field = rand(FullGaussianField, 4)
    field_copy = Base.unaliascopy(field)
    @test field_copy == field && field_copy.data !== field.data
end

@testset "nonparametric types" begin
    @test RingGrids.nonparametric_type(Array) == Array
    @test RingGrids.nonparametric_type(Array{Float32}) == Array
    @test RingGrids.nonparametric_type(Array{Float32, 1}) == Array
    @test RingGrids.nonparametric_type(SubArray) == SubArray
    @test RingGrids.nonparametric_type(SubArray{Float32}) == SubArray
    @test RingGrids.nonparametric_type(SubArray{Float32, 1}) == SubArray
    @test RingGrids.nonparametric_type(SubArray{Float32, 1, Array}) == Array
    @test RingGrids.nonparametric_type(SubArray{Float32, 1, Array{Float32, 1}}) == Array
end

@testset "ArrayDimensions" begin
    using SpeedyWeatherInternals.ArrayDimensions: XY, XYZ, XYT, XYZT, hastime, hasvertical

    grid = FullGaussianGrid(4)

    # default dims is XY (2D horizontal)
    F2 = zeros(grid)
    @test F2.dims isa XY
    @test !hastime(F2)
    @test !hasvertical(F2)

    # explicit 3D horizontal + vertical
    F3z = zeros(grid, XYZ(), 3)
    @test F3z.dims isa XYZ
    @test !hastime(F3z)
    @test hasvertical(F3z)

    # explicit 3D horizontal + time
    F3t = zeros(grid, XYT(), 3)
    @test F3t.dims isa XYT
    @test hastime(F3t)
    @test !hasvertical(F3t)

    # explicit 4D horizontal + vertical + time
    F4 = zeros(grid, XYZT(), 3, 2)
    @test F4.dims isa XYZT
    @test hastime(F4)
    @test hasvertical(F4)

    # dims are preserved through similar, zero, and field_view
    F3z_sim = similar(F3z)
    @test F3z_sim.dims isa XYZ

    F3z_zero = zero(F3z)
    @test F3z_zero.dims isa XYZ

    F3z_view = field_view(F3z, :, 1)
    @test F3z_view.dims isa XY

    F3z_range_view = field_view(F3z, :, 1:2)
    @test F3z_range_view.dims isa XYZ

    # getindex with integer drops dims; range preserves
    @test F3z[:, 1].dims isa XY
    @test F3z[:, 1:2].dims isa XYZ

    # 4D: two explicit non-horizontal indices
    @test F4[:, 1:3, 1].dims isa XYZ   # drop time, keep vertical range
    @test F4[:, 1, 1].dims isa XY      # drop both vertical and time
end

@testset "Field concatenation" begin
    grid = FullGaussianGrid(4)

    # Check that trivial case returns same Field
    F1 = Field(grid, 1)
    @test cat(F1, dims = 2) == F1

    # Concatenate two fields
    F1 = Field(grid, 1) .+ 1
    F2 = Field(grid, 2) .+ 2
    F3 = cat(F1, F2, dims = 2)
    @test F3 isa FullGaussianField
    @test F3.grid === grid
    @test size(F3, 2) == 3
    @test all(F3[:, 1] .≈ F1[:, 1]) && all(F3[:, 2:3] .≈ F2[:, 1])

    # Concatenate N fields along dimension 3
    N = 5
    Fs = [Field(grid, 1, i) for i in 1:N]
    F3 = cat(Fs..., dims = 3)
    @test F3 isa FullGaussianField
    @test F3.grid === grid
    @test size(F3, 3) == sum(1:N)

    # Concatenate along two dimensions at once
    F3 = cat(Fs..., dims = (2, 3))
    @test F3 isa FullGaussianField
    @test F3.grid === grid
    @test size(F3, 2) == N
    @test size(F3, 3) == sum(1:N)
    # also for array dims (reversed order for good measure)
    F3 = cat(Fs..., dims = [3, 2])
    @test F3 isa FullGaussianField
    @test F3.grid === grid
    @test size(F3, 2) == N
    @test size(F3, 3) == sum(1:N)

    # Check singleton case for iterable dims
    F3 = cat(F1, F2, dims = [2])
    @test F3 isa FullGaussianField
    @test F3.grid === grid
    @test size(F3, 2) == 3

    # Check that concatenation along dimension 1 fails
    @test_throws AssertionError cat(F1, F2, dims = 1)
end

@testset "get_londlatds for full grids" begin
    for G in (FullClenshawGrid, FullGaussianGrid, FullHEALPixGrid, FullOctaHEALPixGrid)
        for nlat_half in (1, 2, 3, 8)
            (G <: FullHEALPixGrid && isodd(nlat_half)) && continue
            grid = G(nlat_half)
            londs, latds = RingGrids.get_londlatds(grid)
            lond = RingGrids.get_lond(grid)
            latd = RingGrids.get_latd(grid)

            @test length(londs) == length(latds) == RingGrids.get_npoints(grid)
            for (j, ring) in enumerate(eachring(grid))
                @test londs[ring] == lond
                @test all(latds[ring] .== latd[j])
            end
        end
    end
end
