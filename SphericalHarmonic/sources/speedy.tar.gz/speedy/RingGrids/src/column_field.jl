import LinearAlgebra.transpose
import LinearAlgebra.transpose!

"""
ColumnField is a version of `Field` with data stored in a column-major format. 
It is used e.g. to represent data on a vertical column of a grid in column-based
parametrizations. 
$(TYPEDFIELDS)

A ColumnField can be easily created from a `Field` by transposing it:

```julia
field = Field(grid, k...)
column_field = transpose(field)
```
"""
struct ColumnField{T, N, ArrayType <: AbstractArray, Grid <: AbstractGrid, Dims} <: AbstractField{T, N, ArrayType, Grid, Dims}
    data::ArrayType
    grid::Grid
    dims::Dims

    function ColumnField(data, grid, dims = default_column_field_dimensions(data))
        data_matches_grid(data, grid; horizontal_dim = 2) || throw(DimensionMismatch(data, grid))
        return new{eltype(data), ndims(data), typeof(data), typeof(grid), typeof(dims)}(data, grid, dims)
    end
end

const ColumnField2D = ColumnField{T, 1} where {T}
const ColumnField3D = ColumnField{T, 2} where {T}
const ColumnField4D = ColumnField{T, 3} where {T}

const FullColumnField = ColumnField{T, N, ArrayType, Grid} where {T, N, ArrayType, Grid <: AbstractFullGrid}
const ReducedColumnField = ColumnField{T, N, ArrayType, Grid} where {T, N, ArrayType, Grid <: AbstractReducedGrid}

# default constructors
ColumnField(grid::AbstractGrid, k...) = transpose(zeros(grid, k...))
ColumnField(::Type{T}, grid::AbstractGrid, k...) where {T} = transpose(zeros(T, grid, k...))
(::Type{<:ColumnField{T}})(data::AbstractArray, grid::AbstractGrid) where {T} =
    ColumnField(eltype(data) === T ? data : T.(data), grid)

default_column_field_dimensions(::AbstractVector) = ArrayDimensions.XY()
default_column_field_dimensions(::AbstractArray) = ArrayDimensions.ZXY()

# TYPES
Architectures.nonparametric_type(::Type{<:ColumnField}) = ColumnField
grid_type(::Type{<:ColumnField{T, N, A, G}}) where {T, N, A, G} = G
Architectures.array_type(::Type{<:ColumnField{T, N, A, G}}) where {T, N, A, G} = A

# CONVERSION from Field
LinearAlgebra.transpose(field::Field) = transpose_safe(field)
LinearAlgebra.transpose!(field::Field) = transpose_unsafe!(field, similar(field.data))

# and back to Field
LinearAlgebra.transpose(field::ColumnField) = transpose_safe(field)
LinearAlgebra.transpose!(field::ColumnField) = transpose_unsafe!(field, similar(field.data))

# safe version which allocates a new field
function transpose_safe(field::Field)
    data_transposed = collect(permutedims(field.data, (2, 1, 3:ndims(field)...)))
    return ColumnField(data_transposed, field.grid)
end

# 2D version
function transpose_safe(field::Field2D)
    return ColumnField(collect(transpose(field.data)), field.grid)
end

# tranpose is defined here as swapping first two dimensions
function _size_of_transpose(data::AbstractArray)
    IJ, K, L... = size(data)
    return (K, IJ, L...)
end

# for vectors (i.e. Field2D) return original size
_size_of_transpose(data::AbstractVector) = (1, length(data))

# unsafe version that leaves the origional data corrupted (=transposed even though `field` doesn't indicate this)
# but returns a ColumnField/Field view onto the same memory
transpose_unsafe!(field::Field, scratch::AbstractArray) = ColumnField(_data_transpose!(field.data, scratch), field.grid)
transpose_unsafe!(field::ColumnField, scratch::AbstractArray) = Field(_data_transpose!(field.data, scratch), field.grid)

function _data_transpose!(data::AbstractArray, scratch::AbstractArray)
    @boundscheck length(scratch) == length(data) || throw(BoundsError(scratch, data))
    scratch_reshaped = reshape(scratch, _size_of_transpose(data))           # so scratch input can be of size(field) or its tranpose
    permutedims!(scratch_reshaped, data, (2, 1, 3:ndims(data)...))          # transpose into scratch memory
    vec(data) .= vec(scratch_reshaped)                                      # copy back (scratch memory is free again after this)
    return reshape(data, _size_of_transpose(data))
end

# 2D version, this is actually safe as no data reordering required
_data_transpose!(data::AbstractVector, scratch::AbstractArray) = reshape(data, _size_of_transpose(data))

# safe version which allocates a new field
function transpose_safe(field::ColumnField)
    data_transposed = collect(permutedims(field.data, (2, 1, 3:ndims(field)...)))
    return Field(data_transposed, field.grid)
end

# SIMILAR AND UNDEF CONSTRUCTORS
# data with same type T but new size (=new grid)
function Base.similar(
        field::ColumnField,
        nlayers::Integer,
        nlat_half::Integer,
        k::Integer...
    )
    # use same architecture though
    new_grid = typeof(field.grid)(nlat_half, field.grid.architecture)
    similar_data = similar(field.data, nlayers, get_npoints(new_grid), k...)
    return ColumnField(similar_data, new_grid)
end

# data with new type T and new size
function Base.similar(
        field::ColumnField,
        ::Type{Tnew},
        nlayers::Integer,
        nlat_half::Integer,
        k::Integer...
    ) where {Tnew}
    # use same architecture though
    new_grid = typeof(field.grid)(nlat_half, field.grid.architecture)
    similar_data = similar(field.data, Tnew, nlayers, get_npoints(new_grid), k...)
    return ColumnField(similar_data, new_grid)
end

# general version with ArrayType{T, N}(undef, ...) generator
function (::Type{F})(
        ::UndefInitializer,
        nlayers::Integer,
        nlat_half::Integer,
        k::Integer...,
    ) where {F <: ColumnField{T, N, ArrayType, Grid}} where {T, N, ArrayType, Grid <: AbstractGrid{Architecture}} where {Architecture}
    # this (inevitably) creates a new grid and architecture instance
    grid = nonparametric_type(Grid)(nlat_half, Architecture())
    # TODO this should allocate on the device
    data = nonparametric_type(ArrayType){T}(undef, nlayers, get_npoints(grid), k...)
    return ColumnField(data, grid)
end

# in case Architecture is not provided use DEFAULT_ARCHITECTURE
function (::Type{F})(
        ::UndefInitializer,
        nlayers::Integer,
        nlat_half::Integer,
        k::Integer...,
    ) where {F <: ColumnField{T, N, ArrayType, Grid}} where {T, N, ArrayType, Grid <: AbstractGrid}
    grid = nonparametric_type(Grid)(nlat_half, DEFAULT_ARCHITECTURE())
    data = nonparametric_type(ArrayType){T}(undef, nlayers, get_npoints(grid), k...)
    return ColumnField(data, grid)
end

# in case only grid is provided (e.g. FullGaussianField) use Float64, Array, DEFAULT_ARCHITECTURE
function (::Type{F})(
        ::UndefInitializer,
        nlayers::Integer,
        nlat_half::Integer,
        k::Integer...,
    ) where {F <: ColumnField}
    Grid = grid_type(F)
    grid = nonparametric_type(Grid)(nlat_half, DEFAULT_ARCHITECTURE())
    data = Array{DEFAULT_NF}(undef, nlayers, get_npoints(grid), k...)
    return ColumnField(data, grid)
end

# in case only number format is provided use Array and DEFAULT_ARCHITECTURE
function (::Type{F})(
        ::UndefInitializer,
        nlayers::Integer,
        nlat_half::Integer,
        k::Integer...,
    ) where {F <: ColumnField{T}} where {T}
    Grid = grid_type(F)
    grid = nonparametric_type(Grid)(nlat_half, DEFAULT_ARCHITECTURE())
    data = Array{T}(undef, nlayers, get_npoints(grid), k...)
    return ColumnField(data, grid)
end

#  same as above but with N (ignored though as obtained from integer arguments)
function (::Type{F})(
        ::UndefInitializer,
        nlayers::Integer,
        nlat_half::Integer,
        k::Integer...,
    ) where {F <: ColumnField{T, N}} where {T, N}
    Grid = grid_type(F)
    grid = nonparametric_type(Grid)(nlat_half, DEFAULT_ARCHITECTURE())
    data = Array{T}(undef, nlayers, get_npoints(grid), k...)
    return ColumnField(data, grid)
end

# in case ArrayType is provided use that!
function (::Type{F})(
        ::UndefInitializer,
        nlayers::Integer,
        nlat_half::Integer,
        k::Integer...,
    ) where {F <: ColumnField{T, N, ArrayType}} where {T, N, ArrayType}
    Grid = grid_type(F)
    grid = nonparametric_type(Grid)(nlat_half, DEFAULT_ARCHITECTURE())
    data = nonparametric_type(ArrayType){T}(undef, nlayers, get_npoints(grid), k...)
    return ColumnField(data, grid)
end

# Some ARITHMETICS with regular Fields
add!(field::Field, column_field::ColumnField) = field .+= transpose(column_field)
add!(column_field::ColumnField, field::Field) = column_field .+= transpose(field)

function Architectures.on_architecture(arch, field::ColumnField{T, N, ArrayType, Grid}) where {T, N, ArrayType, Grid}
    adapted_data = on_architecture(arch, field.data)
    if ismatching(field.grid, typeof(adapted_data))
        return ColumnField(adapted_data, on_architecture(arch, field.grid))
    else # if not matching, create new grid with other architecture
        #@warn "Adapting field to new architecture with $(typeof(adapted_data))"
        return ColumnField(adapted_data, Grid(field.grid, architecture(typeof(adapted_data))))
    end
end
