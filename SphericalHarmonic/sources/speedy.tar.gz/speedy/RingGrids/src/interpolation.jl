abstract type AbstractGridGeometry end

"""Contains general precomputed arrays describing the grid.
$(TYPEDFIELDS)"""
struct GridGeometry{
        Grid,
        VectorType,
        VectorIntType,
        VectorRange,
        IntType,
    } <: AbstractGridGeometry
    grid::Grid                  # grid, e.g. FullGaussianGrid

    nlat_half::IntType          # number of latitude rings on one hemisphere (Eq. incl)
    nlat::IntType               # total number of latitude rings
    npoints::IntType            # total number of grid points
    londs::VectorType           # longitudes of every grid point 0˚ to 360˚E
    latd::VectorType            # latitude of each ring, incl north pole 90˚N, ..., south pole -90˚N

    nlons::VectorIntType        # number of longitudinal points per ring
    ring_starts::VectorIntType  # first flat index ij of each ring
    lon_offsets::VectorType     # longitude offsets of first grid point per ring

    # rings, GPU/architecture copy (if needed) of grid.rings
    rings::VectorRange
end

GridGeometry(field::AbstractField; kwargs...) = GridGeometry(field.grid; NF = eltype(field), kwargs...)

Adapt.@adapt_structure GridGeometry

"""
$(TYPEDSIGNATURES)
Precomputed arrays describing the geometry of the Grid with resolution `nlat_half`.
Contains longitudes, latitudes of grid points, their ring index j and their
unravelled indices ij."""
function GridGeometry(
        grid::AbstractGrid;                                     # which grid to calculate the geometry for
        NF::Type{<:AbstractFloat} = DEFAULT_NF,                 # number format for the coordinates
    )
    (; architecture, nlat_half) = grid
    nlat = get_nlat(grid)                       # total number of latitude rings
    npoints = get_npoints(grid)                 # total number of grid points

    # LATITUDES
    latd = get_latd(grid)                       # latitudes in degrees 90˚N ... -90˚N
    latd_poles = cat(90, latd, -90, dims = 1)     # latd, but poles incl

    # Hack: use -90.00...1˚N instead of exactly -90˚N for the <=, > comparison
    # in find_rings! that way the last ring to the south pole can be an open
    # interval [a, b) with a the latitude of the last ring and b=90˚N as for
    # all other intervals between rings
    latd_poles[end] = latd_poles[end] - eps(latd_poles[end])

    # COORDINATES for every grid point in ring order
    londs, _ = get_londlatds(grid)              # in degrees [0˚...360˚E]

    # RINGS and LONGITUDE OFFSETS
    nlons = get_nlons(grid)                                 # number of longitude per ring, pole to pole
    lon_offsets = [londs[ring[1]] for ring in eachring(grid)]   # offset of the first point from 0˚E

    # first flat index ij of every ring, precomputed here so that the interpolation kernels
    # can convert an in-ring index i to a flat index ij without indexing into rings (which
    # would be dynamic indexing on GPU)
    ring_starts = [first(ring) for ring in eachring(grid)]

    # vector type
    VectorType = array_type(architecture, NF, 1)
    VectorIntType = array_type(architecture, Int, 1)
    device_rings = on_architecture(architecture, grid.rings)

    return GridGeometry{typeof(grid), VectorType, VectorIntType, typeof(device_rings), typeof(nlat_half)}(
        grid, nlat_half, nlat, npoints, londs, latd_poles, nlons, ring_starts, lon_offsets, device_rings
    )
end

Base.show(io::IO, G::GridGeometry) = print(io, "GridGeometry for $(G.grid)")

"""Supertype of every Locator, which locates the indices on a grid to be used to perform an
interpolation. E.g. AnvilLocator uses a 4-point stencil for every new coordinate to interpolate
onto. Higher order stencils can be implemented by defining OtherLocator <: AbstractLocactor."""
abstract type AbstractLocator end

"""Contains arrays that locates grid points of a given field to be uses in an interpolation
and their weights. This Locator is a 4-point average in an anvil-shaped grid-point arrangement
between two latitude rings."""
@kwdef struct AnvilLocator{
        VectorType,
        VectorIntType,
        IntType,
    } <: AbstractLocator

    npoints_output::IntType            # number of points to interpolate onto (length of following vectors)
    nlayers::IntType = 1               # number of vertical layers; 1 for 2D (default), nlayers for 3D

    # to the coordinates respective indices
    js::VectorIntType = zeros(Int, npoints_output)   # ring indices j such that [j, j+1) contains the point
    ij_as::VectorIntType = zeros(Int, npoints_output)   # pixel index ij for top left point a on ring j
    ij_bs::VectorIntType = zeros(Int, npoints_output)   # pixel index ij for top right point b on ring j
    ij_cs::VectorIntType = zeros(Int, npoints_output)   # pixel index ij for bottom left point c on ring j+1
    ij_ds::VectorIntType = zeros(Int, npoints_output)   # pixel index ij for bottom right point d on ring j+1

    # distances to adjacent grid points (i.e. the averaging weights), allocated on the CPU and
    # converted to VectorType as not all array types (e.g. Reactant's) have an undef constructor
    Δys::VectorType = zeros(eltype(VectorType), npoints_output)     # distance fractions between rings
    Δabs::VectorType = zeros(eltype(VectorType), npoints_output)    # distance fractions between a, b
    Δcds::VectorType = zeros(eltype(VectorType), npoints_output)    # distance fractions between c, d

    # pole ring averages per vertical layer for 3D interpolation
    north_pole_average::VectorType = zeros(eltype(VectorType), nlayers)
    south_pole_average::VectorType = zeros(eltype(VectorType), nlayers)
end

Adapt.@adapt_structure AnvilLocator

function Architectures.on_architecture(arch::AbstractArchitecture, loc::AnvilLocator)
    return AnvilLocator(
        npoints_output = loc.npoints_output,
        nlayers = loc.nlayers,
        js = on_architecture(arch, loc.js),
        ij_as = on_architecture(arch, loc.ij_as),
        ij_bs = on_architecture(arch, loc.ij_bs),
        ij_cs = on_architecture(arch, loc.ij_cs),
        ij_ds = on_architecture(arch, loc.ij_ds),
        Δys = on_architecture(arch, loc.Δys),
        Δabs = on_architecture(arch, loc.Δabs),
        Δcds = on_architecture(arch, loc.Δcds),
        north_pole_average = on_architecture(arch, loc.north_pole_average),
        south_pole_average = on_architecture(arch, loc.south_pole_average),
    )
end

"""
$(TYPEDSIGNATURES)
Zero generator function for the 4-point average AnvilLocator. Use `update_locator!` to
update the grid indices used for interpolation and their weights. The number format
NF is the format used for the calculations within the interpolation, the input data
and/or output data formats may differ. `nlayers = 1` (default) for 2D interpolation;
set to the number of vertical layers for 3D vertically-blended interpolation."""
function (::Type{L})(
        NF::Type{<:AbstractFloat},                                 # number format
        npoints::Integer,
        nlayers::Integer = 1;
        architecture::AbstractArchitecture = DEFAULT_ARCHITECTURE(), # architecture to use
    ) where {L <: AbstractLocator}

    VectorType = array_type(architecture, NF, 1)
    VectorIntType = array_type(architecture, Int, 1)

    return L{VectorType, VectorIntType, typeof(npoints)}(; npoints_output = npoints, nlayers)
end

# use Float32 as default for weights
(::Type{L})(npoints::Integer; kwargs...) where {L <: AbstractLocator} = L(DEFAULT_NF, npoints; kwargs...)

function Base.show(io::IO, L::AbstractLocator)
    type_str = split("$(typeof(L))", "{", limit = 2)
    type_itself = type_str[1]
    type_params = length(type_str) == 2 ? ("{" * type_str[2]) : ""
    type_params_short = length(type_params) > 30 ? first(type_params, 30) * "...}" : type_params
    println(io, styled"{warning:$type_itself}{note:$type_params_short}" * " <: $(supertype(typeof(L)))")
    Utils.print_fields(io, L, propertynames(L))
    return nothing
end


"""
    abstract type AbstractInterpolator end

Supertype for Interpolators. Every Interpolator <: AbstractInterpolator is
expected to have two fields,
 - geometry, which describes the grid G to interpolate from
 - locator, which locates the indices on G and their weights to interpolate
    onto a new grid.

NF is the number format used to calculate the interpolation, which can be
different from the input data and/or the interpolated data on the new grid."""
abstract type AbstractInterpolator end

"""
$(TYPEDSIGNATURES)
Interpolator type for [`anvil_average`](@ref).

NF is the number format used to calculate the interpolation, which can be
different from the input data and/or the interpolated data on the new grid.
"""
struct AnvilInterpolator{NF, Geometry, Locator} <: AbstractInterpolator
    geometry::Geometry
    locator::Locator
end

function Adapt.adapt_structure(to, I::AnvilInterpolator{NF}) where {NF}
    geometry = adapt_structure(to, I.geometry)
    locator = adapt_structure(to, I.locator)
    return AnvilInterpolator{eltype(NF), typeof(geometry), typeof(locator)}(geometry, locator)
end

const DEFAULT_INTERPOLATOR = AnvilInterpolator
Base.eltype(::AnvilInterpolator{NF}) where {NF} = NF
grid_type(I::AnvilInterpolator) = typeof(I.geometry.grid)

function Base.show(io::IO, L::AnvilInterpolator{NF}) where {NF}
    NF_str = "{$NF}"
    println(io, styled"{warning:AnvilInterpolator}{note:$NF_str} for $(L.geometry.grid)")
    print(io, styled"└ {info:onto}: $(L.locator.npoints_output) points")
    return nothing
end

# define to a <:AbstractInterpolator the corresponding Locator
Locator(::Type{<:AnvilInterpolator}) = AnvilLocator

# generator with NF default based on geometry and locator
function AnvilInterpolator(
        geometry::AbstractGridGeometry,
        locator::AbstractLocator;
        NF = DEFAULT_NF
    )
    return AnvilInterpolator{NF, typeof(geometry), typeof(locator)}(geometry, locator)
end

# generator from grid and npoints, nlayers sizes the locator's pole-average buffers so that
# (batched) interpolation of fields with up to nlayers layers does not allocate
function AnvilInterpolator(
        grid::AbstractGrid,
        npoints::Integer;       # number of points to interpolate onto
        NF::Type{<:AbstractFloat} = DEFAULT_NF,
        nlayers::Integer = 1,
    )
    geometry = GridGeometry(grid; NF)        # general coordinates and indices for grid
    locator = AnvilLocator(NF, npoints, nlayers; architecture = grid.architecture)  # preallocate work arrays for interpolation

    # assemble geometry and locator to interpolator
    return AnvilInterpolator(geometry, locator; NF)
end

# generator that allocates a grid from Grid and nlat_half, TODO needed?
function (::Type{I})(
        ::Type{Grid},
        nlat_half::Integer,
        npoints::Integer;
        kwargs...
    ) where {I <: AbstractInterpolator, Grid <: AbstractGrid}
    return I(Grid(nlat_half), npoints; kwargs...)
end

# general interpolator function that takes the Interpolator type as kwarg
function interpolator(
        grid::AbstractGrid,
        npoints::Integer;
        Interpolator::Type{<:AbstractInterpolator} = DEFAULT_INTERPOLATOR,
        kwargs...
    )
    # note this leaves the interpolator.locator uninitialized
    return Interpolator(grid, npoints; kwargs...)
end

# generator based on two grids
function interpolator(
        grid_out::AbstractGrid,
        grid_in::AbstractGrid;
        kwargs...
    )
    I = interpolator(grid_in, get_npoints(grid_out); kwargs...)
    NF = eltype(I)
    londs, latds = get_londlatds(grid_out)
    # Convert on host (Float64 → NF) before the device transfer so the kernel sees
    # the same eltype as `lon_offsets`; otherwise `find_grid_indices!` falls into
    # its `convert.(NF, λs)` branch which Reactant cannot trace.
    londs = on_architecture(architecture(grid_out), convert(Vector{NF}, londs))
    latds = on_architecture(architecture(grid_out), convert(Vector{NF}, latds))

    update_locator!(I, londs, latds, unsafe = false)
    return I
end

# generator based on two fields
interpolator(Aout::Field, A::Field; kwargs...) =
    interpolator(Aout.grid, A.grid; kwargs...)

## FUNCTIONS
# interpolate into one point, wrap them into vector
function interpolate(lond::Real, latd::Real, A::Field2D; kwargs...)
    Ai = interpolate([lond], [latd], A; kwargs...)
    return Ai[1]
end

# interpolate while creating an interpolator on the fly
function interpolate(
        londs::AbstractVector{NF},  # longitudes to interpolate into (0˚...360˚E)
        latds::AbstractVector{NF},  # latitudes to interpolate onto (90˚N...-90˚N)
        A::Field2D;         # gridded field to interpolate from
        kwargs...
    ) where {NF}                      # number format used for interpolation
    npoints = length(latds)
    npoints == length(londs) || DimensionMismatch("New interpolation coordinates londs, latds have to be of same length.
                                $n and $(length(londs)) provided.")

    I = interpolator(A.grid, npoints; kwargs...)    # generate Interpolator, containing geometry and work arrays
    update_locator!(I, londs, latds, unsafe = false)  # update location work arrays in I
    return interpolate(A, I)
end

# interpolate using an existing interpolator (needs to be initialized with update_locator!)
function interpolate(
        A::Field2D{NF},     # field to interpolate
        I::AbstractInterpolator;    # indices in I are assumed to be calculated already!
        kwargs...
    ) where {NF}
    (; npoints_output) = I.locator                                      # number of points to interpolate onto
    Aout = similar(A.data, NF, npoints_output)                          # preallocate: onto θs, λs interpolated values of A
    return interpolate_2D!(Aout, A.data, I.locator, I.geometry, architecture(A)) # perform interpolation, store in Aout
end

"""
$(TYPEDSIGNATURES)
Horizontal (2D) interpolation of the gridded values `A` onto the points located in `locator`,
writing into `Aout`. This is the actual interpolation function; the `interpolate!` methods
forward to it. A 3D (vertically blended) interpolation is `interpolate_3D!` instead. The
methods on plain arrays take the raw ring-ordered data, i.e. `field.data`, so that views and
reshapes of a field's data can be passed too. This method interpolates a single layer, the
`AbstractMatrix` method below interpolates all layers of a `(npoints, nlayers)` matrix in a
single (batched) launch. A single layer is passed on to that batched method as a one-column
matrix whenever that reshape is O(1), so that the pole averages are written into the
locator's preallocated buffers on device instead of being allocated and reduced on every call."""
function interpolate_2D!(
        Aout::AbstractVector,               # Out: interpolated values
        A::AbstractVector,                  # gridded values to interpolate from
        locator::AnvilLocator,
        geometry::GridGeometry,
        architecture::AbstractArchitecture
    )
    if is_flattenable(Aout) && is_flattenable(A)
        interpolate_2D!(reshape(Aout, :, 1), reshape(A, :, 1), locator, geometry, architecture)
        return Aout
    end

    # otherwise (e.g. strided views) the single-layer kernel with allocated pole averages
    (; npoints_output, ij_as, ij_bs, ij_cs, ij_ds, Δabs, Δcds, Δys) = locator
    (; npoints) = geometry
    (; rings) = geometry.grid # CPU version even on GPU

    # 1) Aout's length must match the interpolator
    # 2) input A must match the interpolator's geometry points (do not check grids for view support)
    @boundscheck size(Aout, 1) == length(ij_as) || throw(DimensionMismatchArray(Aout, ij_as))
    @boundscheck length(A) == npoints ||
        throw(DimensionMismatch("Interpolator ($npoints points) mismatches input grid ($(length(A)) points)."))

    A_northpole, A_southpole = average_on_poles(A, rings)

    #TODO ij_cs, ij_ds shouldn't be 0...
    @boundscheck extrema_in(ij_as, 0, npoints) || throw(BoundsError)
    @boundscheck extrema_in(ij_bs, 0, npoints) || throw(BoundsError)
    @boundscheck extrema_in(ij_cs, -1, npoints) || throw(BoundsError)
    @boundscheck extrema_in(ij_ds, -1, npoints) || throw(BoundsError)

    launch!(
        architecture,
        LinearWorkOrder,
        (npoints_output,),
        _interpolate_kernel!,
        Aout,
        A,
        ij_as,
        ij_bs,
        ij_cs,
        ij_ds,
        Δabs,
        Δcds,
        Δys,
        A_northpole,
        A_southpole,
    )

    return Aout
end

@kernel inbounds = true function _interpolate_kernel!(
        Aout,               # Out: interpolated values
        A,                  # gridded values to interpolate from
        ij_as,      # indices of A to interpolate from
        ij_bs,      # indices of A to interpolate from
        ij_cs,      # indices of A to interpolate from
        ij_ds,      # indices of A to interpolate from
        Δabs,       # weights of A to interpolate from
        Δcds,       # weights of A to interpolate from
        Δys,        # weights of A to interpolate from
        A_northpole,
        A_southpole,
    )

    k = @index(Global, Linear)

    # pole averages are numbers, or 0-dimensional arrays when traced by Reactant: [] for both,
    # otherwise the branches below differ in type and Reactant can't raise the kernel (raise = true)
    northpole = A_northpole[]
    southpole = A_southpole[]
    a, b = ij_as[k] == 0 ? (northpole, northpole) : (A[ij_as[k]], A[ij_bs[k]])
    c, d = ij_cs[k] == -1 ? (southpole, southpole) : (A[ij_cs[k]], A[ij_ds[k]])

    Aout[k] = anvil_average(a, b, c, d, Δabs[k], Δcds[k], Δys[k])
end

# batched version: all layers in a single launch, sharing the locator's indices and weights
function interpolate_2D!(
        Aout::AbstractMatrix,               # Out: interpolated values, (npoints_output, nlayers)
        A::AbstractMatrix,                  # gridded values to interpolate from, (npoints, nlayers)
        locator::AnvilLocator,
        geometry::GridGeometry,
        architecture::AbstractArchitecture
    )
    (; npoints_output, ij_as, ij_bs, ij_cs, ij_ds, Δabs, Δcds, Δys) = locator
    (; npoints) = geometry

    nlayers = size(A, 2)

    # as in the single-layer method, but the layer dimensions must agree too
    @boundscheck size(Aout, 1) == length(ij_as) || throw(DimensionMismatchArray(Aout, ij_as))
    @boundscheck size(A, 1) == npoints ||
        throw(DimensionMismatch("Interpolator ($npoints points) mismatches input grid ($(size(A, 1)) points)."))
    @boundscheck size(Aout, 2) == nlayers ||
        throw(DimensionMismatch("Output has $(size(Aout, 2)) layers but input has $nlayers."))

    # into the locator's buffers if large enough, otherwise allocating
    A_northpole, A_southpole = average_on_poles!(locator, A, geometry, architecture)

    @boundscheck extrema_in(ij_as, 0, npoints) || throw(BoundsError)
    @boundscheck extrema_in(ij_bs, 0, npoints) || throw(BoundsError)
    @boundscheck extrema_in(ij_cs, -1, npoints) || throw(BoundsError)
    @boundscheck extrema_in(ij_ds, -1, npoints) || throw(BoundsError)

    launch!(
        architecture,
        ArrayWorkOrder,
        (npoints_output, nlayers),
        _interpolate_batched_kernel!,
        Aout,
        A,
        ij_as,
        ij_bs,
        ij_cs,
        ij_ds,
        Δabs,
        Δcds,
        Δys,
        A_northpole,
        A_southpole,
    )

    return Aout
end

@kernel inbounds = true function _interpolate_batched_kernel!(
        Aout,        # Out: interpolated values
        A,           # gridded values to interpolate from
        ij_as,       # indices of A to interpolate from
        ij_bs,       # indices of A to interpolate from
        ij_cs,       # indices of A to interpolate from
        ij_ds,       # indices of A to interpolate from
        Δabs,        # weights of A to interpolate from
        Δcds,        # weights of A to interpolate from
        Δys,         # weights of A to interpolate from
        A_northpole, # per-layer, unlike the single-layer kernel's scalars
        A_southpole,
    )

    k, l = @index(Global, NTuple)

    a, b = ij_as[k] == 0 ? (A_northpole[l], A_northpole[l]) : (A[ij_as[k], l], A[ij_bs[k], l])
    c, d = ij_cs[k] == -1 ? (A_southpole[l], A_southpole[l]) : (A[ij_cs[k], l], A[ij_ds[k], l])

    Aout[k, l] = anvil_average(a, b, c, d, Δabs[k], Δcds[k], Δys[k])
end

# version for 2D fields
interpolate_2D!(
    Aout::Field,
    A::Field2D,
    interpolator::AbstractInterpolator,
) = interpolate_2D!(Aout, A, interpolator.locator, interpolator.geometry)

function interpolate_2D!(
        Aout::Field,
        A::Field2D,
        locator::AbstractLocator,
        geometry::AbstractGridGeometry,
    )
    fields_match(Aout, A) && return copyto!(Aout.data, A.data)
    @assert ismatching(architecture(A), Aout) "Interpolation is only supported between fields on the same architecture, got $(architecture(A)) and $(architecture(Aout))"
    return interpolate_2D!(Aout.data, A.data, locator, geometry, architecture(A))
end

# version for 2D field and vector
interpolate_2D!(
    Aout::AbstractVector,       # Out: points to interpolate onto
    A::Field2D,                 # In: field to interpolate from
    interpolator::AbstractInterpolator,
) = interpolate_2D!(Aout, A, interpolator.locator, interpolator.geometry)

function interpolate_2D!(
        Aout::AbstractVector,       # Out: points to interpolate onto
        A::Field2D,                 # In: field to interpolate from
        locator::AbstractLocator,
        geometry::AbstractGridGeometry,
    )
    return interpolate_2D!(Aout, A.data, locator, geometry, architecture(A))  # use .data to trigger dispatch for method above
end

# version for 3D+ fields: batched 2D interpolation, every layer interpolated horizontally
# onto the same points, no interpolation in the vertical (that is interpolate_3D!)
interpolate_2D!(
    Aout::Field,        # Out: grid to interpolate onto
    A::Field,           # In: gridded data to interpolate from
    interpolator::AbstractInterpolator,
) = interpolate_2D!(Aout, A, interpolator.locator, interpolator.geometry)

function interpolate_2D!(
        Aout::Field,        # Out: grid to interpolate onto
        A::Field,           # In: gridded data to interpolate from
        locator::AbstractLocator,
        geometry::AbstractGridGeometry,
    )
    # if fields match just copy data over (eltypes might differ)
    fields_match(Aout, A) && return copyto!(Aout.data, A.data)
    @assert ismatching(architecture(A), Aout) "Interpolation is only supported between fields on the same architecture, got $(architecture(A)) and $(architecture(Aout))"

    # Interpolate every layer in a single launch by collapsing the trailing dimensions into
    # one. That reshape is O(1) for dense data and contiguous views only, so anything else
    # (e.g. a field wrapping a strided view) keeps the per-layer loop.
    if is_flattenable(Aout.data) && is_flattenable(A.data)
        interpolate_2D!(
            flatten_layers(Aout.data),
            flatten_layers(A.data),
            locator,
            geometry,
            architecture(A),
        )
    else
        for k in eachlayer(Aout, A, vertical_only = true)
            interpolate_2D!(view(Aout.data, :, k), view(A.data, :, k), locator, geometry, architecture(A))
        end
    end
    return Aout                             # return the field wrapped around the interpolated data
end

"""
$(TYPEDSIGNATURES)
True if `reshape(x, size(x, 1), :)` is O(1) and yields an array that the interpolation kernels
can index directly: dense arrays and contiguous views (e.g. `view(A, :, :, k)`). A strided view
would reshape into a slow wrapper type, so the batched interpolation is not used in this case."""
is_flattenable(x::DenseArray) = true
is_flattenable(x::SubArray) = Base.iscontiguous(x)
is_flattenable(x::AbstractArray) = false

"""$(TYPEDSIGNATURES)
Collapse all trailing dimensions of `x` into one, `reshape(x, size(x, 1), :)` but returning
matrices unchanged instead of wrapping them into a reshaped array."""
flatten_layers(x::AbstractMatrix) = x
flatten_layers(x::AbstractArray) = reshape(x, size(x, 1), :)

"""
$(TYPEDSIGNATURES)
Interpolate `A` onto `Aout`, choosing the interpolation by the way vertical locations are
communicated: with a `locator` and `geometry` (or an `interpolator` bundling both) only,
this is a horizontal interpolation via `interpolate_2D!`, batched over all layers of a
3D+ field. Methods that also take vertical positions perform a 3D interpolation via
`interpolate_3D!`."""
interpolate!(Aout::Field, A::Field, interpolator::AbstractInterpolator) =
    interpolate_2D!(Aout, A, interpolator)
interpolate!(Aout::Field, A::Field, locator::AbstractLocator, geometry::AbstractGridGeometry) =
    interpolate_2D!(Aout, A, locator, geometry)
# Field2D is an AbstractVector too, resolve the ambiguity with the vector-output methods
interpolate!(Aout::Field, A::Field2D, interpolator::AbstractInterpolator) =
    interpolate_2D!(Aout, A, interpolator)
interpolate!(Aout::Field, A::Field2D, locator::AbstractLocator, geometry::AbstractGridGeometry) =
    interpolate_2D!(Aout, A, locator, geometry)
interpolate!(Aout::AbstractVector, A::Field2D, interpolator::AbstractInterpolator) =
    interpolate_2D!(Aout, A, interpolator)
interpolate!(Aout::AbstractVector, A::Field2D, locator::AbstractLocator, geometry::AbstractGridGeometry) =
    interpolate_2D!(Aout, A, locator, geometry)

# interpolate while creating an interpolator on the fly
function interpolate!(
        Aout::Field,
        A::Field;
        kwargs...
    )
    # if fields match just copy data over (eltypes might differ)
    fields_match(Aout, A) && return copyto!(Aout.data, A.data)
    I = interpolator(Aout, A; kwargs...)    # create interpolator instance from field A to Aout
    interpolate!(Aout, A, I)                # perform interpolation returns
    return Aout                             # return the field wrapped around the interpolated data
end

"""$(TYPEDSIGNATURES)
Interpolate `field_in` onto `field_out` ignoring NaNs in `field_in` (e.g. ocean in land
climatologies): the interpolation weights are renormalised over the valid neighbours, so coastal
points take their value from the surrounding land. Points without any valid neighbour remain NaN
(0/0). Overwrites the NaNs in `field_in` with zeros."""
function interpolate_ignoring_nan!(field_out::Field, field_in::Field, interpolator::AbstractInterpolator)
    valid = .!isnan.(field_in.data)
    weights_in = similar(field_in)
    weights_in.data .= valid
    field_in.data .= ifelse.(valid, field_in.data, zero(eltype(field_in)))
    weights_out = similar(field_out)
    interpolate!(field_out, field_in, interpolator)
    interpolate!(weights_out, weights_in, interpolator)
    field_out.data ./= weights_out.data
    return field_out
end

# create grid on the fly
interpolate(Grid::Type{<:AbstractGrid}, nlat_half::Integer, A::Field; kwargs...) =
    interpolate(Grid(nlat_half), A; kwargs...)

# create field from grid on the fly
function interpolate(
        grid::AbstractGrid,
        A::Field;
        kwargs...
    )
    I = interpolator(grid, A.grid; kwargs...)
    Aout = Field(grid, size(A)[2:end]...)
    interpolate!(Aout, A, I)    # returns an array
    return Aout                 # returns the field wrapped around that array
end

# if only the grid type is provided, create a grid with nlat_half and architecture from the input field
interpolate(Grid::Type{<:AbstractGrid}, A::Field; kwargs...) = interpolate(Grid(A.grid.nlat_half, architecture(A)), A; kwargs...)

"""
$(TYPEDSIGNATURES)
Locate the interpolation points `(λs, θs)` on the grid described by `I.geometry`, updating
`I.locator` in place with the ring indices and interpolation weights required by
`interpolate!`. This is the precomputation step of the interpolation, separate from the
per-value `interpolate!` call so that the (relatively expensive) locating can be reused
across multiple interpolations onto the same points.
"""
update_locator!(
    I::AbstractInterpolator,    # GridGeometry and Locator
    λs::AbstractVector,         # longitudes to interpolate onto
    θs::AbstractVector;         # latitudes to interpolate onto
    unsafe::Bool = false,         # true to disable safety checks
) = update_locator!(I.locator, I.geometry, λs, θs; unsafe)

function update_locator!(
        locator::AbstractLocator,
        geometry::AbstractGridGeometry,
        λs::AbstractVector,         # longitudes to interpolate onto
        θs::AbstractVector;         # latitudes to interpolate onto
        unsafe::Bool = false,         # true to disable safety checks
    )
    # find latitude ring indices corresponding to interpolation points
    (; latd) = geometry                  # latitudes of rings including north and south pole
    (; js, Δys) = locator                # to be updated: ring indices js, and meridional weights Δys
    find_rings!(js, Δys, θs, latd; unsafe, architecture = geometry.grid.architecture)  # next ring at or north of θ

    # find grid incides ij for top, bottom and left, right grid points around (θ, λ)
    return find_grid_indices!(locator, geometry, λs, geometry.grid.architecture)               # next points left and right of λ on rings north and south
end

update_locator!(I::AbstractInterpolator, A::Field; kwargs...) = update_locator!(I.locator, I.geometry, A::Field; kwargs...)

function update_locator!(
        locator::AbstractLocator,
        geometry::AbstractGridGeometry,
        A::Field; kwargs...
    )
    londs, latds = get_londlatds(A.grid)
    londs = on_architecture(architecture(A), londs)
    latds = on_architecture(architecture(A), latds)

    return update_locator!(locator, geometry, londs, latds; kwargs...)
end

function find_rings!(
        js::AbstractVector,             # Out: ring indices j
        Δys::AbstractVector,            # Out: distance fractions to ring further south
        θs::AbstractVector,             # latitudes to interpolate onto
        latd::AbstractVector;           # latitudes of the rings on the original grid
        unsafe::Bool = false,             # skip safety checks when true
        architecture::AbstractArchitecture = architecture(js)
    )

    if ~unsafe
        θmin, θmax = extrema(θs)
        @boundscheck θmin >= -90 || throw(ArgumentError("Latitudes θs are expected to be within [-90˚, 90˚]; θ=$(θmin)˚ given."))
        @boundscheck θmax <= 90 || throw(ArgumentError("Latitudes θs are expected to be within [-90˚, 90˚]; θ=$(θmax)˚ given."))

        #TODO: currently we only check the latitudes of the grid we interpolate onto
        #TODO: as we only allow instances of Field to be the original grid, the latitudes below
        #TODO: should be okay anyway. Checking it on GPU is a bit more annoying...

        @assert Utils.isdecreasing(latd) "Latitudes latd are expected to be strictly decreasing."
        #@assert latd[1] == 90 "Latitudes latd are expected to contain 90˚N, the north pole."

        # Hack: for intervals between rings to be one-sided open [j, j+1) the last element in
        # latd has to be prevfloat(-90) for the <=, > comparisons
        #ϵ = eps(latd[end])
        #@assert latd[end] == -90-ϵ "Latitudes latd are expected to contain -90˚, the south pole."
    end

    return find_rings_unsafe!(js, Δys, θs, latd, architecture)
end

DimensionMismatchArray(a::AbstractArray, b::AbstractArray) =
    DimensionMismatch("Arrays have different dimensions: $(size(a)) vs $(size(b))")
DimensionMismatchArray(a::AbstractArray, bs::AbstractArray...) =
    DimensionMismatch("Arrays have different dimensions: $(size(a)) vs $(map(size, bs))")

# GPU kernel for finding ring indices
@kernel inbounds = true function find_rings_kernel!(
        js,                # Out: ring indices j
        Δys,               # Out: distance fractions to ring further south
        θs,        # latitudes to interpolate onto
        latd       # latitudes of the rings on the original grid
    )
    k = @index(Global, Linear)

    # Binary search to find the ring index for this latitude
    θ = θs[k]

    # Initialize search bounds
    j_low = 1
    j_high = length(latd) - 1

    # Binary search for the ring that contains this latitude
    j = 1  # Default starting point

    # Binary search is more efficient than linear search as latd are sorted
    # and scales with log(N_lat) instead of N_lat
    while j_low <= j_high
        j_mid = (j_low + j_high) ÷ 2

        if θ <= latd[j_mid] && (j_mid == length(latd) - 1 || θ > latd[j_mid + 1])
            # Found the correct ring
            j = j_mid
            break
        elseif θ > latd[j_mid]
            j_high = j_mid - 1
        else
            j_low = j_mid + 1
        end
    end

    # Store results
    js[k] = j - 1  # Convert to 1-based indexed rings
    Δys[k] = (latd[j] - θ) / (latd[j] - latd[j + 1])
end

function find_rings_unsafe!(
        js::AbstractArray,             # Out: vector of ring indices
        Δys::AbstractArray,            # distance fractions to ring further south
        θs::AbstractArray,             # latitudes of points to interpolate onto
        latd::AbstractArray,           # latitudes of rings (90˚ to -90˚, strictly decreasing)
        architecture::AbstractArchitecture
    )

    @boundscheck length(js) == length(θs) || throw(DimensionMismatchArray(js, θs))
    @boundscheck length(js) == length(Δys) || throw(DimensionMismatchArray(js, Δys))

    launch!(
        architecture,
        LinearWorkOrder,
        size(js),
        find_rings_kernel!,
        js,
        Δys,
        θs,
        latd
    )
    return nothing
end

# for testing only
function find_rings(θs::AbstractVector, latd::AbstractVector{NF}) where {NF}
    js = Vector{Int}(undef, length(θs))
    Δys = Vector{NF}(undef, length(θs))
    find_rings!(js, Δys, θs, latd)
    return js, Δys
end

@kernel inbounds = true function find_grid_indices_kernel!(
        js,            # ring indices j
        ij_as, ij_bs,          # northern point indices
        ij_cs, ij_ds,          # southern point indices
        Δabs, Δcds,            # distance fractions
        λs,            # longitudes to interpolate onto
        lon_offsets,   # longitude offsets for each ring
        nlons,         # number of longitude points per ring
        ring_starts,   # starting flat index for each ring
        nlat,          # number of latitude rings
    )
    k = @index(Global, Linear)

    j = js[k]
    λ = λs[k]

    # NORTHERN POINTS a, b
    if j == 0               # a, b are at the north pole
        ij_as[k] = 0        # use 0 as north pole flag
        ij_bs[k] = 0
    else
        # get in-ring index i for a, the next grid point to the left
        # and b the next grid point to the right, such that
        # λ ∈ [a, b); while in most cases i_a + 1 = i_b, across 0˚E this is not the case
        i_a, i_b, Δ = find_lon_indices(λ, lon_offsets[j], nlons[j])
        ij_as[k] = ring_starts[j] + i_a - 1    # convert to flat index
        ij_bs[k] = ring_starts[j] + i_b - 1    # convert to flat index
        Δabs[k] = Δ                 # distance fraction of λ between a, b
    end

    # SOUTHERN POINTS c, d
    if j == nlat                    # c, d are at the south pole
        ij_cs[k] = -1               # use -1 as south pole flag
        ij_ds[k] = -1
    else
        # as above but for one ring further down
        i_c, i_d, Δ = find_lon_indices(λ, lon_offsets[j + 1], nlons[j + 1])
        ij_cs[k] = ring_starts[j + 1] + i_c - 1  # convert to flat index
        ij_ds[k] = ring_starts[j + 1] + i_d - 1  # convert to flat index
        Δcds[k] = Δ                 # distance fraction of λ between c, d
    end
end

find_grid_indices!(
    I::AnvilInterpolator,        # update indices arrays
    λs::AbstractArray,           # based on new longitudes λ
    architecture::AbstractArchitecture = architecture(λs)
) = find_grid_indices!(I.locator, I.geometry, λs, architecture)

function find_grid_indices!(
        locator::AbstractLocator,   # update indices arrays
        geometry::AbstractGridGeometry,
        λs::AbstractArray,           # based on new longitudes λ
        architecture::AbstractArchitecture = architecture(λs)
    )

    (; js, ij_as, ij_bs, ij_cs, ij_ds) = locator
    (; Δabs, Δcds) = locator
    (; nlons, ring_starts, lon_offsets, nlat) = geometry

    # Skip the broadcast convert when eltypes already match: `convert.(T, λs)` is
    # incompatible with Reactant tracing, so we only run it when truly needed.
    T = eltype(lon_offsets)
    λs_converted = eltype(λs) == T ? λs : convert.(T, λs)

    launch!(
        architecture,
        LinearWorkOrder,
        size(js),
        find_grid_indices_kernel!,
        js,
        ij_as, ij_bs,
        ij_cs, ij_ds,
        Δabs, Δcds,
        λs_converted,
        lon_offsets,
        nlons,
        ring_starts,
        nlat
    )
    return nothing
end

@inline function find_lon_indices(
        λ::NF,     # longitude to find incides for (0˚...360˚E)
        λ₀::NF,     # offset of the first longitude point on ring
        nlon::Int   # number of longitude points on ring
    ) where {NF <: AbstractFloat}

    Δλ = convert(NF, 360) / nlon          # longitude spacing
    ix = (λ - λ₀) / Δλ                      # grid index i but with fractional part
    # unsafe_trunc(Int, floor(ix)) instead of floor(Int, ix): the latter carries an
    # InexactError branch which boxes ix, requiring GPU-side allocation. AMDGPU rejects
    # that at compile time. λ, λ₀ are bounded degrees so the conversion cannot overflow.
    i = Base.unsafe_trunc(Int, floor(ix))   # 0-based grid index to the left
    Δ = ix - i                            # distance fraction from i to i+1

    # λ ∈ [λa, λb), i.e. a is the next grid point to the left, b to the right
    i_a = mod(i, nlon) + 1              # convert to 1-based index
    i_b = mod(i + 1, nlon) + 1            # use mod for periodicity
    return i_a, i_b, Δ
end

"""
$(TYPEDSIGNATURES)
Computes the average at the North and South pole from a given grid `A` and it's precomputed
ring indices `rings`. The North pole average is an equally weighted average of all grid points
on the northern-most ring. Similar for the South pole."""
@inline function average_on_poles(A::AbstractVector, rings)
    # TODO: doing the computation below causes allocations, doing it with views causes scalarindexing on GPU
    A_northpole = mean(A[rings[1]])     # average of all grid points around the north pole
    A_southpole = mean(A[rings[end]])   # same for south pole
    return A_northpole, A_southpole
end

"""
$(TYPEDSIGNATURES)
Method for `A::Abstract{T<:Integer}` which rounds the averaged values
to return the same number format `NF`."""
@inline function average_on_poles(A::AbstractVector{NF}, rings) where {NF <: Integer}
    # TODO: doing the computation below causes allocations, doing it with views causes scalarindexing on GPU
    A_northpole = mean(A[rings[1]])    # average of all grid points around the north pole
    A_southpole = mean(A[rings[end]])  # same for south pole
    return round(NF, A_northpole), round(NF, A_southpole)
end

"""
$(TYPEDSIGNATURES)
Method for a layered `A`, returning `1 × nlayers` matrices of pole averages, one per layer and
indexed linearly by the batched interpolation kernel (no `vec` as Reactant's lazily reshaped
arrays can't be passed to kernels). Indexing rather than viewing matches the single-layer methods
above: it allocates, but a view would trigger scalar indexing on GPU."""
@inline function average_on_poles(A::AbstractMatrix, rings)
    A_northpole = mean(A[rings[1], :], dims = 1)    # per layer, around the north pole
    A_southpole = mean(A[rings[end], :], dims = 1)  # same for south pole
    return A_northpole, A_southpole
end

"""
$(TYPEDSIGNATURES)
Method for a layered `A::AbstractMatrix{T<:Integer}` which rounds the averaged values
to return the same number format `NF`."""
@inline function average_on_poles(A::AbstractMatrix{NF}, rings) where {NF <: Integer}
    A_northpole = mean(A[rings[1], :], dims = 1)
    A_southpole = mean(A[rings[end], :], dims = 1)
    return round.(NF, A_northpole), round.(NF, A_southpole)
end

"""
$(TYPEDSIGNATURES)
Pole averages per layer of `A` written into the `north_pole_average`, `south_pole_average`
buffers of `locator` without allocating, returning these buffers. Falls back to the
allocating `average_on_poles` if the buffers have fewer entries than `A` has layers (e.g.
a locator created with the default `nlayers = 1`), for integer data, which is rounded, or if
the buffers' number format is less precise than `A`'s (e.g. Float64 data with a Float32
interpolator), so that the pole averages keep the precision of the data."""
function average_on_poles!(
        locator::AnvilLocator,
        A::AbstractMatrix,
        geometry::GridGeometry,
        architecture::AbstractArchitecture,
    )
    (; north_pole_average, south_pole_average) = locator
    nlayers = size(A, 2)
    T = eltype(north_pole_average)
    if eltype(A) <: AbstractFloat && promote_type(eltype(A), T) == T && length(north_pole_average) >= nlayers
        launch!(
            architecture, LinearWorkOrder, (nlayers,), _compute_pole_averages_kernel!,
            north_pole_average, south_pole_average, A, geometry
        )
        return north_pole_average, south_pole_average
    else
        return average_on_poles(A, geometry.grid.rings)
    end
end

# Compute north and south pole ring averages per vertical layer on device, accumulated in the
# number format of the averages (which can differ from the data's, e.g. Float32 output)
@kernel inbounds = true function _compute_pole_averages_kernel!(
        north_pole_average, south_pole_average, A_data, geometry
    )
    (; ring_starts, nlons, nlat) = geometry
    k = @index(Global, Linear)
    T = eltype(north_pole_average)
    n_north = nlons[1]
    rs_north = ring_starts[1]
    north_sum = zero(T)
    for i in 0:(n_north - 1)
        north_sum += convert(T, A_data[rs_north + i, k])
    end
    north_pole_average[k] = north_sum / n_north
    n_south = nlons[nlat]
    rs_south = ring_starts[nlat]
    south_sum = zero(T)
    for i in 0:(n_south - 1)
        south_sum += convert(T, A_data[rs_south + i, k])
    end
    south_pole_average[k] = south_sum / n_south
end

"""
$(TYPEDSIGNATURES)
The bilinear average of a, b, c, d which are values at grid points
in an anvil-shaped configuration at location x, which is denoted
by Δab, Δcd, Δy, the fraction of distances between a-b, c-d, and ab-cd,
respectively. Note that a, c and b, d do not necessarily share the same
longitude/x-coordinate. See schematic:
```
            0..............1    # fraction of distance Δab between a, b
            |<  Δab   >|

    0^      a -------- o - b    # anvil-shaped average of a, b, c, d at location x
    .Δy                |
    .                  |
    .v                 x
    .                  |
    1         c ------ o ---- d

              |<  Δcd >|
              0...............1 # fraction of distance Δcd between c, d
```
^ fraction of distance Δy between a-b and c-d."""
@inline function anvil_average(
        a,      # top left value
        b,      # top right value
        c,      # bottom left value
        d,      # bottom right value
        Δab,    # fraction of distance between a, b ∈ [0, 1)
        Δcd,    # fraction of distance between c, d ∈ [0, 1)
        Δy,     # fraction of distance between ab, cd ∈ [0, 1)
    )

    # the type of the weights is ::Real, but the following is written such that
    # always NF (the type of the data values a, b, c, d) is returned
    ab_average = a + (b - a) * Δab      # a for Δab=0, b for Δab=1
    cd_average = c + (d - c) * Δcd      # c for Δab=0, b for Δab=1
    abcd_average = ab_average + (cd_average - ab_average) * Δy
    return abcd_average
end

"""
$TYPEDSIGNATURES
Averages all grid points in `input` that are within one grid cell of
`output` with coslat-weighting. The output grid cell boundaries
are assumed to be rectangles spanning half way to adjacent longitude
and latitude points."""
function grid_cell_average!(
        output::Field,
        input::AbstractFullField
    )

    # for i, j indexing
    input_matrix = reshape(input.data, :, get_nlat(input))

    # input grid coordinates, all in radians 0:π for colat, 0:2π for lon
    colat_in = get_colat(input)
    coslat = sin.(colat_in)    # cos(lat) = sin(colat)
    lon_in = get_lon(input)
    nlon_in = length(lon_in)

    # output grid coordinates, append -π, 2π to have grid points
    # towards the poles definitely included
    colat_out = vcat(-π, get_colat(output), 2π)
    lons_out, _ = get_lonlats(output)

    rings = eachring(output)

    for (j, ring) in enumerate(rings)
        Δϕ = 2π / length(ring)        # longitude spacing on this ring

        # indices for lat_out are shifted as north and south pole are included
        θ0 = (colat_out[j] + colat_out[j + 1]) / 2      # northern edge
        θ1 = (colat_out[j + 1] + colat_out[j + 2]) / 2  # southern edge

        # matrix indices for input grid that lie in output grid cell
        j0 = findfirst(θ -> θ >= θ0, colat_in)
        j1 = findlast(θ -> θ < θ1, colat_in)

        for ij in ring
            ϕ0 = mod(lons_out[ij] - Δϕ / 2, 2π)         # western edge
            ϕ1 = ϕ0 + Δϕ                                # eastern edge
            # the last line does not require a mod and in fact throws
            # an error if, as long as the offset from prime meridian
            # is at most Δϕ/2 (true for HEALPixGrids, offset 0 for
            # Gaussian and Clenshaw grids)

            # matrix indices for input grid that lie in output grid cell
            a = findlast(ϕ -> ϕ < ϕ0, lon_in)           # western edge
            b = findfirst(ϕ -> ϕ >= ϕ1, lon_in)         # eastern edge

            # map around prime meridian if coordinates outside of range
            a = isnothing(a) ? nlon_in : a
            b = isnothing(b) ? 1 : b

            # in most cases we will have 1 <= a < b <=n, then loop i in a:b (b:a isn't looping)
            # however at the edges we have a < 1 or n < b the mod turns this into
            # 1 <= b < a <= n, for which we want to loop 1:b AND a:n
            ab, ba = b < a ? (1:b, a:nlon_in) : (a:b, b:a)

            sum_of_weights = 0
            for j′ in j0:j1

                for i in ab
                    w = coslat[j′]
                    sum_of_weights += w
                    output[ij] += w * input_matrix[i, j′]
                end

                for i in ba
                    w = coslat[j′]
                    sum_of_weights += w
                    output[ij] += w * input_matrix[i, j′]
                end
            end
            output[ij] /= sum_of_weights
        end
    end

    return output
end


"""
$TYPEDSIGNATURES
Averages all grid points in `input` that are within one grid cell of
`output` with coslat-weighting. The output grid cell boundaries
are assumed to be rectangles spanning half way to adjacent longitude
and latitude points."""
function grid_cell_average(Grid::Type{<:AbstractGrid}, nlat_half::Integer, input::AbstractFullGrid)
    grid = Grid(nlat_half)
    output = Field(grid)
    grid_cell_average!(output, input)
    return output
end
