module RingGrids

# DOCUMENTATION
using StyledStrings
using DocStringExtensions
import Printf

# NUMERICS
import Statistics: Statistics, mean
import FastGaussQuadrature
import LinearAlgebra
import Random

# ASSET DOWNLOADING
import Downloads
import Artifacts
import Pkg

# GPU
import Adapt: Adapt, adapt, adapt_structure
import GPUArrays
import KernelAbstractions: KernelAbstractions, @kernel, @index, synchronize

# SPEEDYWEATHER SUBMODULES
import SpeedyWeatherInternals.Architectures: Architectures, AbstractArchitecture, CPU, GPU,
    on_architecture, architecture, array_type, ismatching, nonparametric_type
export CPU, GPU, on_architecture, architecture                # export device functions
export SpeedyWeatherInternals, Architectures, KernelLaunching

using SpeedyWeatherInternals.Architectures
using SpeedyWeatherInternals.KernelLaunching
import SpeedyWeatherInternals: Utils

import SpeedyWeatherInternals.ArrayDimensions: ArrayDimensions, AbstractArrayDimensions,
    hastime, hasvertical, Dimensions2D, Dimensions3D, Dimensions4D,
    DimensionsWithTime, DimensionsWithVertical, DimensionsWithTimeAndVertical
export ArrayDimensions

# ABSTRACT GRIDS
export AbstractGrid,
    AbstractFullGrid,
    AbstractReducedGrid

# CONCRETE GRIDS
export FullGaussianGrid,
    FullClenshawGrid,
    FullHEALPixGrid,
    FullOctaHEALPixGrid

export OctahedralGaussianGrid,
    OctahedralClenshawGrid,
    HEALPixGrid,
    OctaHEALPixGrid,
    OctaminimalGaussianGrid

# FIELDS (Data on grids)
export AbstractField, AbstractField2D, AbstractField3D, AbstractField4D,
    AbstractFieldWithTime, AbstractFieldWithVertical, AbstractFieldWithTimeAndVertical,
    Field, Field2D, Field3D

export FullGaussianField,
    FullClenshawField,
    FullHEALPixField,
    FullOctaHEALPixField,
    OctahedralGaussianField,
    OctahedralClenshawField,
    HEALPixField,
    OctaHEALPixField,
    OctaminimalGaussianField

export ColumnField,
    FullColumnField,
    ReducedColumnField,
    ColumnField2D,
    ColumnField3D,
    ColumnField4D,
    transpose!

export field_view

# SIZE
export grids_match,
    fields_match,
    get_nlat,
    get_nlat_half,
    get_npoints,
    get_npoints2D

# COORDINATES
export get_londlatds,
    get_lonlats,
    get_loncolats,
    get_lat,
    get_colat,
    get_latd,
    get_lond,
    get_nlons,
    get_nlon_max

# INTEGRATION
export get_quadrature_weights,
    get_solid_angles

# ITERATORS
export eachlayer,
    eachring,
    whichring,
    eachgridpoint,
    each_index_in_ring,
    each_index_in_ring!

# SCALING
export scale_coslat!,
    scale_coslat²!,
    scale_coslat⁻¹!,
    scale_coslat⁻²!,
    scale_coslat,
    scale_coslat²,
    scale_coslat⁻¹,
    scale_coslat⁻²

# INTERPOLATION
export AbstractInterpolator,
    GridGeometry,
    AbstractLocator,
    AnvilLocator,
    AnvilInterpolator,
    DEFAULT_INTERPOLATOR

export interpolate,
    interpolate!,
    interpolate_3D!,
    interpolate_2D!,
    update_locator,
    update_locator!

export SigmaCenter,
    SigmaFaceAbove,
    SigmaFaceBelow

# STATISTICS
export zonal_mean

export unmasked_indices, copy_unmasked!

# CONSTANTS
const DEFAULT_NF = Float32
const DEFAULT_ARRAYTYPE = Array
const DEFAULT_ARCHITECTURE = CPU

# to be defined in GeoMakie extension
export globe, globe!
function globe end
function globe! end

include("utility_functions.jl")

# GENERAL
include("abstract_types.jl")
include("field.jl")
include("column_field.jl")
include("grid.jl")
include("scaling.jl")
include("geodesics.jl")
include("reverse.jl")
include("rotate.jl")
include("reordering.jl")

# FULL GRIDS
include("grids/full_grids.jl")
include("grids/full_gaussian.jl")
include("grids/full_clenshaw.jl")
include("grids/full_healpix.jl")
include("grids/full_octahealpix.jl")

# REDUCED GRIDS
include("grids/reduced_grids.jl")
include("grids/octahedral_gaussian.jl")
include("grids/octahedral_clenshaw.jl")
include("grids/healpix.jl")
include("grids/octahealpix.jl")
include("grids/octaminimal_gaussian.jl")

# INTEGRATION AND INTERPOLATION
include("quadrature_weights.jl")
include("interpolation.jl")
include("interpolation_3d.jl")
include("vertices.jl")
include("statistics.jl")
include("copy_unmasked.jl")

# ASSET DOWNLOADING
export get_asset, load_asset, ASSETS_URL, DEFAULT_ASSETS_VERSION

# load_asset: extension dispatch point implemented by RingGridsNCDatasetsExt (and future format extensions)
function load_asset end

include("get_asset.jl")

end
