"""MatrixSpectralTransform struct that contains all parameters and precomputed matrices
to perform a spectral transform using dense matrices. Fields are
$(TYPEDFIELDS)"""
struct MatrixSpectralTransform{
        NF,
        AR,                         # <: AbstractArchitecture
        SpectrumType,               # <: AbstractSpectrum
        GridType,                   # <: AbstractGrid
        VectorType,                 # <: ArrayType{NF, 1},
        MatrixType,                 # <: ArrayType{NF, 2},
        GradientType,               # <: Gradients struct (see gradient_arrays.jl)
    } <: AbstractSpectralTransform{NF, AR}

    # Architecture
    architecture::AR

    # SPECTRAL AND GRID RESOLUTION
    spectrum::SpectrumType              # spectral truncation
    grid::GridType                      # grid used, including nlat_half for resolution, indices for rings, etc.
    nlayers::Int                        # number of layers in vertical

    # CORRESPONDING GRID VECTORS
    coslat::VectorType                  # Cosine of latitudes, north to south
    coslat⁻¹::VectorType                # inverse of coslat inv.(coslat)

    # NORMALIZATION
    norm_sphere::NF                 # normalization of the l=0, m=0 mode

    # LAPLACE EIGENVALUES -l*(l+1) and their inverse, for ∇²/∇⁻². Stored here (with the existing
    # VectorType parameter) rather than inside `gradients` to keep the type name short.
    eigenvalues::VectorType
    eigenvalues⁻¹::VectorType

    # THE ACTUAL TRANSFORM MATRICES for forward = LT(FFT(input)) and backward = IFFT(ILT(input)).
    # The complex forward matrix F and backward matrix B are stored as real matrices with their real and
    # imaginary parts stacked, so that both directions are a single real matrix-matrix multiply that
    # dispatches to BLAS/CUBLAS/rocBLAS on every architecture. A complex × real `mul!` would not
    # (equal element types are required) and falls back to a generic, 100× slower loop/kernel.
    forward_stacked::MatrixType         # [Re(F); Im(F)], size (2nharmonics, npoints): [Re(c); Im(c)] = forward_stacked*field
    backward_stacked::MatrixType        # [Re(B) -Im(B)], size (npoints, 2nharmonics): field = Re(B*c) = backward_stacked*[Re(c); Im(c)]

    # SCRATCH MEMORY, size (2nharmonics, nlayers), holds [Re(c); Im(c)] for up to nlayers columns, the
    # widest batch a transform call may have (sized to the widest batch any model emits via SpectralGrid)
    scratch_memory::MatrixType

    gradients::GradientType             # precomputed gradient and integration matrices
end

Architectures.nonparametric_type(::Type{<:MatrixSpectralTransform}) = MatrixSpectralTransform

"""
$(TYPEDSIGNATURES)
Generator function for a MatrixSpectralTransform struct. With `NF` the number format,
`Grid` the grid type `<:AbstractGrid` and spectral truncation `lmax, mmax` this function sets up
necessary constants for the spectral transform using dense transformation matrices. Also precomputes
the forward and backward transform matrices, retrieves the colatitudes, and preallocates scratch memory."""
function MatrixSpectralTransform(
        spectrum::AbstractSpectrum,                                                     # Spectral truncation
        grid::AbstractGrid;                                                             # grid used and resolution, e.g. FullGaussianGrid
        NF::Type{<:Real} = DEFAULT_NF,                                                  # Number format NF
        nlayers::Integer = DEFAULT_NLAYERS,                                             # number of layers in the vertical (for scratch memory size)
        LegendreShortcut::Type{<:AbstractLegendreShortcut} = LegendreShortcutLinear,    # shorten Legendre loop over order m
        transform_batch = nothing,                                                      # accepted+ignored: MatrixSpectralTransform has no FFT plans to multiplex
    )
    (; architecture) = spectrum                       # 1-based spectral truncation order and degree

    ArrayType = array_type(architecture)
    ArrayType_ = nonparametric_type(ArrayType)      # drop parameters of ArrayType

    # LATITUDE VECTORS (based on Gaussian, equi-angle or HEALPix latitudes)
    latd = RingGrids.get_latd(grid)                                     # latitude in degrees (90˚Nto -90˚N)
    coslat = on_architecture(architecture, NF.(cosd.(latd)))            # cos(lat)
    coslat⁻¹ = on_architecture(architecture, NF.(inv.(cosd.(latd))))   # 1/cos(lat)

    # Create another SpectralTransform to calculate the transform matrices from (do this on the CPU)
    spectrum_cpu = on_architecture(CPU(), spectrum)
    grid_cpu = on_architecture(CPU(), grid)
    S = SpectralTransform(spectrum_cpu, grid_cpu; NF, nlayers, LegendreShortcut)

    npoints = get_npoints(grid)
    nharmonics = LowerTriangularArrays.nonzeros(spectrum)
    forward = zeros(Complex{NF}, nharmonics, npoints)
    backward = zeros(Complex{NF}, npoints, nharmonics)

    field2D = zeros(NF, grid_cpu)
    coeffs2D = zeros(Complex{NF}, spectrum_cpu)

    progress_fwd = ProgressMeter.Progress(length(field2D); dt = 2, desc = "Precalculate forward matrix:")
    forward_matrix!(forward, S, field2D, coeffs2D, progress_fwd)
    progress_bwd = ProgressMeter.Progress(2 * nharmonics; dt = 2, desc = "Precalculate backward matrix:")
    backward_matrix!(backward, S, field2D, coeffs2D, progress_bwd)

    # stack real and imaginary parts into real matrices, see struct definition
    forward_stacked = on_architecture(architecture, vcat(real(forward), imag(forward)))
    backward_stacked = on_architecture(architecture, hcat(real(backward), -imag(backward)))

    # SCRATCH MEMORY for the stacked real and imaginary parts of the coefficients, nlayers columns
    scratch_memory = on_architecture(architecture, zeros(NF, 2 * nharmonics, nlayers))

    # PRECOMPUTE GRADIENT AND INTEGRATION MATRICES + LAPLACE EIGENVALUES (stored on the transform,
    # not inside `gradients`, so the `gradients` type stays short — see `Gradients`)
    gradients = gradient_arrays(NF, spectrum)
    eigenvalues, eigenvalues⁻¹ = get_eigenvalues_and_inverse(NF, spectrum)

    return MatrixSpectralTransform{
        NF,
        typeof(architecture),
        typeof(spectrum),
        typeof(grid),
        typeof(coslat),
        typeof(forward_stacked),
        typeof(gradients),
    }(
        architecture,
        spectrum, grid, nlayers,
        coslat, coslat⁻¹,
        S.norm_sphere,
        eigenvalues, eigenvalues⁻¹,
        forward_stacked,
        backward_stacked,
        scratch_memory,
        gradients,
    )
end

"""$(TYPEDSIGNATURES)
Compute the forward transform matrix `F` from grid to spectral space using the precomputed
spectral transform `S`. The matrix is computed such that multiplying it by flattened grid
data yields spectral coefficients. This function is not yet implemented."""
function forward_matrix!(F, S::AbstractSpectralTransform, field::AbstractField2D, coeffs::LowerTriangularMatrix, progress = nothing)
    for ij in eachindex(field)
        field .= 0                              # unit vector of input
        GPUArrays.@allowscalar field[ij] = 1
        transform!(coeffs, field, S)            # forward transforms of unit vectors
        F[:, ij] .= coeffs.data                 # are the columns of the transformation matrix F
        isnothing(progress) || ProgressMeter.next!(progress)
    end
    return nothing
end

"""$(TYPEDSIGNATURES)
Compute the backward transform matrix `B` from spectral to grid space using the precomputed
spectral transform `S`. The inverse transform maps complex spectral coefficients to real grid
values via `field = Re(B * coeffs)`, so `B` is complex. Each column is determined by probing
with a real unit vector (`coeffs[lm] = 1` gives `Re(B)[:, lm]`) and an imaginary unit vector
(`coeffs[lm] = im` gives `-Im(B)[:, lm]`)."""
function backward_matrix!(B, S::AbstractSpectralTransform, field::AbstractField2D, coeffs::LowerTriangularMatrix, progress = nothing)
    for lm in axes(coeffs.data, 1)
        # real part of column: set coeffs[lm] = 1 (real unit vector)
        coeffs.data .= 0
        GPUArrays.@allowscalar coeffs.data[lm] = 1
        transform!(field, coeffs, S)
        real_response = copy(field.data)

        # imaginary part of column: set coeffs[lm] = im (imaginary unit vector)
        # field = Re(B * c) = Re(B)*Re(c) - Im(B)*Im(c), with c[lm]=im: field = -Im(B)[:, lm]
        coeffs.data .= 0
        GPUArrays.@allowscalar coeffs.data[lm] = im
        transform!(field, coeffs, S)

        B[:, lm] .= real_response .+ im .* (.-field.data)

        isnothing(progress) || ProgressMeter.next!(progress)
    end
    return nothing
end

"""On the CPU nothing needs to be copied: BLAS and broadcasting handle strided views directly,
so a 2-D array (also a 2-D view) is used as is and n-dimensional data is collapsed into columns
with a (zero-copy) `reshape`."""
function _as_matrix(x::AbstractArray, ::AbstractArchitecture)
    ndims(x) == 2 && return x, false
    return reshape(x, size(x, 1), :), false
end

"""On the GPU only arrays that are themselves GPU arrays can go into CUBLAS/rocBLAS. Contiguous
views of GPU arrays are GPU arrays (CUDA.jl/AMDGPU.jl/... do not wrap them in a `SubArray`), so the
fused variables of a model never copy. Everything else (nested or non-contiguous views, which are
not `StridedCuArray`s) is materialized first; the second return value signals that the result has to
be copied back when it is used as output."""
function _as_matrix(x::AbstractArray, ::GPU)
    n = size(x, 1)
    x isa AbstractGPUArray || return reshape(copy(x), n, :), true
    ndims(x) == 2 && return x, false
    return reshape(x, n, :), false
end

# The stacked real/imaginary parts of `ncolumns` columns of coefficients have to fit into the scratch
# memory: `scratch_memory` is (2nharmonics, nlayers) with `nlayers` the largest batch the transform
# was constructed for (`MatrixSpectralTransform(spectral_grid)` sizes it to the widest batch a model
# emits, see `max_transform_batch`).
function _check_scratch(scratch_memory, nharmonics::Integer, ncolumns::Integer)
    size(scratch_memory, 1) == 2nharmonics || throw(DimensionMismatch("scratch memory of size $(size(scratch_memory)) does not match $(2nharmonics) stacked harmonics"))
    ncolumns <= size(scratch_memory, 2) || throw(DimensionMismatch("$ncolumns columns to transform but scratch memory has $(size(scratch_memory, 2)), construct the MatrixSpectralTransform with nlayers >= $ncolumns"))
    return nothing
end

"""$(TYPEDSIGNATURES)
Grid to spectral: multiply the stacked real/imaginary transform matrix `forward_stacked` with the
columns of `field` into the real `scratch`, then combine its two halves into the complex `coeffs`.
Both steps live in one function so that `@maybe_jit` compiles them together on Reactant: outside
of compilation, broadcasting over views of Reactant arrays falls back to scalar indexing."""
function _forward_stacked!(coeffs, scratch, forward_stacked, field)
    LinearAlgebra.mul!(scratch, forward_stacked, field)
    nharmonics = size(coeffs, 1)
    coeffs .= complex.(view(scratch, 1:nharmonics, :), view(scratch, (nharmonics + 1):(2nharmonics), :))
    return coeffs
end

"""$(TYPEDSIGNATURES)
Spectral to grid: stack the real and imaginary parts of `coeffs` into the real `scratch`, then
multiply with the stacked transform matrix `backward_stacked` into the columns of `field`. In one
function for `@maybe_jit`, see [`_forward_stacked!`](@ref)."""
function _backward_stacked!(field, scratch, backward_stacked, coeffs)
    nharmonics = size(coeffs, 1)
    view(scratch, 1:nharmonics, :) .= real.(coeffs)
    view(scratch, (nharmonics + 1):(2nharmonics), :) .= imag.(coeffs)
    LinearAlgebra.mul!(field, backward_stacked, scratch)
    return field
end

"""$(TYPEDSIGNATURES)
Spectral transform (grid to spectral space) from n-dimensional array `field` to an n-dimensional
array `coeffs` of spherical harmonic coefficients. Uses precomputed dense transform matrices to
perform the transformation. The spectral transform is number format-flexible but `field` and the
spectral transform `M` have to have the same number format. The spectral transform is grid-flexible
as long as `field.grid` and `M.grid` match."""
function transform!(                        # GRID TO SPECTRAL
        coeffs::LowerTriangularArray,       # output: spectral coefficients
        field::AbstractField,               # input: gridded values
        scratch_memory,                     # explicit scratch memory, (2nharmonics, ncolumns) real
        M::MatrixSpectralTransform,         # precomputed spectral transform
    )

    # catch incorrect sizes early
    @boundscheck ismatching(M, field, horizontal_only = true) || throw(DimensionMismatch(M, field))
    @boundscheck ismatching(M, coeffs, horizontal_only = true) || throw(DimensionMismatch(M, coeffs))
    # TODO: deactivated temporarily because of Reactant issue
    #@boundscheck size(coeffs, 2) == size(field, 2) || throw(DimensionMismatch(field.data, coeffs.data))

    # Collapse any batch/layer dimensions into columns so the single dense matrix multiply also
    # works for n-dimensional (batched/fused) fields, not just 2D. This is not a batched matmul
    # (one matrix × many columns), so one big `mul!` is both correct and optimal.
    # See `_as_matrix` for why GPU non-contiguous views need materializing first (CPU views don't).
    field_matrix, _ = _as_matrix(field.data, M.architecture)                # read-only source, no writeback needed
    coeffs_matrix, coeffs_materialized = _as_matrix(coeffs.data, M.architecture)
    nharmonics, ncolumns = size(coeffs_matrix)
    @boundscheck _check_scratch(scratch_memory, nharmonics, ncolumns)
    scratch = view(scratch_memory, :, 1:ncolumns)

    # [Re(c); Im(c)] = [Re(F); Im(F)] * field, a single real matrix multiply, then combined into
    # the complex coefficients, jitted together, see `_forward_stacked!`
    @maybe_jit M.architecture _forward_stacked!(coeffs_matrix, scratch, M.forward_stacked, field_matrix)

    coeffs_materialized && copyto!(coeffs.data, coeffs_matrix)
    return coeffs
end

"""$(TYPEDSIGNATURES)
Spectral transform (spectral to grid space) from n-dimensional array `coeffs` of spherical harmonic
coefficients to an n-dimensional array `field`. Uses precomputed dense transform matrices to perform
the transformation. The spectral transform is number format-flexible but `field` and the spectral
transform `M` have to have the same number format. The spectral transform is grid-flexible as long
as `field.grid` and `M.grid` match."""
function transform!(                        # SPECTRAL TO GRID
        field::AbstractField,               # gridded output
        coeffs::LowerTriangularArray,       # spectral coefficients input
        scratch_memory,                     # explicit scratch memory, (2nharmonics, ncolumns) real
        M::MatrixSpectralTransform;         # precomputed transform
        unscale_coslat::Bool = false,       # unscale with cos(lat) on the fly?
    )

    # catch incorrect sizes early
    @boundscheck ismatching(M, field) || throw(DimensionMismatch(M, field))
    @boundscheck ismatching(M, coeffs) || throw(DimensionMismatch(M, coeffs))

    # Collapse any batch/layer dimensions into columns (see the grid→spectral transform above),
    # so the dense matrix multiply also works for n-dimensional (batched/fused) coefficients.
    coeffs_matrix, _ = _as_matrix(coeffs.data, M.architecture)              # read-only source, no writeback needed
    field_matrix, field_materialized = _as_matrix(field.data, M.architecture)
    nharmonics, ncolumns = size(coeffs_matrix)
    @boundscheck _check_scratch(scratch_memory, nharmonics, ncolumns)
    scratch = view(scratch_memory, :, 1:ncolumns)

    # the result is real-valued: field = Re(B*c) = Re(B)*Re(c) - Im(B)*Im(c) is a single real
    # matrix multiply [Re(B) -Im(B)] * [Re(c); Im(c)] with the stacked real/imaginary parts,
    # stacking and multiply jitted together, see `_backward_stacked!`
    @maybe_jit M.architecture _backward_stacked!(field_matrix, scratch, M.backward_stacked, coeffs_matrix)

    field_materialized && copyto!(field.data, field_matrix)

    if unscale_coslat
        @maybe_jit M.architecture RingGrids._scale_lat!(field, M.coslat⁻¹)
    end
    return field
end
