const DEFAULT_NLAYERS = 1
const DEFAULT_GRID = FullGaussianGrid
const DEFAULT_NF = Float32
const DEFAULT_ARRAYTYPE = Array

abstract type AbstractSpectralTransform{NF, AR} end
Architectures.nonparametric_type(S::AbstractSpectralTransform) = nonparametric_type(typeof(S))

"""SpectralTransform struct that contains all parameters and precomputed arrays
to perform a spectral transform. Fields are
$(TYPEDFIELDS)"""
struct SpectralTransform{
        NF,
        AR,                         # <: AbstractArchitecture
        SpectrumType,               # <: AbstractSpectrum
        GridType,                   # <: AbstractGrid
        VectorType,                 # <: ArrayType{NF, 1},
        ArrayTypeIntMatrix,         # <: ArrayType{Int32, 2}
        MatrixComplexType,          # <: ArrayType{Complex{NF}, 2},
        LowerTriangularArrayType,   # <: LowerTriangularArray{NF, 2, ArrayType{NF}, ...},
        ScratchType,                # <: ScratchMemory{ArrayComplexType, VectorComplexType},
        GradientType,               # <: Gradients struct
        RFFTSerialType,             # <: Vector{<:AbstractFFTs.Plan}  (K=1, 1-D forward plans)
        BRFFTSerialType,            # <: Vector{<:AbstractFFTs.Plan}  (K=1, 1-D inverse plans)
        RFFTBatchedType,            # <: Dict{Int, <:Vector{<:AbstractFFTs.Plan}}  (K>1, 2-D forward)
        BRFFTBatchedType,           # <: Dict{Int, <:Vector{<:AbstractFFTs.Plan}}  (K>1, 2-D inverse)
    } <: AbstractSpectralTransform{NF, AR}

    # Architecture
    architecture::AR

    # SPECTRAL RESOLUTION
    spectrum::SpectrumType          # spectral truncation
    nfreq_max::Int                  # Maximum (at Equator) number of Fourier frequencies (real FFT)
    LegendreShortcut::Type{<:AbstractLegendreShortcut} # Legendre shortcut for truncation of m loop
    mmax_truncation::Vector{Int}    # Maximum order m to retain per latitude ring

    # GRID
    grid::GridType                  # grid used, including nlat_half for resolution, indices for rings, etc.
    nlayers::Int                    # max number of layers in the vertical (= max planned batch K; for scratch memory size)

    # CORRESPONDING GRID SIZE
    nlon_max::Int                   # Maximum number of longitude points (at Equator)
    nlons::Vector{Int}              # Number of longitude points per ring
    nlat::Int                       # Number of latitude rings
    rings::Vector{UnitRange{Int}}   # precomputed ring indices

    # CORRESPONDING GRID VECTORS
    coslat::VectorType              # Cosine of latitudes, north to south
    coslat⁻¹::VectorType            # inverse of coslat inv.(coslat)
    lon_offsets::MatrixComplexType  # Offset of first lon per ring from prime meridian

    # NORMALIZATION
    norm_sphere::NF                 # normalization of the l=0, m=0 mode

    # FFT plans, split into concretely-typed serial (K=1, 1-D) and batched (K>1, 2-D) sets so that
    # `plan * view` / `mul!` is a static call (the K=1 and K>1 plans are different concrete FFTW/cuFFT
    # types and cannot share one container). FFTW/cuFFT plans bake K into the plan at construction.
    # The serial plans are the per-layer fallback (used by `_fourier_serial!`), always present. Hot K
    # values (batched dycore transforms, prognostic spec→grid, U/V) are pre-planned in the batched
    # Dicts, keyed by K; everything else falls back to the serial plans in a loop (CPU) or is planned
    # on first use and cached in these Dicts (GPU, see `ensure_batched_plans!`).
    rfft_plan_serial::RFFTSerialType     # grid → spectral (forward), K=1 per-ring 1-D plans
    brfft_plan_serial::BRFFTSerialType   # spectral → grid (inverse), K=1 per-ring 1-D plans
    rfft_plans_batched::RFFTBatchedType  # grid → spectral (forward), K>1 per-ring 2-D plans, keyed by K
    brfft_plans_batched::BRFFTBatchedType # spectral → grid (inverse), K>1 per-ring 2-D plans, keyed by K

    # LEGENDRE POLYNOMIALS, for all latitudes, precomputed (unused on Reactant, which only uses the
    # dense copy below, zero latitudes there)
    legendre_polynomials::LowerTriangularArrayType
    # ... and transposed to (latitude ring, harmonic), flattened so that it needs no type
    # parameter of its own; index it as [(lm - 1) * nlat_half + j].
    # The GPU transforms read the polynomials along opposite axes -- the inverse has
    # neighbouring threads on neighbouring rings, the forward on neighbouring harmonics -- and no
    # single layout is coalesced for both, so the GPU keeps this second copy.
    # Empty on CPU, which only uses the layout above, and on Reactant (unused).
    legendre_polynomials_transposed::VectorType
    # ... and dense, (parity, order, degree, latitude ring) flattened, for the Legendre transform as
    # one batched matrix multiply on Reactant, see `dense_legendre_polynomials`. Empty elsewhere.
    legendre_polynomials_dense::VectorType

    # FOURIER TRANSFORM AS TRUNCATED DFT on Reactant (`fourier_dft = true`), see `dense_fourier_matrices`:
    # forward (2mmax, nlon_max, nlat_half) and inverse (nlon_max, 2mmax, nlat_half) real matrices, flattened.
    # Empty elsewhere and with `fourier_dft = false`.
    fourier_matrix_forward::VectorType
    fourier_matrix_inverse::VectorType

    # SCRATCH MEMORY FOR FOURIER NOT YET LEGENDRE TRANSFORMED AND VICE VERSA
    # state is undetermined, only read after writing to it
    scratch_memory::ScratchType

    # PRECOMPUTED THREAD INDEX MAPS FOR THE GPU LEGENDRE TRANSFORMS
    # The inverse transform runs one thread per (latitude ring, order, layer), the forward one
    # thread per (spherical harmonic coefficient, layer), so the two need different maps.
    jm_index_size::Int                          # number of (j, m) rows in jm_indices
    jm_indices::ArrayTypeIntMatrix              # (j, m, lm_offset, column length) per inverse-transform thread
    lm_indices::ArrayTypeIntMatrix              # (m, hemisphere sign, jm_indices row range) per forward-transform thread

    # SOLID ANGLES ΔΩ FOR QUADRATURE
    # (integration for the Legendre polynomials, extra normalisation of π/nlat included)
    # vector is pole to pole although only northern hemisphere required
    solid_angles::VectorType                    # = ΔΩ = sinθ Δθ Δϕ (solid angle of grid point)

    # LAPLACE EIGENVALUES -l*(l+1) and their inverse, for ∇²/∇⁻².
    eigenvalues::VectorType
    eigenvalues⁻¹::VectorType

    gradients::GradientType                     # precomputed gradient and integration matrices

    # GPU GRAPHS (CUDA graphs and HIP graphs; see SpeedyTransformsCUDAExt.jl /
    # SpeedyTransformsAMDGPUExt.jl) toggle for the GPU-graphs accelerated batched Fourier
    # transform. Set to `false` to fall back to the generic (allocating) per-ring GPU path.
    # Only effective when the CUDA or AMDGPU extension is loaded; ignored on CPU. On AMDGPU
    # this falls back to the generic path, with a one-time warning, if the installed AMDGPU.jl
    # is too old to expose the high-level HIP graph API. Defaults to `default_gpu_graphs`
    # (backend-dependent, see below) rather than a flat `true`/`false`.
    gpu_graphs::Bool

    # Fourier transform as a truncated DFT (batched matrix multiplies) instead of FFTs, only on
    # Reactant, see `default_fourier_dft` and SpeedyTransformsReactantExt.
    fourier_dft::Bool
end

# eltype of a transform is the number format used within
Base.eltype(S::AbstractSpectralTransform{NF}) where {NF} = NF
Architectures.array_type(S::AbstractSpectralTransform{NF, AR}) where {NF, AR} = array_type(AR)
Architectures.nonparametric_type(::Type{<:SpectralTransform}) = SpectralTransform

"""$(TYPEDSIGNATURES)
Default value for the `gpu_graphs` keyword of [`SpectralTransform`](@ref), dispatching on the
device wrapped by `architecture`. The fallback (`true`) covers CUDA and any other backend
without a more specific method; extensions add their own method to opt a backend out of the
default (e.g. `SpeedyTransformsAMDGPUExt.jl` for AMDGPU, since HIP-graphs stability is only
confirmed so far on datacenter/CDNA hardware, not the consumer RDNA cards CI currently runs on).
Explicitly passing `gpu_graphs = true/false` to `SpectralTransform` always overrides this."""
default_gpu_graphs(architecture::AbstractArchitecture) = default_gpu_graphs(device(architecture))
default_gpu_graphs(::KernelAbstractions.CPU) = false   # no graphs on CPU, be explicit
default_gpu_graphs(backend) = true                     # fallback, e.g. CUDA
default_gpu_graphs(::ReactantDevice) = false           # Reactant already does a sort of graph optimisation

"""Largest spectral truncation (1-based `mmax`) for which [`default_fourier_dft`](@ref) chooses the
Fourier transform as a truncated DFT on Reactant. Its matrices take 2 × 307 MB in Float32 at 256, and
grow with the cube of the truncation."""
const DFT_MAX_TRUNCATION = 512

"""$(TYPEDSIGNATURES)
Default value for the `fourier_dft` keyword of [`SpectralTransform`](@ref): the Fourier transform as a
truncated discrete Fourier transform, one batched matrix multiply per direction instead of one FFT per
latitude ring, which XLA keeps in its CUDA graph (it can't capture FFTs). Only on Reactant up to
`DFT_MAX_TRUNCATION`, never on other architectures (not implemented there)."""
default_fourier_dft(architecture::AbstractArchitecture, spectrum::AbstractSpectrum) = false
default_fourier_dft(::ReactantDevice, spectrum::AbstractSpectrum) = spectrum.mmax <= DFT_MAX_TRUNCATION

"""
$(TYPEDSIGNATURES)
Generator function for a SpectralTransform struct. With `NF` the number format,
`Grid` the grid type `<:AbstractGrid` and spectral truncation `lmax, mmax` this function sets up
necessary constants for the spetral transform. Also plans the Fourier transforms, retrieves the colatitudes,
and preallocates the Legendre polynomials and quadrature weights."""
function SpectralTransform(
        spectrum::AbstractSpectrum,                     # Spectral truncation
        grid::AbstractGrid;                             # grid used and resolution, e.g. FullGaussianGrid
        NF::Type{<:Real} = DEFAULT_NF,                                                  # Number format NF
        nlayers::Integer = DEFAULT_NLAYERS,                                             # scratch size — max layer count any single transform call may carry
        transform_batch::AbstractVector{<:Integer} = Int[1, nlayers],                   # list of batch sizes K to pre-plan FFTs for (independent of scratch size)
        LegendreShortcut::Type{<:AbstractLegendreShortcut} = LegendreShortcutLinear,    # shorten Legendre loop over order m
        gpu_graphs::Bool = default_gpu_graphs(spectrum.architecture),               # use GPU-graphs accelerated Fourier path (CUDA, AMDGPU); backend-dependent default
        fourier_dft::Bool = default_fourier_dft(spectrum.architecture, spectrum),   # Fourier transform as truncated DFT (Reactant only)
    )
    fourier_dft && !(spectrum.architecture isa ReactantDevice) &&
        throw(ArgumentError("fourier_dft = true is only implemented for ReactantDevice, not $(spectrum.architecture)."))
    # planned_K controls which Ks get pre-built FFT plans. K=1 is always planned (it is the
    # per-layer fallback used by `_fourier_serial!`).
    planned_K = sort!(unique!(Int[1; transform_batch]))
    @assert maximum(planned_K) <= nlayers "transform_batch $planned_K contains an entry larger than nlayers=$nlayers; scratch would be too small."
    (; lmax, mmax, architecture) = spectrum                       # 1-based spectral truncation order and degree

    ArrayType = array_type(architecture)
    ArrayType_ = nonparametric_type(ArrayType)      # drop parameters of ArrayType

    (; nlat_half) = grid                            # number of latitude rings on one hemisphere incl equator

    # RESOLUTION PARAMETERS
    nlat = get_nlat(grid)           # 2nlat_half but one less if grid has odd # of lat rings
    nlon_max = get_nlon_max(grid)   # number of longitudes around the equator
    # number of longitudes per latitude ring (one hemisphere only)
    nlons = [RingGrids.get_nlon_per_ring(grid, j) for j in 1:nlat_half]
    nfreq_max = nlon_max ÷ 2 + 1              # maximum number of fourier frequencies (real FFTs)
    rings = on_architecture(CPU(), eachring(grid))  # precomputed ring indices

    # LATITUDE VECTORS (based on Gaussian, equi-angle or HEALPix latitudes)
    latd = RingGrids.get_latd(grid)         # latitude in degrees (90˚Nto -90˚N)
    colat = RingGrids.get_colat(grid)       # colatitude in radians
    cos_colat = cos.(colat)                 # cos(colat)
    coslat = cosd.(latd)                    # cos(lat)
    coslat⁻¹ = inv.(coslat)                 # 1/cos(lat)

    # LEGENDRE SHORTCUT OVER ORDER M (0-based), truncate the loop over order m
    mmax_truncation = [LegendreShortcut(nlons[j], latd[j]) for j in 1:nlat_half]
    mmax_truncation = min.(mmax_truncation, mmax - 1)   # only to mmax in any case (otherwise BoundsError)

    # NORMALIZATION
    norm_sphere = 2sqrt(π)  # norm_sphere at l=0, m=0 translates to 1s everywhere in grid space

    # LONGITUDE OFFSETS OF FIRST GRID POINT PER RING (0 for full and octahedral grids)
    lons, _ = RingGrids.get_lonlats(grid)
    rings = adapt(Array, eachring(grid))                    # compute ring indices (on CPU)
    lon1s = [lons[rings[j].start] for j in 1:nlat_half]     # pick lons at first index for each ring
    lon_offsets = [cispi(m * lon1 / π) for m in 0:(mmax - 1), lon1 in lon1s]

    # PRECOMPUTE LEGENDRE POLYNOMIALS
    # On Reactant on the CPU: there they are only used to build the dense copy (below), and filling a
    # Reactant array latitude by latitude is scalar indexing, an error on Reactant's GPU backend
    spectrum_polynomials = architecture isa ReactantDevice ? on_architecture(CPU(), spectrum) : spectrum
    legendre_polynomials = zeros(LowerTriangularArray{NF}, spectrum_polynomials, nlat_half)
    legendre_polynomials_j = zeros(NF, lmax, mmax)          # temporary for one latitude
    for j in 1:nlat_half                                    # only one hemisphere due to symmetry
        Legendre.λlm!(legendre_polynomials_j, lmax - 1, mmax - 1, cos_colat[j])     # precompute l, m 0-based
        legendre_polynomials[:, j] = LowerTriangularArray(legendre_polynomials_j)   # store
    end

    # TRANSPOSED COPY OF THE LEGENDRE POLYNOMIALS FOR THE GPU INVERSE TRANSFORM, see the struct
    # field. Costs as much memory again as the polynomials themselves, so only built on GPU.
    legendre_polynomials_transposed = architecture isa Architectures.GPU ?
        vec(permutedims(legendre_polynomials.data)) :
        on_architecture(architecture, zeros(NF, 0))

    # DENSE COPY OF THE LEGENDRE POLYNOMIALS FOR REACTANT, see the struct field, empty elsewhere
    legendre_polynomials_dense = dense_legendre_polynomials(architecture, legendre_polynomials, mmax_truncation)

    # Reactant only uses the dense copy, so the polynomials are unused there (zero latitudes)
    if architecture isa ReactantDevice
        legendre_polynomials = zeros(LowerTriangularArray{NF}, spectrum, 0)
    end

    # SOLID ANGLES WITH QUADRATURE WEIGHTS (Gaussian, Clenshaw-Curtis, or Riemann depending on grid)
    # solid angles are ΔΩ = sinθ Δθ Δϕ for every grid point with
    # sin(θ)dθ are the quadrature weights approximate the integration over latitudes
    # and sum up to 2 over all latitudes as ∫sin(θ)dθ = 2 over 0...π.
    # Δϕ = 2π/nlon is the azimuth every grid point covers
    solid_angles = get_solid_angles(grid)

    # FOURIER TRANSFORM AS TRUNCATED DFT ON REACTANT, see the struct fields, empty elsewhere
    fourier_matrix_forward, fourier_matrix_inverse =
        dense_fourier_matrices(architecture, NF, fourier_dft, nlons, lon_offsets, solid_angles, mmax)

    # SCRATCH MEMORY FOR FOURIER NOT YET LEGENDRE TRANSFORMED AND VICE VERSA
    # CPU always chunks unplanned K down to the largest planned batch, so scratch only needs
    # to hold one such chunk. GPU shouldn't chunk and must fit the full input K.
    # Reactant transforms without scratch memory (zero layers).
    scratch_memory = ScratchMemory(NF, architecture, grid, _scratch_nlayers(architecture, nlayers, planned_K))

    # PLAN THE FFTs: concretely-typed serial (K=1) plan vectors + batched (K>1) plan Dicts
    rfft_plan_serial, brfft_plan_serial, rfft_plans_batched, brfft_plans_batched = plan_FFTs(
        architecture, planned_K, NF, grid, nlayers, scratch_memory.north, rings, nlons
    )

    # PRECOMPUTE (j, m) INDICES FOR THE GPU LEGENDRE TRANSFORM
    # One row per (latitude ring j, order m) pair a thread works on; the vertical layer k is the
    # kernel's second dimension so the table does not repeat over k. Columns 3 and 4 hold the
    # offset and length of the lower-triangular column at order m, so the kernels index the
    # coefficients directly without recomputing `get_lm_range`.
    # Rows run to the ring's number of Fourier frequencies nfreq_j = nlon_j÷2+1, beyond the
    # Legendre shortcut truncation. Those extra rows carry length 0 and mark the frequencies the
    # inverse transform has to zero out (the FFT reads all of 1:nfreq_j), which saves resetting
    # the whole scratch memory before every transform.
    # The rows are ordered by order m first and latitude ring j second, so that neighbouring
    # threads hold neighbouring rings at the same order and read the transposed Legendre
    # polynomials below with coalesced access. Within an order the rings inside the Legendre
    # truncation come first, so that they form the contiguous row range that the forward
    # transform sums over (recorded in `lm_indices` below), followed by the zero-only rows.
    nfreqs = nlons .÷ 2 .+ 1
    n_orders = max.(nfreqs, mmax_truncation .+ 1)
    n_orders_max = maximum(n_orders)
    jm_index_size = sum(n_orders)
    jm_indices = zeros(Int32, jm_index_size, 4)
    truncated_rows = fill((1, 0), n_orders_max)     # rows inside the truncation, per order m
    i = 0
    for m in 1:n_orders_max
        lm_range = m <= mmax ? LowerTriangularArrays.get_lm_range(m, lmax - 1) : (1:0)  # 0-based lmax
        row_start = i + 1
        for (j, mmax_j) in enumerate(mmax_truncation)   # rings inside the truncation, with a column to sum
            m <= mmax_j + 1 || continue
            i += 1
            jm_indices[i, 1] = j
            jm_indices[i, 2] = m
            jm_indices[i, 3] = first(lm_range) - 1
            jm_indices[i, 4] = length(lm_range)
        end
        truncated_rows[m] = (row_start, i)

        for (j, mmax_j) in enumerate(mmax_truncation)   # then the rings the transform skips,
            mmax_j + 1 < m <= n_orders[j] || continue   # left at length 0 as zero-only rows
            i += 1
            jm_indices[i, 1] = j
            jm_indices[i, 2] = m
        end
    end

    # PRECOMPUTE COEFFICIENT INDICES FOR THE GPU FORWARD LEGENDRE TRANSFORM
    # The forward transform is parallelised over its output coefficients (one thread per
    # coefficient lm and layer), each summing over the latitude rings.
    # Per coefficient we store the order m (to index the Fourier
    # coefficients), the sign with which the southern hemisphere enters (+ for even, - for odd
    # degrees l-m, the north/south symmetry split) and the range of `jm_indices` rows that holds
    # the rings contributing at that order. Those rings are read from the table rather than
    # derived from a first ring down to the equator: the coslat-dependent shortcuts are not
    # monotonic in latitude, so a ring closer to the equator can retain fewer orders than one
    # closer to the pole and the contributing rings do not always reach the equator.
    lm_indices = zeros(Int32, LowerTriangularArrays.nonzeros(spectrum), 4)
    for m in 1:mmax
        # empty range if no ring contributes at that order, then the coefficient stays zero
        row_start, row_end = m <= n_orders_max ? truncated_rows[m] : (1, 0)

        for (l, lm) in enumerate(LowerTriangularArrays.get_lm_range(m, lmax - 1))
            lm_indices[lm, 1] = m
            lm_indices[lm, 2] = isodd(l) ? 1 : -1
            lm_indices[lm, 3] = row_start
            lm_indices[lm, 4] = row_end
        end
    end

    # PRECOMPUTE GRADIENT AND INTEGRATION MATRICES + LAPLACE EIGENVALUES
    gradients = gradient_arrays(NF, spectrum)
    eigenvalues, eigenvalues⁻¹ = get_eigenvalues_and_inverse(NF, spectrum)

    return SpectralTransform{
        NF,
        typeof(architecture),
        typeof(spectrum),
        typeof(grid),
        array_type(architecture, NF, 1),
        array_type(architecture, Int32, 2),
        array_type(architecture, Complex{NF}, 2),
        typeof(legendre_polynomials),
        typeof(scratch_memory),
        typeof(gradients),
        typeof(rfft_plan_serial),
        typeof(brfft_plan_serial),
        typeof(rfft_plans_batched),
        typeof(brfft_plans_batched),
    }(
        architecture,
        spectrum, nfreq_max,
        LegendreShortcut, mmax_truncation,
        grid, nlayers,
        nlon_max, nlons, nlat, rings,
        coslat, coslat⁻¹, lon_offsets,
        norm_sphere,
        rfft_plan_serial, brfft_plan_serial,
        rfft_plans_batched, brfft_plans_batched,
        legendre_polynomials,
        legendre_polynomials_transposed,
        legendre_polynomials_dense,
        fourier_matrix_forward, fourier_matrix_inverse,
        scratch_memory,
        jm_index_size, jm_indices, lm_indices,
        solid_angles,
        eigenvalues, eigenvalues⁻¹,
        gradients,
        gpu_graphs,
        fourier_dft,
    )
end

# make commutative
SpectralTransform(grid::AbstractGrid, spectrum::AbstractSpectrum; kwargs...) =
    SpectralTransform(spectrum, grid; kwargs...)

# calculate spectrum if not provided
function SpectralTransform(
        grid::AbstractGrid;
        truncation::Integer = 0,                    # spectral truncation (1-based)
        dealiasing::Real = SpeedyTransforms.default_dealiasing(grid),      # dealiasing factor
        one_more_degree::Bool = false,              # returns a square LowerTriangularMatrix by default
        kwargs...
    )
    # get truncation from dealiasing if not provided
    truncation = truncation > 0 ? truncation : get_truncation(grid, dealiasing)
    spectrum = Spectrum(truncation + one_more_degree, truncation; architecture = architecture(grid))
    return SpectralTransform(spectrum, grid; kwargs...)
end

# calculate grid if not provided
function SpectralTransform(
        spectrum::AbstractSpectrum;                     # spectral coefficients
        Grid::Type{<:AbstractGrid} = DEFAULT_GRID,      # grid type, e.g. FullGaussianGrid
        nlat_half::Integer = 0,                         # resolution parameter nlat_half
        dealiasing::Real = SpeedyTransforms.default_dealiasing(Grid),          # dealiasing factor
        kwargs...
    )
    # get nlat_half from dealiasing if not provided
    nlat_half = nlat_half > 0 ? nlat_half : get_nlat_half(spectrum.mmax, dealiasing)
    grid = Grid(nlat_half, spectrum.architecture)                  # create grid with nlat_half
    return SpectralTransform(spectrum, grid; kwargs...)
end

# use spectrum, NF, and ArrayType from coeffs
function SpectralTransform(
        coeffs::LowerTriangularArray;                   # spectral coefficients
        kwargs...
    )
    (; spectrum) = coeffs
    NF = real(eltype(coeffs))
    nlayers = size(coeffs, 2)
    return SpectralTransform(spectrum; NF, nlayers, kwargs...)
end

# use grid, NF, and ArrayType from field
function SpectralTransform(
        field::AbstractField;                       # gridded field
        kwargs...
    )
    (; grid) = field
    NF = eltype(field)                          # number format of the spectral coefficients
    nlayers = size(field, 2)
    return SpectralTransform(grid; NF, nlayers, kwargs...)
end

"""$(TYPEDSIGNATURES)
Generator function for a `SpectralTransform` struct to transform between `field` and `coeffs`."""
function SpectralTransform(
        field::AbstractField,
        coeffs::LowerTriangularArray;
        kwargs...
    )
    @boundscheck ismatching(architecture(field), architecture(coeffs)) || throw(ArgumentError("Architectures of field and coeffs do not match."))

    # infer types for SpectralTransform
    NF = promote_type(real(eltype(field)), real(eltype(coeffs)))

    # get resolution
    (; spectrum) = coeffs
    (; grid) = field
    nlayers = size(field, 2)
    @boundscheck nlayers == size(coeffs, 2) || throw(DimensionMismatch("Number of layers in field ($nlayers) and coeffs ($(size(coeffs, 2))) do not match."))
    return SpectralTransform(spectrum, grid; NF, nlayers, kwargs...)
end

# make commutative
SpectralTransform(coeffs::LowerTriangularArray, field::AbstractField; kwargs...) =
    SpectralTransform(field, coeffs; kwargs...)

# CHECK MATCHING SIZES
"""$(TYPEDSIGNATURES)
Spectral transform `S` and lower triangular matrix `L` match if the
spectral dimensions `(lmax, mmax)` match and the number of vertical layers is
equal or larger in the transform (constraints due to allocated scratch memory size)."""
function Architectures.ismatching(S::AbstractSpectralTransform, L::LowerTriangularArray; horizontal_only::Bool = false)
    resolution_match = resolution(S.spectrum) == size(L, OneBased, Matrix)[1:2]
    vertical_match = horizontal_only ? true : length(axes(L, 2)) <= S.nlayers
    return resolution_match && vertical_match
end

"""$(TYPEDSIGNATURES)
Spectral transform `S` and `grid` match if the resolution `nlat_half` and the
type of the grid match and the number of vertical layers is equal or larger in
the transform (constraints due to allocated scratch memory size)."""
function Architectures.ismatching(S::AbstractSpectralTransform, field::AbstractField; horizontal_only::Bool = false)
    grid_match = S.grid == field.grid   # grid type and resolution match
    vertical_match = horizontal_only ? true : size(field, 2) <= S.nlayers
    return grid_match && vertical_match
end

# make `ismatching` commutative
Architectures.ismatching(L::LowerTriangularArray, S::AbstractSpectralTransform) = ismatching(S, L)
Architectures.ismatching(F::AbstractField, S::AbstractSpectralTransform) = ismatching(S, F)

function Base.DimensionMismatch(S::AbstractSpectralTransform, L::LowerTriangularArray)
    S_ = nonparametric_type(S)
    s = "$S_ for $(S.spectrum.lmax)x$(S.spectrum.mmax)x$(S.nlayers) LowerTriangularArrays " *
        "with $(Base.dims2string(size(L, as = Matrix))) " *
        "LowerTriangularArray do not match."
    return DimensionMismatch(s)
end

function Base.DimensionMismatch(S::AbstractSpectralTransform, F::AbstractField)
    S_ = nonparametric_type(S)
    sz = (RingGrids.get_npoints(S.grid), S.nlayers)
    Grid = nonparametric_type(S.grid)
    Grid2 = nonparametric_type(F.grid)
    s = "$S_ for $(Base.dims2string(sz)) $Grid with " *
        "$(Base.dims2string(size(F))) field on $Grid2 do not match."
    return DimensionMismatch(s)
end

# Layer size of scratch memory (north/south columns in `ScratchMemory`).
# On CPU we typically use `nlayers` only (largest allocated plan and physical layers of the model)
# On GPU we batch transforms much more, and need to use a scratch memory in
# accordance with the largest batch which is `nlayers` in this case and ISN'T equal to the physical layers of the model
_scratch_nlayers(::AbstractCPU, ::Integer, planned_K::AbstractVector{<:Integer}) = maximum(planned_K)
_scratch_nlayers(::AbstractArchitecture, nlayers::Integer, ::AbstractVector{<:Integer}) = nlayers
# Reactant fuses the Fourier and Legendre transform without scratch memory (SpeedyTransformsReactantExt)
_scratch_nlayers(::ReactantDevice, ::Integer, ::AbstractVector{<:Integer}) = 0

# Return true if a call with `K` layers should be split into chunks that are
# executed sequentially.
# Architecture-dispatched:
# CPU chunks to avoid FFTW's alignment-mismatch on x86 (no problem on ARM)
# GPU doesn't need any of that we have seperate plans for each K
@inline function _needs_chunking(K::Integer, S::SpectralTransform{NF, <:AbstractCPU}) where {NF}
    K > 1 || return false                            # K=1 always handled directly
    haskey(S.rfft_plans_batched, K) && return false  # K is directly planned, no chunking needed
    # K > 1 and not directly planned: chunk through whichever planned K is largest (≤ K_total).
    # Note this includes the degenerate case `keys(rfft_plans) == [1]`: chunks then have K=1
    # and route to the K=1 plan one layer at a time. Scratch (sized to maximum(planned_K))
    # is guaranteed to fit each chunk in all cases.
    return true
end

@inline _needs_chunking(::Integer, ::SpectralTransform) = false

# Largest planned batch K ≤ K_total, excluding the K=1 fallback. Used to pick the chunk size. Typically this will just be the number of layers in the model.
@inline function _largest_planned_batch(K_total::Integer, S::SpectralTransform)
    best = 1
    for k in keys(S.rfft_plans_batched)
        if k > best && k <= K_total
            best = k
        end
    end
    return best
end

# For CPU only: Split a transform over `K` layers into chunks that each match a pre-built batched FFT plan.
# Each chunk is a sub-view of the input/output along the layer dim; calling `transform!`
# on the sub-views routes through the regular batched path. The trailing remainder
# (size < K_batched) goes through the K=1 serial path one layer at a time.
#
# Why this matters on CPU: FFT plans bake their batch dim K into the plan, and on x86 the
# scratch column-stride (= nfreq_max * sizeof(Complex{NF})) is generally not a multiple
# of the SIMD width, so the K=1 plan can't be applied to columns other than column 1
# without an alignment-mismatch error. Chunking with the sequential execution sidesteps
# that path for the bulk of the layers and effectively restores the previous behavior before
# fusion/batching without performance penalties.
# Greedy chunk sizes: at each position take the largest planned batch that fits the remaining
# layers (1 = the always-planned serial fallback when nothing larger fits)
function _transform_chunked!(                       # SPECTRAL TO GRID
        field::AbstractField, coeffs::LowerTriangularArray,
        scratch_memory::ScratchMemory, S::SpectralTransform;
        unscale_coslat::Bool = false,
    )
    K = size(field, 2)
    c = 1
    while c <= K
        len = _largest_planned_batch(K - c + 1, S)  # planned batch (or 1) fitting the remainder
        chunk = c:(c + len - 1)
        field_chunk = wrapped_view(field, :, chunk)
        coeffs_chunk = wrapped_view(coeffs, :, chunk)
        _transform_nonchunked!(field_chunk, coeffs_chunk, scratch_memory, S, unscale_coslat)
        c += len
    end
    return nothing
end

function _transform_chunked!(                       # GRID TO SPECTRAL
        coeffs::LowerTriangularArray, field::AbstractField,
        scratch_memory::ScratchMemory, S::SpectralTransform,
    )
    K = size(field, 2)
    c = 1
    while c <= K
        len = _largest_planned_batch(K - c + 1, S)  # planned batch (or 1) fitting the remainder
        chunk = c:(c + len - 1)
        field_chunk = wrapped_view(field, :, chunk)
        coeffs_chunk = wrapped_view(coeffs, :, chunk)
        _transform_nonchunked!(coeffs_chunk, field_chunk, scratch_memory, S)
        c += len
    end
    return nothing
end

"""$(TYPEDSIGNATURES)
Spectral transform (spectral to grid space) from n-dimensional array `coeffs` of spherical harmonic
coefficients to an n-dimensional array `field`. Uses FFT in the zonal direction,
and a Legendre Transform in the meridional direction exploiting symmetries. The spectral transform is
number format-flexible but `field` and the spectral transform `S` have to have the same number format.
Uses the precalculated arrays, FFT plans and other constants in the SpectralTransform struct `S`.
The spectral transform is grid-flexible as long as `field.grid` and `S.grid` match."""
transform!(                                 # SPECTRAL TO GRID
    field::AbstractField,                   # gridded output
    coeffs::LowerTriangularArray,           # spectral coefficients input
    S::AbstractSpectralTransform;           # precomputed transform
    unscale_coslat::Bool = false,           # unscale with cos(lat) on the fly?
) = transform!(field, coeffs, S.scratch_memory, S; unscale_coslat)

function transform!(                        # SPECTRAL TO GRID
        field::AbstractField,               # gridded output
        coeffs::LowerTriangularArray,       # spectral coefficients input
        scratch_memory::ScratchMemory,      # explicit scratch memory to use
        S::SpectralTransform;               # precomputed transform
        unscale_coslat::Bool = false,       # unscale with cos(lat) on the fly?
    )
    # thin forwarder to the positional core (see `_transform_grid!`)
    return _transform_grid!(field, coeffs, scratch_memory, S, unscale_coslat)
end

function _transform_grid!(
        field::AbstractField, coeffs::LowerTriangularArray,
        scratch_memory::ScratchMemory, S::SpectralTransform, unscale_coslat::Bool,
    )
    # On CPU, an unplanned K would route the FFT through `_fourier_serial!`, which on x86
    # crashes with an FFTW alignment mismatch when the scratch column-stride is not a multiple
    # of the SIMD width (consecutive columns have differing alignment). Split into chunks
    # matching the largest available batched plan; each chunk uses the batched FFT path
    # against scratch starting at column 1 (always SIMD-aligned). `_needs_chunking` is
    # statically false on GPU/others, so this branch elides there.
    # Checked **before** the boundscheck below so chunking can handle K > S.nlayers
    K = size(field, 2)
    if _needs_chunking(K, S)
        _transform_chunked!(field, coeffs, scratch_memory, S; unscale_coslat)
        return field
    end
    return _transform_nonchunked!(field, coeffs, scratch_memory, S, unscale_coslat)
end

function _transform_nonchunked!(
        field::AbstractField, coeffs::LowerTriangularArray,
        scratch_memory::ScratchMemory, S::SpectralTransform, unscale_coslat::Bool,
    )
    # catch incorrect sizes early
    @boundscheck ismatching(S, field) || throw(DimensionMismatch(S, field))
    @boundscheck ismatching(S, coeffs) || throw(DimensionMismatch(S, coeffs))

    # use scratch memory for Legendre but not yet Fourier-transformed data
    g_north = scratch_memory.north    # phase factors for northern latitudes
    g_south = scratch_memory.south    # phase factors for southern latitudes

    # INVERSE LEGENDRE TRANSFORM in meridional direction
    _legendre!(g_north, g_south, coeffs, scratch_memory.column, S; unscale_coslat)

    # INVERSE FOURIER TRANSFORM in zonal direction
    _fourier!(field, g_north, g_south, S)

    return field
end

"""$(TYPEDSIGNATURES)
Spectral transform (grid to spectral space) from n-dimensional array `field` to an n-dimensional
array `coeffs` of spherical harmonic coefficients. Uses FFT in the zonal direction,
and a Legendre Transform in the meridional direction exploiting symmetries. The spectral transform is
number format-flexible but `field` and the spectral transform `S` have to have the same number format.
Uses the precalculated arrays, FFT plans and other constants in the SpectralTransform struct `S`.
The spectral transform is grid-flexible as long as `field.grid` and `S.grid` match."""
transform!(                                             # GRID TO SPECTRAL
    coeffs::LowerTriangularArray,                       # output: spectral coefficients
    field::AbstractField,                               # input: gridded values
    S::AbstractSpectralTransform,                       # precomputed spectral transform
) = transform!(coeffs, field, S.scratch_memory, S)

function transform!(                                    # GRID TO SPECTRAL
        coeffs::LowerTriangularArray,                   # output: spectral coefficients
        field::AbstractField,                           # input: gridded values
        scratch_memory::ScratchMemory,                  # explicit scratch memory to use
        S::SpectralTransform,                           # precomputed spectral transform
    )
    # thin forwarder to the positional core (see `_transform_spec!`)
    return _transform_spec!(coeffs, field, scratch_memory, S)
end

# Positional core of the grid-to-spectral `transform!`; analytic-adjoint AD boundary, see
# `_transform_grid!` and SpeedyTransformsEnzymeExt.
function _transform_spec!(
        coeffs::LowerTriangularArray, field::AbstractField,
        scratch_memory::ScratchMemory, S::SpectralTransform,
    )
    # Same chunking-before-boundscheck pattern as the spec→grid `transform!` above —
    # see comment there.
    K = size(field, 2)
    if _needs_chunking(K, S)
        _transform_chunked!(coeffs, field, scratch_memory, S)
        return coeffs
    end
    return _transform_nonchunked!(coeffs, field, scratch_memory, S)
end

# Non-chunked core, factored out for the same recursion-breaking + AD-boundary reasons as
# `_transform_nonchunked!` above.
function _transform_nonchunked!(
        coeffs::LowerTriangularArray, field::AbstractField,
        scratch_memory::ScratchMemory, S::SpectralTransform,
    )
    # catch incorrect sizes early
    @boundscheck ismatching(S, field) || throw(DimensionMismatch(S, field))
    @boundscheck ismatching(S, coeffs) || throw(DimensionMismatch(S, coeffs))

    # use scratch memory for Fourier but not yet Legendre-transformed data
    f_north = scratch_memory.north    # phase factors for northern latitudes
    f_south = scratch_memory.south    # phase factors for southern latitudes

    # FOURIER TRANSFORM in zonal direction
    _fourier!(f_north, f_south, field, S)

    # LEGENDRE TRANSFORM in meridional direction
    _legendre!(coeffs, f_north, f_south, scratch_memory.column, S)

    return coeffs
end

# CONVENIENCE/ALLOCATING VERSIONS

"""$(TYPEDSIGNATURES)
Spherical harmonic transform from `field` to a newly allocated `coeffs::LowerTriangularArray`
using the precomputed spectral transform `S`."""
function transform(                         # GRID TO SPECTRAL
        field::AbstractField,               # input field
        S::AbstractSpectralTransform,       # precomputed spectral transform
    )
    coeffs = similar(field, S.spectrum, Complex{eltype(S)})
    transform!(coeffs, field, S)
    return coeffs
end

"""$(TYPEDSIGNATURES)
Spherical harmonic transform from `coeffs` to a newly allocated `field::AbstractField`
using the precomputed spectral transform `S`."""
function transform(                     # SPECTRAL TO GRID
        coeffs::LowerTriangularArray,   # input spectral coefficients
        S::AbstractSpectralTransform;   # precomputed spectral transform
        kwargs...                       # pass on unscale_coslat=true/false(default)
    )
    field = similar(coeffs, S.grid, eltype(S))
    transform!(field, coeffs, S; kwargs...)
    return field
end

"""
$(TYPEDSIGNATURES)
Spectral transform (spectral to grid space) from spherical coefficients `alms` to a newly allocated gridded
field `map`. Based on the size of `alms` the grid type `grid`, the spatial resolution is retrieved based
on the truncation defined for `grid`. SpectralTransform struct `S` is allocated to execute `transform(alms, S)`."""
function transform(
        coeffs::LowerTriangularArray;               # SPECTRAL TO GRID
        unscale_coslat::Bool = false,               # separate from kwargs as argument for transform!
        kwargs...                                   # arguments for SpectralTransform constructor
    )
    S = SpectralTransform(coeffs; kwargs...)        # precompute transform
    return transform(coeffs, S; unscale_coslat)     # do the transform
end

"""
$(TYPEDSIGNATURES)
Spectral transform (grid to spectral space) from `field` to a newly allocated `LowerTriangularArray`.
Based on the size of `field` and the keyword `dealiasing` the spectral resolution `truncation` is
retrieved. SpectralTransform struct `S` is allocated to execute `transform(field, S)`."""
function transform(field::AbstractField; kwargs...) # GRID TO SPECTRAL
    S = SpectralTransform(field; kwargs...)         # precompute transform
    return transform(field, S)                      # do the transform
end
