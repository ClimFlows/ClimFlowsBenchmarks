# =====================================================================================
# BACKEND-AGNOSTIC GPU-GRAPHS MACHINERY FOR THE BATCHED FOURIER TRANSFORM
#
# `include()`-d directly by SpeedyTransforms.jl, so this compiles unconditionally as part of
# the main package — including in CPU-only sessions with no GPU backend loaded. That is
# deliberate: nothing below references CUDA/AMDGPU/ROCArray/CuArray etc. — the kernels are
# plain KernelAbstractions `@kernel` functions, and the only backend-specific pieces (the
# actual capture/instantiate/launch primitives and the graph-exec type, e.g. `CuGraphExec`)
# are supplied from outside via the `GraphBackend` struct built by each extension. So none of
# this has a hard dependency on the "extension-triggering" package and there is no compilation
# reason to gate it behind one (see PR #1232 review discussion).
#
# What DOES still have to stay in the extensions, and can never move here: the concrete
# `_fourier_batched!(..., ::CuArray, ...)` / `::ROCArray` methods and the `CUDA_GRAPH_BACKEND`/
# `HIP_GRAPH_BACKEND` instances. Those genuinely cannot compile without `CuArray`/`ROCArray`
# etc. being defined, i.e. without the GPU package loaded.
# =====================================================================================

"""Maximum number of cached graphs per direction per `SpectralTransform`. Prevents
unbounded growth (and host-side capture cost) when the transform is called with a stream
of freshly-allocated buffers (e.g. the allocating `transform(field, S)`, or new `Variables`
for the same model). Beyond this many distinct (field, scratch) buffer sets the allocation-free
loop is run directly without capturing."""
const MAX_GRAPHS = 64

# =====================================================================================
# Fused gather/scatter kernels — move all rings at once between the strided grid/scratch
# layout and the contiguous packed work buffer (one launch instead of one copy per ring).
# Each kernel is launched over (nlon_max | nfreq_max, nlat_half, nlayers) and masks the
# threads beyond a ring's actual length.
# =====================================================================================

# grid field (npoints × nlayers) ring rows  ->  packed real buffer  (forward gather)
@kernel inbounds = true function gather_real_kernel!(packed, src, real_offset, nlons, istart)
    i, j, k = @index(Global, NTuple)
    nlon = nlons[j]
    if i <= nlon
        packed[real_offset[j] + (k - 1) * nlon + i] = src[istart[j] + i - 1, k]
    end
end

# packed complex buffer  ->  scratch (nfreq_max × nlayers × nlat_half)  (forward scatter)
@kernel inbounds = true function scatter_complex_kernel!(dst, packed, complex_offset, nfreqs)
    m, j, k = @index(Global, NTuple)
    nfreq = nfreqs[j]
    if m <= nfreq
        dst[m, k, j] = packed[complex_offset[j] + (k - 1) * nfreq + m]
    end
end

# scratch  ->  packed complex buffer  (inverse gather)
@kernel inbounds = true function gather_complex_kernel!(packed, src, complex_offset, nfreqs)
    m, j, k = @index(Global, NTuple)
    nfreq = nfreqs[j]
    if m <= nfreq
        packed[complex_offset[j] + (k - 1) * nfreq + m] = src[m, k, j]
    end
end

# packed real buffer  ->  grid field ring rows  (inverse scatter)
# `add` selects overwrite (`=`, the plain transform) vs accumulate (`+=`, used by the Enzyme adjoint
# rules). It is a plain `Bool` kernel argument rather than a type parameter: the branch is uniform
# across all threads (no divergence) and graphs are captured per `add` mode anyway (see
# `inverse_execs`), so a second specialisation would buy nothing.
@kernel inbounds = true function scatter_real_kernel!(dst, packed, real_offset, nlons, istart, add)
    i, j, k = @index(Global, NTuple)
    nlon = nlons[j]
    if i <= nlon
        i_dst = istart[j] + i - 1
        val = packed[real_offset[j] + (k - 1) * nlon + i]
        if add
            dst[i_dst, k] += val
        else
            dst[i_dst, k] = val
        end
    end
end

# =====================================================================================
# Per-SpectralTransform cache: contiguous packed work buffers, reshaped per-ring views
# for the FFTs, device-side gather/scatter metadata, and the instantiated GPU graphs.
# =====================================================================================

# Graph-cache key: the addresses of all buffers a captured graph bakes in that the caller
# passes in, see `graph_key`
const GraphKey = Tuple{UInt, UInt, UInt, NTuple{3, Int}}

"""$(TYPEDSIGNATURES)
Cache (one per transform SIZE, i.e. per FFT plan) holding the pre-allocated packed
work buffers, the per-ring reshaped views and FFT plans used by the transforms, the device
gather/scatter index metadata, and the instantiated GPU graphs (one per distinct (field,
scratch) buffer set and direction, see [`graph_key`](@ref)). A graph value of `nothing` marks
a buffer set for which capture failed (fall back to direct loop). `E` is the backend's
graph-exec type (e.g. `CuGraphExec`)."""
struct GPUFourierGraphCache{PR, PC, RV, CV, RFP, BFP, IV, A, E}
    packed_real::PR             # device Vector{NF}          — all rings' dense real blocks
    packed_complex::PC          # device Vector{Complex{NF}} — all rings' dense complex blocks
    real_view::RV               # Vector of per-ring reshaped (nlon_j × nlayers) views into packed_real
    complex_view::CV            # Vector of per-ring reshaped (nfreq_j × nlayers) views into packed_complex
    rfft_plans::RFP             # forward FFT plans for THIS size (nlayers batches), per ring
    brfft_plans::BFP            # inverse FFT plans for THIS size, per ring
    real_offset::IV             # 0-based real-block offset per ring
    complex_offset::IV          # 0-based complex-block offset per ring
    nlons::IV                   # longitudes per ring
    nfreqs::IV                  # Fourier frequencies per ring
    istart_n::IV                # first grid row of each northern ring
    istart_s::IV                # first grid row of each southern ring
    nlons_s::IV                 # like nlons but 0 at the equator ring (south skip)
    nlon_max::Int               # maximum number of longitudes across all rings (for launch size)
    nfreq_max::Int              # maximum number of frequencies across all rings (for launch size)
    nlat_half::Int              # number of rings on one hemisphere, equator included
    nlayers::Int                # number of vertical layers (for launch size)
    has_equator::Bool           # whether the grid has a ring on the equator that needs special handling
    j_equator::Int              # latitude index of the equator ring (if any)
    arch::A                     # SpeedyWeather GPU architecture (for launch!)
    forward_execs::Dict{GraphKey, Union{Nothing, E}}    # forward graphs, keyed by field + scratch buffers
    # inverse graphs, keyed by (field + scratch buffers, `add`): a captured graph bakes in whether the
    # scatter overwrites or accumulates, so the two modes must never share a graph.
    inverse_execs::Dict{Tuple{GraphKey, Bool}, Union{Nothing, E}}
end

# One cache per (SpectralTransform, transform size), keyed by the *forward FFT plan set*
# (`fft_plans(S, nlayers)[1]`)
# this is saved here directly as a global variable and not as a field of `S` because
# it would be very hard to make `S` a concrete type again otherwise, and this seems to work
# without problems and performance mali
const GRAPH_CACHES = IdDict{Any, GPUFourierGraphCache}()

# EXTENSION POINT for batching: return the
# (forward, inverse) per-ring FFT plan sets for a transform of `nlayers` layers. The default
# assumes a single size; override this for an `S` that stores several plan sets (e.g. keyed
# by layer count) and the rest — caches, packing, capture, replay — follows automatically.
# gets called by `cache_key` when accessing the different caches and graphs
fft_plans(S::SpectralTransform, nlayers::Integer) = (S.rfft_plans_batched[nlayers], S.brfft_plans_batched[nlayers])

# build/allocate the cache for a transform of `nlayers` layers. `E` is the backend's
# graph-exec type, supplied by the including extension (e.g. `CuGraphExec`).
function build_cache(::Type{E}, S::SpectralTransform, nlayers::Integer) where {E}
    NF = eltype(S)
    nlat = S.nlat
    nlat_half = S.grid.nlat_half
    rfft_plans, brfft_plans = fft_plans(S, nlayers)
    rings = S.rings
    nlons = collect(Int, S.nlons[1:nlat_half])
    nfreqs = nlons .÷ 2 .+ 1

    # packed buffer block offset
    block_real = nlons .* nlayers
    block_complex = nfreqs .* nlayers
    real_offset = [0; cumsum(block_real)[1:(end - 1)]]
    complex_offset = [0; cumsum(block_complex)[1:(end - 1)]]

    istart_n = [rings[j].start for j in 1:nlat_half]
    istart_s = [rings[nlat - j + 1].start for j in 1:nlat_half]

    has_equator = isodd(nlat)
    j_equator = (nlat + 1) ÷ 2
    nlons_s = copy(nlons)
    has_equator && (nlons_s[j_equator] = 0)        # south pass skips the equator ring

    arch = S.architecture
    dev(x) = on_architecture(arch, x)              # device-agnostic transfer (works for any GPU backend)
    packed_real = dev(zeros(NF, sum(block_real)))
    packed_complex = dev(zeros(Complex{NF}, sum(block_complex)))
    real_view = [reshape(view(packed_real, (real_offset[j] + 1):(real_offset[j] + block_real[j])), nlons[j], nlayers) for j in 1:nlat_half]
    complex_view = [reshape(view(packed_complex, (complex_offset[j] + 1):(complex_offset[j] + block_complex[j])), nfreqs[j], nlayers) for j in 1:nlat_half]

    return GPUFourierGraphCache(
        packed_real, packed_complex, real_view, complex_view,
        rfft_plans, brfft_plans,
        dev(real_offset), dev(complex_offset), dev(nlons), dev(nfreqs),
        dev(istart_n), dev(istart_s), dev(nlons_s),
        S.nlon_max, S.nfreq_max, nlat_half, nlayers, has_equator, j_equator,
        arch,
        Dict{GraphKey, Union{Nothing, E}}(),
        Dict{Tuple{GraphKey, Bool}, Union{Nothing, E}}(),
    )
end

"""$(TYPEDSIGNATURES)
The per-size resource that identifies a graph cache. The forward FFT plan set is unique per
transform size and stable for the lifetime of `S`. Must return *the stored*
plan object (not a fresh allocation) so the identity is stable across calls."""
cache_key(S::SpectralTransform, nlayers::Integer) = fft_plans(S, nlayers)[1]

# keyed by the forward FFT plan set (= the per-size resource); `nlayers` sizes the cache
get_cache(::Type{E}, S::SpectralTransform, nlayers::Integer) where {E} =
    get!(() -> build_cache(E, S, nlayers), GRAPH_CACHES, cache_key(S, nlayers))::GPUFourierGraphCache

"""$(TYPEDSIGNATURES)
Trim the memory pool of the backend. EXTENSION POINT, does nothing by default."""
reclaim!(::AbstractArchitecture) = nothing

"""$(TYPEDSIGNATURES)
Clear all cached GPU-graphs Fourier buffers and graphs. With `gc = true` (default) also
run a full GC and [`reclaim!`](@ref) the device memory of the cleared caches' architectures
and of any `architectures` passed on. Mainly useful for tests/benchmarks."""
function clear_fourier_graph_cache!(architectures::AbstractArchitecture...; gc::Bool = true)
    architectures = unique!(AbstractArchitecture[architectures..., (cache.arch for cache in values(GRAPH_CACHES))...])
    empty!(GRAPH_CACHES)
    if gc
        GC.gc(true)
        foreach(reclaim!, architectures)
    end
    return nothing
end

# =====================================================================================
# Allocation-free fused loops (capturable). They write exactly the regions the generic
# `_fourier_batched!` writes (rows 1:nfreq of each ring's scratch slice for the forward;
# the full ring rows of `field` for the inverse), so the result is identical.
# =====================================================================================

"""$(TYPEDSIGNATURES)
Allocation-free, fused forward (grid → spectral) batched Fourier loop: one gather kernel
packs all rings, per-ring in-place FFTs run on reshaped views, one scatter kernel writes
the scratch. Suitable for GPU-graph capture."""
function forward_loop!(cache::GPUFourierGraphCache, f_north, f_south, field::AbstractField, S::SpectralTransform)
    (; arch) = cache
    (; nlat_half, nlayers) = cache
    (; nlon_max, nfreq_max, nlons, nfreqs, j_equator) = cache
    (; real_view, complex_view, packed_real, packed_complex, rfft_plans) = cache
    (; real_offset, complex_offset, istart_n, istart_s) = cache

    real_size = (nlon_max, nlat_half, nlayers)          # launch scatter/gather kernels over
    complex_size = (nfreq_max, nlat_half, nlayers)

    # northern rings,
    launch!(arch, ArrayWorkOrder, real_size, gather_real_kernel!, packed_real, field.data, real_offset, nlons, istart_n)
    @inbounds for j in 1:nlat_half
        LinearAlgebra.mul!(complex_view[j], rfft_plans[j], real_view[j])
    end
    launch!(arch, ArrayWorkOrder, complex_size, scatter_complex_kernel!, f_north, packed_complex, complex_offset, nfreqs)

    # southern rings (the equator ring, if any, is zeroed rather than transformed)
    launch!(arch, ArrayWorkOrder, real_size, gather_real_kernel!, packed_real, field.data, real_offset, nlons, istart_s)
    @inbounds for j in 1:nlat_half
        if cache.has_equator && j == j_equator
            fill!(complex_view[j], 0)
        else
            LinearAlgebra.mul!(complex_view[j], rfft_plans[j], real_view[j])
        end
    end
    launch!(arch, ArrayWorkOrder, complex_size, scatter_complex_kernel!, f_south, packed_complex, complex_offset, nfreqs)
    return nothing
end

"""$(TYPEDSIGNATURES)
Allocation-free, fused inverse (spectral → grid) batched Fourier loop: one gather kernel
packs all rings from the scratch, per-ring in-place inverse FFTs run on reshaped views,
one scatter kernel writes the grid field. `add` accumulates onto `field` instead of overwriting it
(Enzyme adjoint rule); it is baked into the captured graph, hence the per-`add` graph cache key.
Suitable for GPU-graph capture."""
function inverse_loop!(cache::GPUFourierGraphCache, field::AbstractField, g_north, g_south, S::SpectralTransform, add::Bool = false)
    (; arch) = cache
    (; nlat_half, nlayers) = cache
    (; nlon_max, nfreq_max, nlons, nlons_s, nfreqs, j_equator) = cache
    (; real_view, complex_view, packed_real, packed_complex, brfft_plans) = cache
    (; real_offset, complex_offset, istart_n, istart_s) = cache

    real_size = (nlon_max, nlat_half, nlayers)
    complex_size = (nfreq_max, nlat_half, nlayers)

    # northern rings
    launch!(arch, ArrayWorkOrder, complex_size, gather_complex_kernel!, packed_complex, g_north, complex_offset, nfreqs)
    @inbounds for j in 1:nlat_half
        LinearAlgebra.mul!(real_view[j], brfft_plans[j], complex_view[j])
    end
    launch!(arch, ArrayWorkOrder, real_size, scatter_real_kernel!, field.data, packed_real, real_offset, nlons, istart_n, add)

    # southern rings (the equator ring, if any, is skipped: north already wrote those rows)
    launch!(arch, ArrayWorkOrder, complex_size, gather_complex_kernel!, packed_complex, g_south, complex_offset, nfreqs)
    @inbounds for j in 1:nlat_half
        (cache.has_equator && j == j_equator) && continue
        LinearAlgebra.mul!(real_view[j], brfft_plans[j], complex_view[j])
    end
    launch!(arch, ArrayWorkOrder, real_size, scatter_real_kernel!, field.data, packed_real, real_offset, nlons_s, istart_s, add)
    return nothing
end

# =====================================================================================
# Capture / replay management
# =====================================================================================

"""$(TYPEDSIGNATURES)
Bundles the backend-specific primitives `run_graph!` needs to capture and replay a GPU
graph, so the control flow in `run_graph!` itself can stay backend-agnostic:

- `capture(loop!)`: run `loop!` under stream capture and return the recorded graph, or
  `nothing` if capture failed/was invalidated (must not throw).
- `instantiate(graph)`: turn a captured graph into an executable.
- `launch(exec)`: replay an instantiated graph.
- `device`: the SpeedyWeather architecture (e.g. `GPU(CUDA.CUDABackend())`) whose device is
  synchronized once before capture (via `synchronize(backend.device)`, as elsewhere in the
  codebase), so that one-time warmup work happens outside the captured region.

e.g. for CUDA: `GraphBackend(loop! -> CUDA.capture(loop!; throw_error = false), CUDA.instantiate, CUDA.launch, GPU(CUDA.CUDABackend()))`.
"""

struct GraphBackend{C, I, L, D}
    capture::C
    instantiate::I
    launch::L
    device::D
end

"""$(TYPEDSIGNATURES)
Run `loop!` (a `() -> ...` closure over the allocation-free batched FFT) either by
replaying a cached GPU graph keyed by `key`, or — on first use — by warming up, capturing,
instantiating and caching a graph via the given `backend`. Falls back to running `loop!`
directly if capture fails or the per-direction cache is full."""
function run_graph!(execs::AbstractDict, key, loop!::F, backend::GraphBackend) where {F}
    exec = get(execs, key, missing)          # `missing` is fallback value that gets return when there's no cached exec yet
    if exec !== missing && exec !== nothing
        backend.launch(exec)                 # hot path: pure replay
        return nothing
    elseif exec === nothing                  # fallback (`nothing` -> tried to capture, but failed (e.g. because MAX_GRAPHS reached))
        loop!()                              # fallback to non-graph direct loop for unknown non-capturable buffer
        return nothing
    end

    # first time we see this buffer (exec === missing)
    if length(execs) >= MAX_GRAPHS
        loop!()                              # cache full: don't capture, just run
        return nothing
    end

    # if we haven't exited yet, so far we know we have to capture

    # warm up so that one-time work (FFT plan init, kernel JIT, memory-pool growth) happens
    # OUTSIDE the capture, where it is allowed
    loop!()
    synchronize(backend.device)

    # do the capture
    graph = backend.capture(loop!)

    if graph === nothing
        # capture invalidated (e.g. an unexpected allocation/sync); the warmup already
        # produced the correct result. Remember not to retry capture for this buffer.
        execs[key] = nothing
        return nothing
    end

    # save the graph
    exec = backend.instantiate(graph)
    execs[key] = exec

    return nothing
end

# address of a device array (or of a view into one, e.g. the per-step views of the time stepping)
@inline device_address(data) = reinterpret(UInt, pointer(data))

"""$(TYPEDSIGNATURES)
Graph-cache key of a call with the grid `field` and the scratch memory arrays `north`, `south`:
the device addresses of all buffers a captured graph bakes in that the caller passes in, and
the size of the scratch arrays. The remaining buffers a graph uses (packed work buffers, index
arrays, FFT plans) belong to the `GPUFourierGraphCache` and live as long as the graph.

Addresses, not the wrappers' object identity: the time stepping fetches the grid field for each
transform via `get_prognostic_step` / `get_tendency_step`, i.e. a `field_view`/`get_step` on a
step-dimensioned grid variable. On the GPU `view(::CuArray, :, :, step)` returns a fresh
`CuArray` wrapper each call, so keying on the wrapper would capture a new graph every time step
and the cache would grow without bound. The wrapper churns but always aliases the same device
memory at the same offset, so its address (exactly what the graph bakes in) is stable.

The scratch memory is part of the key because it is not owned by the transform: in a simulation
it is `vars.scratch.transform_memory`, part of the `Variables`, and every new `Variables` for the
same model (another `initialize!(model)`, a `deepcopy`) brings new scratch memory, while the
memory pool may hand its field a recycled address. Keyed on the field alone, such a call would
replay a graph that writes into (or reads from) the freed scratch memory of earlier `Variables`.
A graph is therefore only replayed when all of its caller-provided buffers are those of the
current call. The scratch size is included because the gather/scatter kernels index the scratch
arrays with their size, and scratch memory with another number of layers could be allocated at
a recycled address."""
@inline graph_key(field::AbstractField, north::AbstractArray, south::AbstractArray)::GraphKey =
    (device_address(field.data), device_address(north), device_address(south), size(north))
