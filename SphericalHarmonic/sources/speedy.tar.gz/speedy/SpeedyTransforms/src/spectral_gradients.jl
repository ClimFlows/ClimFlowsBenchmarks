const DEFAULT_RADIUS = 1

"""
    KernelOP{mode, flipsign, add}

Type for dispatching on kernel operations in spectral gradient calculations.
- `mode`: `true` for curl, `false` for divergence
- `flipsign`: `true` or `false` to negate the result
- `add`: `true` or `false` to add to the output instead of overwriting
"""
struct KernelOP{mode, flipsign, add} end

# `mode`, `flipsign` and `add` are type parameters, so the branches below are compile-time constants
@inline function (::KernelOP{mode, flipsign, add})(o, a, b, c) where {mode, flipsign, add}
    base = mode ? (a + b - c) : (a - b + c)     # curl : divergence
    val = flipsign ? -base : base
    return add ? o + val : val
end


"""
$(TYPEDSIGNATURES)
Curl of a vector `u, v` written into `curl`, `curl = ∇×(u, v)`.
`u, v` are expected to have a 1/coslat-scaling included, otherwise `curl` is scaled.
Acts on the unit sphere, i.e. it omits 1/radius scaling as all gradient operators
unless the `radius` keyword argument is provided. `flipsign` option calculates -∇×(u, v) instead.
`add` option calculates `curl += ∇×(u, v)` instead. `flipsign` and `add` can be combined.
This functions only creates the kernel and calls the generic divergence function _divergence!
subsequently with flipped u, v -> v, u for the curl."""
function curl!(
        curl::LowerTriangularArray,
        u::LowerTriangularArray,
        v::LowerTriangularArray,
        S::AbstractSpectralTransform;
        flipsign::Bool = false,
        add::Bool = false,
        kwargs...,
    )
    # = -(∂λ - ∂θ) or (∂λ - ∂θ), adding or overwriting the output curl
    return _divergence!(Val(true), flipsign, add, curl, v, u, S; kwargs...)   # flip u, v -> v, u
end

"""
$(TYPEDSIGNATURES)
Divergence of a vector `u, v` written into `div`, `div = ∇⋅(u, v)`. 
`u, v` are expected to have a 1/coslat-scaling included, otherwise `div` is scaled.
Acts on the unit sphere, i.e. it omits 1/radius scaling as all gradient operators,
unless the `radius` keyword argument is provided. `flipsign` option calculates -∇⋅(u, v) instead.
`add` option calculates `div += ∇⋅(u, v)` instead. `flipsign` and `add` can be combined.
This functions only creates the kernel and calls the generic divergence function _divergence! subsequently."""
function divergence!(
        div::LowerTriangularArray,
        u::LowerTriangularArray,
        v::LowerTriangularArray,
        S::AbstractSpectralTransform;
        flipsign::Bool = false,
        add::Bool = false,
        kwargs...,
    )
    # = -(∂λ + ∂θ) or (∂λ + ∂θ), adding or overwriting the output div
    return _divergence!(Val(false), flipsign, add, div, u, v, S; kwargs...)
end

# `KernelOP` encodes `flipsign`/`add` as type parameters (the functors above dispatch on them inside the
# kernel), but `curl!`/`divergence!` receive them as *runtime* `Bool`s — so `KernelOP{mode, flipsign, add}()`
# would widen to the abstract `KernelOP{mode}` and force `_divergence!` through a runtime dispatch.
# Manually union-split on the two Bools so each `_divergence!` call sees a CONCRETE `KernelOP`.
# `mode` is passed as `Val` (a literal at both call sites) so it const-folds.
@inline function _divergence!(
        ::Val{mode}, flipsign::Bool, add::Bool,
        div::LowerTriangularArray, u::LowerTriangularArray, v::LowerTriangularArray,
        S::AbstractSpectralTransform; kwargs...,
    ) where {mode}
    return if flipsign
        add ? _divergence!(KernelOP{mode, true, true}(), div, u, v, S; kwargs...) :
            _divergence!(KernelOP{mode, true, false}(), div, u, v, S; kwargs...)
    else
        add ? _divergence!(KernelOP{mode, false, true}(), div, u, v, S; kwargs...) :
            _divergence!(KernelOP{mode, false, false}(), div, u, v, S; kwargs...)
    end
end

function _divergence!(
        kernel,
        div::LowerTriangularArray,
        u::LowerTriangularArray,
        v::LowerTriangularArray,
        S::AbstractSpectralTransform;
        radius = DEFAULT_RADIUS,
    )
    (; grad_x_vordiv, grad_y_vordiv1, grad_y_vordiv2) = S.gradients

    @boundscheck ismatching(S, div) || throw(DimensionMismatch(S, div))

    launch!(architecture(div), SpectralWorkOrder, size(div), _divergence_kernel!, kernel, div, u, v, grad_x_vordiv, grad_y_vordiv1, grad_y_vordiv2, size(div, 1))

    # radius scaling if not unit sphere
    if radius != 1
        div .*= inv(convert(real(eltype(div)), radius))
    end

    return div
end

@kernel inbounds = true function _divergence_kernel!(kernel_func::KernelOP{mode, flipsign, add}, div, u, v, grad_x_vordiv, grad_y_vordiv1, grad_y_vordiv2, lmmax) where {mode, flipsign, add}

    I = @index(Global, Cartesian)
    lm = I[1]
    k = ndims(div) == 1 ? CartesianIndex() : I[2]

    # branch-free, see the comment above `previous_lm`: no lm-1 and no zonal term (m = 0) for the
    # first element, the last element (lm==lmax) is zero
    first_element = lm == 1
    last_element = lm == lmmax

    # ∂u/∂λ = i·m·u: multiply-by-imaginary is a 90° rotate + scale (2 real muls) rather than the
    # generic 4-mul/2-add complex product the compiler emits for `im * m * u`.
    z = u[I]
    m = grad_x_vordiv[lm]
    ∂u∂λ = Complex(-m * imag(z), m * real(z))
    ∂u∂λ = ifelse(first_element, zero(∂u∂λ), ∂u∂λ)
    ∂v∂θ1 = grad_y_vordiv1[lm] * v[previous_lm(lm, lmmax), k]
    ∂v∂θ1 = ifelse(first_element, zero(∂v∂θ1), ∂v∂θ1)
    ∂v∂θ2 = grad_y_vordiv2[lm] * v[next_lm(lm, lmmax), k]
    div_lm = kernel_func(div[I], ∂u∂λ, ∂v∂θ1, ∂v∂θ2)
    div[I] = ifelse(last_element, zero(div_lm), div_lm)
end

"""
$(TYPEDSIGNATURES)
Divergence (∇⋅) of two vector components `u, v` which need to have size (n+1)xn,
the last row will be set to zero in the returned `LowerTriangularMatrix`.
This function requires both `u, v` to be transforms of fields that are scaled with
`1/cos(lat)`. Acts on the unit sphere, i.e. it omits 1/radius scaling unless
`radius` keyword argument is provided.
An example usage is therefore

    RingGrids.scale_coslat⁻¹!(u_grid)
    RingGrids.scale_coslat⁻¹!(v_grid)
    u = transform(u_grid, one_more_degree=true)
    v = transform(v_grid, one_more_degree=true)
    div = divergence(u, v, radius = 6.371e6)
    div_grid = transform(div)
"""
function divergence(
        u::LowerTriangularArray,
        v::LowerTriangularArray;
        kwargs...
    )

    S = SpectralTransform(u)
    return divergence(u, v, S; kwargs...)
end

# use SpectralTransform if provided
function divergence(
        u::LowerTriangularArray,
        v::LowerTriangularArray,
        S::AbstractSpectralTransform;
        kwargs...
    )
    div = similar(u)
    return divergence!(div, u, v, S; add = false, flipsign = false, kwargs...)
end

# called by divergence or curl
function _div_or_curl(
        kernel!,
        u::AbstractField,
        v::AbstractField;
        kwargs...,
    )
    u_grid = copy(u)
    v_grid = copy(v)

    RingGrids.scale_coslat⁻¹!(u_grid)
    RingGrids.scale_coslat⁻¹!(v_grid)

    S = SpectralTransform(u_grid, one_more_degree = true)
    us = transform(u_grid, S)
    vs = transform(v_grid, S)

    div_or_vor = similar(us)
    kernel!(div_or_vor, us, vs, S; add = false, flipsign = false, kwargs...)
    return div_or_vor
end

"""
$(TYPEDSIGNATURES)
Divergence (∇⋅) of two vector components `u, v` on a grid.
Applies 1/coslat scaling, transforms to spectral space and returns
the spectral divergence. Acts on the unit sphere, i.e. it omits 1/radius scaling unless
`radius` keyword argument is provided.
"""
divergence(u::AbstractField, v::AbstractField; kwargs...) = _div_or_curl(divergence!, u, v; kwargs...)

"""
$(TYPEDSIGNATURES)
Curl (∇×) of two vector components `u, v` on a grid.
Applies 1/coslat scaling, transforms to spectral space and returns
the spectral curl. Acts on the unit sphere, i.e. it omits 1/radius scaling unless
`radius` keyword argument is provided."""
curl(u::AbstractField, v::AbstractField; kwargs...) = _div_or_curl(curl!, u, v; kwargs...)

"""
$(TYPEDSIGNATURES)
Curl (∇×) of two vector components `u, v` of size (n+1)xn, the last row
will be set to zero in the returned `LowerTriangularMatrix`. This function
requires both `u, v` to be transforms of fields that are scaled with
`1/cos(lat)`. Acts on the unit sphere, i.e. it omits 1/radius scaling unless
`radius` keyword argument is provided. An example usage is therefore

    RingGrids.scale_coslat⁻¹!(u_grid)
    RingGrids.scale_coslat⁻¹!(v_grid)
    u = transform(u_grid)
    v = transform(v_grid)
    vor = curl(u, v, radius=6.371e6)
    vor_grid = transform(div)
"""
function curl(
        u::LowerTriangularArray,
        v::LowerTriangularArray;
        kwargs...
    )

    S = SpectralTransform(u)
    return curl(u, v, S; kwargs...)
end

# use SpectralTransform if provided
function curl(
        u::LowerTriangularArray,
        v::LowerTriangularArray,
        S::AbstractSpectralTransform;
        kwargs...
    )
    vor = similar(u)
    curl!(vor, u, v, S; add = false, flipsign = false, kwargs...)
    return vor
end

"""
$(TYPEDSIGNATURES)
Get U, V (=(u, v)*coslat) from vorticity ζ spectral space (divergence D=0)
Two operations are combined into a single linear operation. First, invert the
spherical Laplace ∇² operator to get stream function from vorticity. Then
compute zonal and meridional gradients to get U, V.
Acts on the unit sphere, i.e. it omits any radius scaling as all inplace gradient operators,
unless the `radius` keyword argument is provided."""
function UV_from_vor!(
        U::LowerTriangularArray,
        V::LowerTriangularArray,
        vor::LowerTriangularArray,
        S::AbstractSpectralTransform;
        radius = DEFAULT_RADIUS,
    )
    (; vordiv_to_uv_x, vordiv_to_uv1, vordiv_to_uv2) = S.gradients
    @boundscheck ismatching(S, U) || throw(DimensionMismatch(S, U))

    launch!(architecture(U), SpectralWorkOrder, size(U), _UV_from_vor_kernel!, U, V, vor, vor.spectrum.l_indices, vor.spectrum.lmax, vordiv_to_uv_x, vordiv_to_uv1, vordiv_to_uv2)

    # *radius scaling if not unit sphere (*radius² for ∇⁻² then /radius to get from stream function to velocity)
    if radius != 1
        U .*= radius
        V .*= radius
    end

    return U, V
end

# The gradient kernels below are branch-free: the special cases (first element, last two rows)
# set coefficients to zero instead of branching, and the neighbours lm-1, lm+1 wrap around at the
# first and last element (where their coefficient is zero). Results are identical to branching (for
# finite input) but Reactant can raise these kernels to StableHLO, needed to differentiate with Enzyme.
# The wrap-around uses `rem` as other index clamps (`max`, `min`, `mod`) can't be raised.
# The wrap-around works because the coefficients are zero for lm-1, lm+1 in the first and last row and the 
# kernels also set them so that it's safe. 
@inline previous_lm(lm, lmmax) = rem(lm - 2 + lmmax, lmmax) + 1
@inline next_lm(lm, lmmax) = rem(lm, lmmax) + 1

@kernel inbounds = true function _UV_from_vor_kernel!(U, V, vor, l_indices, lmax, vordiv_to_uv_x, vordiv_to_uv1, vordiv_to_uv2)
    I = @index(Global, Cartesian)
    lm = I[1]
    k = ndims(vor) == 1 ? CartesianIndex() : I[2]
    lmmax = size(vor, 1)
    l = l_indices[lm]

    # Handle different cases based on position in the triangular matrix
    # (no lm+1 terms in the last two rows in case vor[lmax,:] != 0, see comment in UV_from_vordiv!)
    first_element = lm == 1                                 # no lm-1 term for the first element
    second_last_row = (l == lmax - 1) & !first_element      # no lm+1 term
    last_row = (l == lmax) & !first_element                 # no lm+1 term and V = 0

    # Get the coefficients for the current lm index, zero for the terms that don't exist
    vordiv_uv1 = vordiv_to_uv1[lm]
    vordiv_uv1 = ifelse(first_element, zero(vordiv_uv1), vordiv_uv1)
    vordiv_uv2 = vordiv_to_uv2[lm]
    vordiv_uv2 = ifelse(second_last_row | last_row, zero(vordiv_uv2), vordiv_uv2)
    uv_x = vordiv_to_uv_x[lm]
    z = im * ifelse(last_row, zero(uv_x), uv_x)

    lm_prev = previous_lm(lm, lmmax)
    lm_next = next_lm(lm, lmmax)

    # U = -∂/∂lat(Ψ) combined with Laplace inversion ∇⁻²
    U[I] = muladd(vordiv_uv2, vor[lm_next, k], -vordiv_uv1 * vor[lm_prev, k])
    # V = ∂/∂λ(Ψ)
    V[I] = z * vor[I]
end

"""
$(TYPEDSIGNATURES)
Get U, V (=(u, v)*coslat) from vorticity ζ and divergence D in spectral space.
Two operations are combined into a single linear operation. First, invert the
spherical Laplace ∇² operator to get stream function from vorticity and
velocity potential from divergence. Then compute zonal and meridional gradients
to get U, V.
Acts on the unit sphere, i.e. it omits any radius scaling as all inplace gradient operators.
"""
function UV_from_vordiv!(
        U::LowerTriangularArray,
        V::LowerTriangularArray,
        vor::LowerTriangularArray,
        div::LowerTriangularArray,
        S::AbstractSpectralTransform;
        radius = DEFAULT_RADIUS,
    )
    (; vordiv_to_uv_x, vordiv_to_uv1, vordiv_to_uv2) = S.gradients
    @boundscheck ismatching(S, U) || throw(DimensionMismatch(S, U))

    launch!(architecture(U), SpectralWorkOrder, size(U), _UV_from_vordiv_kernel!, U, V, vor, div, vor.spectrum.l_indices, vor.spectrum.lmax, vordiv_to_uv_x, vordiv_to_uv1, vordiv_to_uv2)

    # *radius scaling if not unit sphere (*radius² for ∇⁻², then /radius to get from stream function to velocity)
    if radius != 1
        radius = convert(real(eltype(U)), radius)
        U .*= radius
        V .*= radius
    end

    return U, V
end

@kernel inbounds = true function _UV_from_vordiv_kernel!(U, V, vor, div, l_indices, lmax, vordiv_to_uv_x, vordiv_to_uv1, vordiv_to_uv2)
    I = @index(Global, Cartesian)
    lm = I[1]
    k = ndims(vor) == 1 ? CartesianIndex() : I[2]
    lmmax = size(vor, 1)
    l = l_indices[lm]

    # Handle different cases based on position in the triangular matrix, branch-free (see above)
    first_element = lm == 1                                 # no lm-1 terms for the first element
    second_last_row = (l == lmax - 1) & !first_element      # no lm+1 terms in the second last row
    last_row = (l == lmax) & !first_element                 # only the lm-1 terms in the last row

    # Get the coefficients for the current lm index, zero for the terms that don't exist
    vordiv_uv1 = vordiv_to_uv1[lm]
    vordiv_uv1 = ifelse(first_element, zero(vordiv_uv1), vordiv_uv1)
    vordiv_uv2 = vordiv_to_uv2[lm]
    vordiv_uv2 = ifelse(second_last_row | last_row, zero(vordiv_uv2), vordiv_uv2)
    uv_x = vordiv_to_uv_x[lm]
    z = im * ifelse(last_row, zero(uv_x), uv_x)

    lm_prev = previous_lm(lm, lmmax)
    lm_next = next_lm(lm, lmmax)

    # Meridional gradient contributions
    ∂ζθ = muladd(vordiv_uv2, vor[lm_next, k], -vordiv_uv1 * vor[lm_prev, k])
    ∂Dθ = muladd(vordiv_uv1, div[lm_prev, k], -vordiv_uv2 * div[lm_next, k])

    # Zonal gradient contributions
    U[I] = muladd(z, div[I], ∂ζθ)          # = ∂Dλ + ∂ζθ
    V[I] = muladd(z, vor[I], ∂Dθ)          # = ∂ζλ + ∂Dθ
end


"""
$(TYPEDSIGNATURES)
Laplace operator ∇² applied to the spectral coefficients `alms` in spherical
coordinates. The eigenvalues which are precomputed in `S`.
∇²! is the in-place version which directly stores the output in the first argument `∇²alms`.
Acts on the unit sphere, i.e. it omits any radius scaling as all inplace gradient operators,
unless the `radius` keyword argument is provided.

Keyword arguments
=================

  - `add=true` adds the ∇²(alms) to the output
  - `flipsign=true` computes -∇²(alms) instead
  - `inverse=true` computes ∇⁻²(alms) instead

Default is `add=false`, `flipsign=false`, `inverse=false`. These options can be combined.
"""
function ∇²!(
        ∇²alms::LowerTriangularArray,       # Output: (inverse) Laplacian of alms
        alms::LowerTriangularArray,         # Input: spectral coefficients
        S::AbstractSpectralTransform;       # precomputed eigenvalues
        add::Bool = false,                  # add to output array or overwrite
        flipsign::Bool = false,             # -∇² or ∇²
        inverse::Bool = false,              # ∇⁻² or ∇²
        radius = DEFAULT_RADIUS,            # scale with radius if provided, otherwise unit sphere
    )
    @boundscheck ismatching(S, ∇²alms) || throw(DimensionMismatch(S, ∇²alms))

    # use eigenvalues⁻¹/eigenvalues for ∇⁻²/∇² based but name both eigenvalues
    eigenvalues = inverse ? S.eigenvalues⁻¹ : S.eigenvalues

    # same approach as for _divergence! to ensure GPU capability and Enzyme compatibility 
    if flipsign
        add ? _∇²!(LaplaceOP{true, true}(), ∇²alms, alms, eigenvalues) :
            _∇²!(LaplaceOP{true, false}(), ∇²alms, alms, eigenvalues)
    else
        add ? _∇²!(LaplaceOP{false, true}(), ∇²alms, alms, eigenvalues) :
            _∇²!(LaplaceOP{false, false}(), ∇²alms, alms, eigenvalues)
    end

    # /radius² or *radius² scaling if not unit sphere
    if radius != 1
        radius = convert(real(eltype(∇²alms)), radius)
        R_plusminus_squared = inverse ? radius^2 : inv(radius^2)
        ∇²alms .*= R_plusminus_squared
    end

    return ∇²alms
end

"""
    LaplaceOP{flipsign, add}

Type for dispatching on the `flipsign`/`add` options of the Laplacian kernel,
like [`KernelOP`](@ref) for divergence/curl.
- `flipsign`: `true` or `false` to negate the result
- `add`: `true` or `false` to add to the output instead of overwriting"""
struct LaplaceOP{flipsign, add} end

# `flipsign` and `add` are type parameters, so the branches below are compile-time constants
@inline function (::LaplaceOP{flipsign, add})(o, val) where {flipsign, add}
    val = flipsign ? -val : val
    return add ? o + val : val
end

@inline function _∇²!(kernel_func::LaplaceOP, ∇²alms, alms, eigenvalues)
    return launch!(
        architecture(∇²alms), SpectralWorkOrder, size(∇²alms), ∇²_kernel!,
        kernel_func, ∇²alms, alms, eigenvalues, alms.spectrum.l_indices,
    )
end

@kernel function ∇²_kernel!(kernel_func::LaplaceOP, ∇²alms, alms, eigenvalues, l_indices)

    I = @index(Global, Cartesian) # I[1] == lm, I[2] == k
    # we use cartesian index instead of NTuple here
    # because this works for 2D and 3D matrices
    l = l_indices[I[1]]

    ∇²alms[I] = kernel_func(∇²alms[I], alms[I] * eigenvalues[l])
end

"""
$(TYPEDSIGNATURES)
Laplace operator ∇² applied to input `alms`, using precomputed eigenvalues from `S`.
Acts on the unit sphere, i.e. it omits 1/radius^2 scaling unless
`radius` keyword argument is provided."""
function ∇²(
        alms::LowerTriangularArray,             # Input: spectral coefficients
        S::AbstractSpectralTransform;           # precomputed eigenvalues
        kwargs...,
    )
    ∇²alms = similar(alms)
    ∇²!(∇²alms, alms, S; add = false, flipsign = false, inverse = false, kwargs...)
    return ∇²alms
end

"""
$(TYPEDSIGNATURES)
Returns the Laplace operator ∇² applied to input `alms`.
Acts on the unit sphere, i.e. it omits 1/radius^2 scaling unless
`radius` keyword argument is provided."""
∇²(alms::LowerTriangularArray; kwargs...) = ∇²(alms, SpectralTransform(alms); kwargs...)

"""
$(TYPEDSIGNATURES)
InverseLaplace operator ∇⁻² applied to input `alms`, using precomputed
eigenvalues from `S`. Acts on the unit sphere, i.e. it omits radius^2 scaling unless
`radius` keyword argument is provided."""
function ∇⁻²(
        ∇²alms::LowerTriangularArray,           # Input: spectral coefficients
        S::AbstractSpectralTransform;           # precomputed eigenvalues
        kwargs...,
    )
    alms = similar(∇²alms)
    ∇⁻²!(alms, ∇²alms, S; add = false, flipsign = false, kwargs...)
    return alms
end

"""
$(TYPEDSIGNATURES)
Returns the inverse Laplace operator ∇⁻² applied to input `alms`.
Acts on the unit sphere, i.e. it omits radius^2 scaling unless
`radius` keyword argument is provided."""
∇⁻²(∇²alms::LowerTriangularArray; kwargs...) = ∇⁻²(∇²alms, SpectralTransform(∇²alms); kwargs...)

"""$(TYPEDSIGNATURES) Calls `∇²!(∇⁻²alms, alms, S; add, flipsign, inverse=true)`."""
function ∇⁻²!(
        ∇⁻²alms::LowerTriangularArray,          # Output: inverse Laplacian of alms
        alms::LowerTriangularArray,             # Input: spectral coefficients
        S::AbstractSpectralTransform;           # precomputed eigenvalues
        add::Bool = false,                      # add to output array or overwrite
        flipsign::Bool = false,                 # -∇⁻² or ∇⁻²
        kwargs...,
    )
    inverse = true
    return ∇²!(∇⁻²alms, alms, S; add, flipsign, inverse, kwargs...)
end

"""$(TYPEDSIGNATURES) Applies the gradient operator ∇ applied to input `p` and stores the result
in `dpdx` (zonal derivative) and `dpdy` (meridional derivative). The gradient operator acts
on the unit sphere and therefore omits the 1/radius scaling unless `radius` keyword argument is provided."""
function ∇!(
        dpdx::LowerTriangularArray,             # Output: zonal gradient
        dpdy::LowerTriangularArray,             # Output: meridional gradient
        p::LowerTriangularArray,                # Input: spectral coefficients
        S::AbstractSpectralTransform{NF};           # includes precomputed arrays
        radius = DEFAULT_RADIUS,                # scale with radius if provided, otherwise unit sphere
    ) where {NF}
    (; grad_y1, grad_y2) = S.gradients
    (; m_indices) = p.spectrum
    @boundscheck ismatching(S, p) || throw(DimensionMismatch(S, p))

    # TODO: there's currently a scalar indexing error when using p direclty instead of p.data, this should be fixed
    @. dpdx = complex(0, m_indices - one(NF)) * p.data

    launch!(architecture(dpdy), SpectralWorkOrder, size(dpdy), dpdy_kernel!, dpdy, p.data, grad_y1, grad_y2)

    # 1/radius factor if not unit sphere
    if radius != 1
        R⁻¹ = inv(convert(real(eltype(dpdx)), radius))
        dpdx .*= R⁻¹
        dpdy .*= R⁻¹
    end

    return dpdx, dpdy
end

@kernel inbounds = true function dpdy_kernel!(dpdy, p, grad_y1, grad_y2)
    I = @index(Global, Cartesian)
    lm = I[1]
    k = ndims(p) == 1 ? CartesianIndex() : I[2]
    lmmax = size(dpdy, 1)

    gy1 = grad_y1[lm]
    gy2 = grad_y2[lm]

    # compared to the old CPU only version, some of the gy1 and gy2 are zero
    # that's why we don't need to check for l==m (diagonal) or l==p.m (last row)
    # branch-free, see the comment above `previous_lm`: no lm-1 term for the first, no lm+1 term
    # for the last element (raised branches become a reduction without reverse rule in Enzyme-MLIR)
    ∂p∂θ1 = gy1 * p[previous_lm(lm, lmmax), k]
    ∂p∂θ1 = ifelse(lm == 1, zero(∂p∂θ1), ∂p∂θ1)
    ∂p∂θ2 = gy2 * p[next_lm(lm, lmmax), k]
    ∂p∂θ2 = ifelse(lm == lmmax, zero(∂p∂θ2), ∂p∂θ2)
    dpdy[lm, k] = ∂p∂θ1 + ∂p∂θ2
end

"""$(TYPEDSIGNATURES) The zonal and meridional gradient of `p`
using an existing `SpectralTransform` `S`. Acts on the unit sphere,
i.e. it omits 1/radius scaling unless `radius` keyword argument is provided."""
function ∇(p::LowerTriangularArray, S::AbstractSpectralTransform; kwargs...)
    dpdx = similar(p)
    dpdy = similar(p)
    ∇!(dpdx, dpdy, p, S; kwargs...)
    return dpdx, dpdy
end

"""$(TYPEDSIGNATURES) The zonal and meridional gradient of `p`.
Precomputes a `SpectralTransform` `S`. Acts on the unit-sphere,
i.e. it omits 1/radius scaling unless `radius` keyword argument is provided."""
function ∇(p::LowerTriangularArray; kwargs...)
    S = SpectralTransform(p, one_more_degree = true)
    return ∇(p, S; kwargs...)
end

"""$(TYPEDSIGNATURES) The zonal and meridional gradient of `grid`.
Transform to spectral space, takes the gradient and unscales the 1/coslat
scaling in the gradient. Acts on the unit-sphere, i.e. it omits 1/radius scaling unless
`radius` keyword argument is provided. Makes use of an existing spectral transform `S`."""
function ∇(field::AbstractField, S::AbstractSpectralTransform; kwargs...)
    p = transform(field, S)
    dpdx, dpdy = ∇(p, S; kwargs...)
    dpdx_grid = transform(dpdx, S, unscale_coslat = true)
    dpdy_grid = transform(dpdy, S, unscale_coslat = true)
    return dpdx_grid, dpdy_grid
end

"""$(TYPEDSIGNATURES) The zonal and meridional gradient of `grid`.
Transform to spectral space, takes the gradient and unscales the 1/coslat
scaling in the gradient. Acts on the unit-sphere, i.e. it omits 1/radius scaling unless
`radius` keyword argument is provided."""
function ∇(field::AbstractField; kwargs...)
    S = SpectralTransform(field, one_more_degree = true)
    return ∇(field, S; kwargs...)
end

# for people that don't have unicode support on their keyboard
laplace = ∇²
laplace! = ∇²!
inverse_laplace = ∇⁻²
inverse_laplace! = ∇⁻²!
gradient = ∇
gradient! = ∇!
