module SpeedyTransformsAMDGPUExt

import AMDGPU: AMDGPU, ROCArray
import AbstractFFTs
using DocStringExtensions

using SpeedyTransforms
using SpeedyTransforms.RingGrids
using SpeedyTransforms.LowerTriangularArrays

import SpeedyTransforms: SpectralTransform, _fourier_batched!, default_gpu_graphs,
    GraphBackend, get_cache, run_graph!, forward_loop!, inverse_loop!, graph_key
import SpeedyTransforms.RingGrids: AbstractField

import SpeedyWeatherInternals.Architectures: GPU

# HIP-graphs stability is so far only confirmed on datacenter/CDNA hardware (LUMI); default off
# on AMDGPU until that's verified more broadly (e.g. the consumer RDNA cards buildkite currently
# runs on) — pass `gpu_graphs = true` explicitly to opt in.
default_gpu_graphs(::AMDGPU.ROCBackend) = false

# trim AMDGPU's memory pool, see `clear_fourier_graph_cache!`
SpeedyTransforms.reclaim!(::GPU{<:AMDGPU.ROCBackend}) = (AMDGPU.reclaim(); nothing)

# =====================================================================================
# HIP GRAPHS ACCELERATION OF THE BATCHED FOURIER TRANSFORM
#
# HIP-graphs equivalent of SpeedyTransformsCUDAExt.jl: captures the fused gather/rocFFT/scatter
# loop of the batched Fourier transform once and replays it with a single `launch`, eliminating
# per-operation CPU launch overhead on the GPU-launch-bound Fourier transform. See
# SpeedyTransformsCUDAExt.jl for the full rationale (packed buffer, single gather/scatter
# kernel per direction, graphs keyed by the field and scratch buffers, etc.) — identical here,
# only the capture/instantiate/launch primitives differ (`AMDGPU.HIP.capture`/`instantiate`/`launch`
# instead of `CUDA.capture`/`instantiate`/`launch`).
#
# The backend-agnostic parts of this (kernels, cache struct, allocation-free loops,
# capture/replay control flow, the `GraphBackend` struct itself) live in
# `SpeedyTransforms/src/gpu_graphs_common.jl` and are compiled unconditionally as part of the
# main package (imported above); only the capture/instantiate/launch primitives below, and the
# `ROCArray`-dispatched methods, are backend-specific and have to live in this extension.
# =====================================================================================

# Probe for the high-level HIP graph API. AMDGPU.HIP exports these in newer versions; on
# older installs only the raw C bindings (hipGraph_t, hipGraphExec_t, …) are present, and
# `_fourier_batched!` falls back to the unaccelerated path with a one-time warning.
const _HIP_GRAPHS_AVAILABLE =
    isdefined(AMDGPU, :HIP) &&
    isdefined(AMDGPU.HIP, :HIPGraphExec) &&
    isdefined(AMDGPU.HIP, :capture)

# The HIP capture/instantiate/launch primitives `run_graph!` needs, plus the architecture used
# to `synchronize` before capture; see `GraphBackend` in gpu_graphs_common.jl. `capture` must
# not throw on an uncapturable region, hence `throw_error = false`. `nothing` on older AMDGPU.jl
# installs where the high-level HIP graph API isn't available at all.
const HIP_GRAPH_BACKEND = if _HIP_GRAPHS_AVAILABLE
    GraphBackend(
        loop! -> AMDGPU.HIP.capture(loop!; throw_error = false),
        AMDGPU.HIP.instantiate,
        AMDGPU.HIP.launch,
        GPU(AMDGPU.ROCBackend()),
    )
else
    nothing
end

const GPU_GRAPHS_WARNED = Ref(false)

function warn_gpu_graphs_unavailable()
    if !GPU_GRAPHS_WARNED[]
        @warn "GPU-graphs acceleration of the Fourier transform (`gpu_graphs = true`) requires a newer AMDGPU.jl exposing the high-level HIP graph API (`AMDGPU.HIP.capture`/`instantiate`/`HIPGraphExec`); falling back to the unaccelerated path. Set `gpu_graphs = false` to silence this warning."
        GPU_GRAPHS_WARNED[] = true
    end
    return nothing
end

# =====================================================================================
# Method extension: dispatch on ROCArray scratch (more specific than the generic
# AbstractArray{<:Complex,3} methods in fourier.jl)
# =====================================================================================

"""$(TYPEDSIGNATURES)
HIP-Graphs accelerated forward (grid → spectral) batched Fourier transform.
Replays a cached HIP graph of the fused gather + per-ring rocFFTs + scatter; see
[`run_graph!`](@ref)."""
function _fourier_batched!(
        f_north::ROCArray{<:Complex, 3},
        f_south::ROCArray{<:Complex, 3},
        field::AbstractField,
        S::SpectralTransform,
    )
    @assert eltype(field) == eltype(S) "Number format of grid $(eltype(field)) and SpectralTransform $(eltype(S)) need to match."
    if !S.gpu_graphs || !_HIP_GRAPHS_AVAILABLE
        !_HIP_GRAPHS_AVAILABLE && warn_gpu_graphs_unavailable()
        return Base.@invoke _fourier_batched!(
            f_north::AbstractArray{<:Complex, 3}, f_south::AbstractArray{<:Complex, 3},
            field::AbstractField, S::SpectralTransform,
        )
    end
    # the cache is selected by (and sized for) this transform size (= its FFT plan set); within
    # it what varies between calls are the caller's buffers, field and scratch, so they are the graph key
    cache = get_cache(AMDGPU.HIP.HIPGraphExec, S, size(field, 2))
    run_graph!(cache.forward_execs, graph_key(field, f_north, f_south), () -> forward_loop!(cache, f_north, f_south, field, S), HIP_GRAPH_BACKEND)
    return nothing
end

"""$(TYPEDSIGNATURES)
HIP-Graphs accelerated inverse (spectral → grid) batched Fourier transform.
Replays a cached HIP graph of the fused gather + per-ring inverse rocFFTs + scatter; see
[`run_graph!`](@ref)."""
function _fourier_batched!(
        field::AbstractField,
        g_north::ROCArray{<:Complex, 3},
        g_south::ROCArray{<:Complex, 3},
        S::SpectralTransform;
        add::Bool = false,          # accumulate onto `field` instead of overwriting? (Enzyme adjoint rule)
    )
    if !S.gpu_graphs || !_HIP_GRAPHS_AVAILABLE
        !_HIP_GRAPHS_AVAILABLE && warn_gpu_graphs_unavailable()
        return Base.@invoke _fourier_batched!(
            field::AbstractField, g_north::AbstractArray{<:Complex, 3},
            g_south::AbstractArray{<:Complex, 3}, S::SpectralTransform; add,
        )
    end
    cache = get_cache(AMDGPU.HIP.HIPGraphExec, S, size(field, 2))
    # `add` is part of the graph key: a captured graph bakes in overwrite-vs-accumulate, so replaying
    # the wrong one would silently produce incorrect results.
    run_graph!(cache.inverse_execs, (graph_key(field, g_north, g_south), add), () -> inverse_loop!(cache, field, g_north, g_south, S, add), HIP_GRAPH_BACKEND)
    return nothing
end

end
