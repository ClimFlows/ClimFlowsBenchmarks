using JLArrays
import Random
import SpeedyWeatherInternals.Architectures: architecture, on_architecture

@testset "LowerTriangularMatrix" begin
    @testset for NF in (Float32, Float64)
        mmax = 32
        @testset for lmax in (mmax, mmax + 1)
            A = randn(Complex{NF}, lmax, mmax)

            LowerTriangularArrays.truncate!(A)

            L = LowerTriangularMatrix(A)

            @test size(L, as = Matrix) == size(A)

            @test size(A) == size(L, as = Matrix)
            @test size(L.data) == size(L, as = Vector)

            for m in 1:mmax
                for l in 1:lmax
                    @test A[l, m] == L[l, m]
                end
            end

            @test_throws BoundsError L[lmax + 1, mmax]
            @test_throws BoundsError L[lmax, mmax + 1]

            @test_throws BoundsError L[1, 2] = 1
            @test_throws BoundsError L[lmax * mmax + 1] = 1

            @test Matrix(L) == A

            @test all(L[:, 1] .== A[:, 1])
            @test all(L[:, 2] .== A[:, 2])
            @test all(L[1, :] .== A[1, :])
            @test all(L[2, :] .== A[2, :])
        end
    end
end

@testset "LowerTriangularArray: N-dim" begin
    @testset for NF in (Float32, Float64)
        mmax = 32
        @testset for idims in ((), (5,), (5, 5))
            @testset for lmax in (mmax, mmax + 1)
                A = randn(Complex{NF}, lmax, mmax, idims...)

                # replaces spectraltrunction! here, we just set the elements zero manually
                ind = LowerTriangularArrays.lowertriangle_indices(A)
                ind = @. ~(ind)
                A[ind] .= zero(Complex{NF})

                L = LowerTriangularArray(A)

                @test size(L, as = Matrix) == size(A)
                @test size(L.data) == size(L, as = Vector)
                @test size(L)[2:end] == size(A)[3:end]
                @test size(L)[1] == LowerTriangularArrays.nonzeros(size(A, 1), size(A, 2))

                # with integer to request length of one specific dimension
                @test size(L)[1] == size(L, 1)
                @test size(L)[1] == size(L, 1, as = Vector)
                @test size(L)[1] == size(L, 1, OneBased, as = Vector)

                @test size(L, 1, as = Matrix) == lmax
                @test size(L, 2, as = Matrix) == mmax
                @test size(L, 1, ZeroBased, as = Matrix) == lmax - 1
                @test size(L, 2, ZeroBased, as = Matrix) == mmax - 1

                # all additional dimensions are or size 1, as defined for Array too
                @test size(L, 2 + length(idims)) == 1
                @test size(L, 3 + length(idims)) == 1
                @test size(L, 4 + length(idims)) == 1
                @test size(L, 5 + length(idims)) == 1

                @test size(L, 3 + length(idims), as = Matrix) == 1
                @test size(L, 4 + length(idims), as = Matrix) == 1
                @test size(L, 5 + length(idims), as = Matrix) == 1

                for m in 1:mmax
                    for l in 1:lmax
                        @test A[l, m, [Colon() for i in 1:length(idims)]...] == L[l, m, [Colon() for i in 1:length(idims)]...]
                    end
                end

                @test_throws BoundsError L[lmax + 1, mmax, [1 for i in 1:length(idims)]...]
                @test_throws BoundsError L[lmax, mmax + 1, [1 for i in 1:length(idims)]...]

                @test_throws BoundsError L[1, 2, [1 for i in 1:length(idims)]...] = 1
                @test_throws BoundsError L[lmax * mmax + 1, [1 for i in 1:length(idims)]...] = 1

                @test Array(L) == A

                if length(idims) == 1
                    L1 = L[:, 1]
                    @test typeof(L1) <: LowerTriangularArray
                    @test all(L1.data .== L.data[:, 1])
                    @test all([L1[i] == L[i, 1] for i in 1:size(L.data, 1)])
                end
            end
        end
    end
end

@testset "OneBased vs ZeroBased" begin

    L = zeros(LowerTriangularMatrix, 5, 5)

    @test size(L) == size(L, as = Vector)
    @test size(L, as = Matrix) == (5, 5)
    @test size(L, 1) == 15
    @test size(L, 1, as = Matrix) == 5
    @test size(L, 2, as = Matrix) == 5
    @test size(L, 1, ZeroBased, as = Matrix) == 4
    @test size(L, 2, ZeroBased, as = Matrix) == 4
    @test size(L, OneBased, as = Matrix) == (5, 5)
    @test_throws MethodError size(L, ZeroBased)
    @test_throws MethodError size(L, ZeroBased, as = Vector)

    L = zeros(LowerTriangularArray, 5, 5, 2)
    m, n = size(L, as = Matrix)
    @test (m, n) == (5, 5)

    lmax, mmax = size(L, ZeroBased, as = Matrix)
    @test (lmax, mmax) == (4, 4)
end

@testset "LowerTriangularMatrix: @inbounds" begin
    m, n = 5, 5
    A = randn(LowerTriangularMatrix, m, n)

    # @testset "getindex" begin
    @test_throws BoundsError A[m, n + 1]  # outside of i, j range
    @test_throws BoundsError A[m + 1, n]  # outside of i, j range

    mn = LowerTriangularArrays.nonzeros(m, n)
    @test_throws BoundsError A[mn + 1]    # outside of k range

    # with @inbounds accessing [1,2] should return [5]
    # because the j > 1 is skipped and lm2i(1, 2, 5) = 5
    # which isn't correct but would never be called without @inbounds
    f(A, i) = @inbounds A[i]             # wrap into function
    f(A, i, j) = @inbounds A[i, j]

    @test f(A, 1) == A[1]       # valid
    @test f(A, 2, 1) == A[2]    # valid
    # @test f(A, 1, 2) == A[m]    # invalid

    @test f(A, CartesianIndex(2, 1)) == A[2, 1]
    # @test f(A, CartesianIndex(1, 2)) == A[n, 1] # invalid, disable for CI (*)
    # end

    # @testset "setindex!" begin
    @test_throws BoundsError A[m + 1, n] = 1  # invalid
    @test_throws BoundsError A[m, n + 1] = 1  # invalid
    @test_throws BoundsError A[1, 2] = 1    # upper triangle

    mn = LowerTriangularArrays.nonzeros(m, n)
    @test_throws BoundsError A[mn + 1] = 1

    # with @inbounds accessing [1,2] should return [5]
    # because the j > 1 is skipped and lm2i(1, 2, 5) = 5
    # which isn't correct but would never be called without @inbounds
    g!(A, i) = @inbounds A[i] = 1               # wrap into function
    g!(A, i, j) = @inbounds A[i, j] = 1

    g!(A, 1)                                    # valid
    @test f(A, 1) == A[1] == 1

    g!(A, 2, 1)                                 # valid
    @test f(A, 2, 1) == A[2] == A[2, 1] == 1

    # g!(A, 1, 2)                                 # invalid, disable for CI (*)
    # @test f(A, 1, 2) == A[n] == A[n,1] == 1
    # end

    # (*) github actions CI is by default set to _always_ checkbounds
    # regardless @inboounds annotations, so these tests were performed manually (and pass)
    # but are disabled to make github actions CI pass
end

@testset "LowerTriangularArray: @inbounds" begin
    m, n, p = 5, 5, 5
    A = randn(LowerTriangularArray, m, n, p)

    # @testset "getindex" begin
    @test_throws BoundsError A[m, n + 1, p + 1]  # outside or range
    @test_throws BoundsError A[m, n + 1, p]  # outside or range
    @test_throws BoundsError A[m + 1, n, p]  # outside or range

    mnp = LowerTriangularArrays.nonzeros(m, n) * p
    @test_throws BoundsError A[mnp + 1]       # outside of k range

    # with @inbounds accessing [1,2] should return [5]
    # because the j > 1 boundscheck is skipped and lm2i(1, 2, 5) = 5
    # which isn't correct but would never be called without @inbounds
    f(A, i) = @inbounds A[i]            # wrap into function
    f(A, i, j) = @inbounds A[i, j]
    f(A, i, j, k) = @inbounds A[i, j, k]

    @test f(A, 1) == A[1]               # valid
    @test f(A, 2, 1) == A[2]            # valid
    # @test f(A, 1, 2, 3) == A[m, 1, 3]   # invalid, disable for CI (*)
    @test f(A, 1, 1, 1) == A[1, 1, 1]   # valid

    @test f(A, CartesianIndex(3)) == A[3]
    @test f(A, CartesianIndex(2, 1)) == A[2, 1]
    @test f(A, CartesianIndex(2, 1, 1)) == A[2, 1]
    # @test f(A, CartesianIndex(1, 2, 1)) == A[n, 1]  # invalid, disable for CI (*)
    # end

    # @testset "setindex!" begin
    @test_throws BoundsError A[m + 1, n, p] = 1  # invalid
    @test_throws BoundsError A[m, n + 1, p] = 1  # invalid
    @test_throws BoundsError A[m, n + 1, p + 1] = 1  # invalid
    @test_throws BoundsError A[1, 2, 1] = 1  # upper triangle

    mnp = LowerTriangularArrays.nonzeros(m, n) * p
    @test_throws BoundsError A[mnp + 1] = 1

    # with @inbounds accessing [1,2] should return [5]
    # because the j > 1 is skipped and lm2i(1, 2, 5) = 5
    # which isn't correct but would never be called without @inbounds
    g!(A, i) = @inbounds A[i] = 1               # wrap into function
    g!(A, i, j) = @inbounds A[i, j] = 1
    g!(A, i, j, k) = @inbounds A[i, j, k] = 1

    g!(A, 1)                                    # valid
    @test f(A, 1) == A[1] == 1

    g!(A, 2, 1)                                 # valid
    @test f(A, 2, 1) == A[2] == A[2, 1] == 1

    g!(A, 1, 2)                                 # valid
    @test f(A, 1, 2) == A[1, 2] == 1

    # g!(A, 1, 2, 1)                              # invalid, disable for CI (*)
    # @test f(A, 1, 2, 1) == A[n] == A[n, 1] == A[n, 1, 1] == 1
    # end
end

@testset "4D LowerTriangularArray: @inbounds" begin
    A = randn(LowerTriangularArray, 33, 32, 1, 1)

    @testset "getindex" begin
        @test_throws BoundsError A[34, 32, 1, 1]    # outside of i, j range
        @test_throws BoundsError A[561, 1, 1]       # outside of k range
        @test_throws BoundsError A[33, 32, 2, 1]    # outside of 3rd dim range
        @test_throws BoundsError A[33, 32, 1, 2]    # outside of 4th dim range
    end

    @testset "setindex!" begin
        @test_throws BoundsError A[34, 32, 1, 1] = 1
        @test_throws BoundsError A[561, 1, 1] = 1
        @test_throws BoundsError A[33, 32, 2, 1] = 1
        @test_throws BoundsError A[33, 32, 1, 2] = 1
    end
end

@testset "Zeros, ones, rand, and randn constructors" begin
    for f in (ones, zeros, rand, randn)
        s = (5, 5)
        spectrum = Spectrum(s...)
        jl_arch = architecture(JLArray)
        spectrum_jlarray = Spectrum(spectrum, architecture = jl_arch)

        # for 2D doesn't matter whether you say Matrix or Array, size is determined by s
        L = f(LowerTriangularMatrix, s...)
        L2 = f(LowerTriangularArray, s...)
        @test typeof(L) == typeof(L2)
        @test size(L) == size(L2)

        L = f(LowerTriangularMatrix, spectrum)
        L2 = f(LowerTriangularArray, spectrum)
        @test typeof(L) == typeof(L2)
        @test size(L) == size(L2)

        L = f(LowerTriangularMatrix{Float16}, s...)
        L2 = f(LowerTriangularArray{Float16}, s...)
        @test typeof(L) == typeof(L2)
        @test size(L) == size(L2)

        L = f(LowerTriangularMatrix{Float16}, spectrum)
        L2 = f(LowerTriangularArray{Float16}, spectrum)
        L3 = f(Float16, spectrum)
        @test typeof(L) == typeof(L2) == typeof(L3)
        @test size(L) == size(L2) == size(L3)

        JL = on_architecture(jl_arch, L)
        JL2 = on_architecture(jl_arch, L2)
        @test typeof(JL) == typeof(JL2) == typeof(zero(JL))
        @test size(JL) == size(JL2) == size(zero(JL))

        L = f(LowerTriangularMatrix{Float16}, s...)
        L2 = f(LowerTriangularArray{Float16, 1, Vector{Float16}, typeof(spectrum)}, s...)
        JL = f(LowerTriangularArray{Float16, 1, JLArray{Float16, 1}, typeof(spectrum_jlarray)}, s...)
        @test typeof(L) == typeof(L2)
        @test size(L) == size(L2)
        @test typeof(L) != typeof(JL)
        @test size(L) == size(L2)

        L = f(LowerTriangularMatrix{Float16}, spectrum)
        L2 = f(LowerTriangularArray{Float16, 1, Vector{Float16}, typeof(spectrum)}, spectrum)
        JL = f(LowerTriangularArray{Float16, 1, JLArray{Float16, 1}, typeof(spectrum_jlarray)}, spectrum_jlarray)
        @test typeof(L) == typeof(L2)
        @test size(L) == size(L2)
        @test typeof(L) != typeof(JL)
        @test size(L) == size(L2)

        # higher dims
        for s in ((2, 3, 4), (2, 3, 4, 5))
            N = length(s)
            Random.seed!(123)
            L = f(LowerTriangularArray{Float16, N - 1, Array{Float16, N - 1}, typeof(spectrum)}, s...)
            Random.seed!(123)
            JL = f(LowerTriangularArray{Float16, N - 1, JLArray{Float16, N - 1}, typeof(spectrum_jlarray)}, s...)
            JL2 = on_architecture(jl_arch, L)
            @test all(JL2 .== JL)   # equality via broadcasting
            @test JL2 == JL         # checks for type and data equality

            Random.seed!(123)
            L2 = f(LowerTriangularArray{Float16}, s...)

            @test L == L2
        end

        # higher dims - spectrum
        for s in ((2,), (2, 3))
            N = length(s)
            Random.seed!(123)
            L = f(LowerTriangularArray{Float16, N + 1, Array{Float16, N + 1}, typeof(spectrum)}, spectrum, s...)
            Random.seed!(123)
            JL = f(LowerTriangularArray{Float16, N + 1, JLArray{Float16, N + 1}, typeof(spectrum_jlarray)}, spectrum_jlarray, s...)
            JL2 = on_architecture(jl_arch, L)
            @test all(JL2 .== JL)   # equality via broadcasting
            @test JL2 == JL         # checks for type and data equality

            Random.seed!(123)
            L2 = f(LowerTriangularArray{Float16}, spectrum, s...)

            @test L == L2

            Random.seed!(123)
            L3 = f(Float16, spectrum, s...)
            @test L == L3
        end
    end
end

@testset "rand, randn constructors with rng" begin
    for f in (rand, randn)
        s = (5, 5)
        spectrum = Spectrum(s...)

        # same seed = same coefficients, reproducibility
        @test f(Random.Xoshiro(123), spectrum) == f(Random.Xoshiro(123), spectrum)
        @test f(Random.Xoshiro(123), spectrum, 2) == f(Random.Xoshiro(123), spectrum, 2)

        # rng doesn't change type or size compared to no rng
        for NF in (Float32, Float64)
            L1 = f(Random.Xoshiro(123), NF, spectrum, 2)
            L2 = f(NF, spectrum, 2)
            @test typeof(L1) == typeof(L2)
            @test size(L1) == size(L2)

            L1 = f(Random.Xoshiro(123), LowerTriangularArray{NF}, s...)
            L2 = f(LowerTriangularArray{NF}, s...)
            @test typeof(L1) == typeof(L2)
            @test size(L1) == size(L2)

            L1 = f(Random.Xoshiro(123), LowerTriangularMatrix{NF}, s...)
            L2 = f(LowerTriangularMatrix{NF}, s...)
            @test typeof(L1) == typeof(L2)
            @test size(L1) == size(L2)
        end
    end
end

@testset "LowerTriangularArray: fill, copy, randn, convert, repeat" begin
    @testset for NF in (Float32, Float64)
        mmax = 32
        @testset for idims in ((), (5,), (5, 5))
            @testset for lmax in (mmax, mmax + 1)
                spectrum = Spectrum(lmax, mmax)
                A = randn(Complex{NF}, lmax, mmax, idims...)

                # replaces spectraltrunction! here, we just set the elements zero manually
                ind = LowerTriangularArrays.lowertriangle_indices(A)
                ind = @. ~(ind)
                A[ind] .= zero(Complex{NF})

                L = LowerTriangularArray(A)
                # fill
                fill!(L, 2)
                for (lm, (l, m)) in enumerate(LowerTriangularArrays.eachharmonic(L))
                    @test all(L[lm, [Colon() for i in 1:length(idims)]...] .== 2)
                end

                # copy
                L2 = copy(L)
                @test L2 == L

                L2[1, [1 for i in 1:length(idims)]...] = 3
                @test L[1, [1 for i in 1:length(idims)]...] == 2     # should be a deep copy
                @test L2[1, [1 for i in 1:length(idims)]...] == 3

                # convert
                L = randn(LowerTriangularArray{NF}, lmax, mmax, idims...)
                L3 = convert(LowerTriangularArray{Float16, 1 + length(idims), Array{Float16, 1 + length(idims)}, typeof(spectrum)}, L)
                for (lm, (l, m)) in enumerate(LowerTriangularArrays.eachharmonic(L, L3))
                    @test Float16(L[lm, [1 for i in 1:length(idims)]...]) == L3[lm, [1 for i in 1:length(idims)]...]
                end

                L_rep = repeat(L, 1, [2 for i in 1:length(idims)]...)
                @test typeof(L_rep) <: LowerTriangularArray
                @test size(L_rep, as = Vector) == (size(L, 1), [10 for i in 1:length(idims)]...) # 10 = 2 * 5 = 2*idims[i]

                Lu = Base.unaliascopy(L)
                @test Lu == L && Lu.data !== L.data
            end
        end
    end
end

@testset "convert(LowerTriangularMatrix{T}, L) skips no-op cast" begin
    # Regression: under Reactant, `T.(L.data)` with `eltype(L.data) === T` traces as a
    # self-recursive `copy(::Broadcasted)` that blows the Julia stack. Same-eltype convert
    # must pass `L.data` through identity-ically.
    spectrum = Spectrum(8, 8)
    L = randn(LowerTriangularMatrix{ComplexF32}, spectrum)

    L_same = convert(LowerTriangularMatrix{ComplexF32}, L)
    @test L_same.data === L.data   # identity, no broadcast/copy

    L_cast = convert(LowerTriangularMatrix{ComplexF64}, L)
    @test eltype(L_cast) === ComplexF64
    @test L_cast.data !== L.data
end

@testset "LowerTriangularMatrix: fill, copy, randn, convert" begin
    @testset for NF in (Float32, Float64)
        mmax = 32
        @testset for lmax in (mmax, mmax + 1)
            A = randn(Complex{NF}, lmax, mmax)
            LowerTriangularArrays.truncate!(A)
            L = LowerTriangularMatrix(A)

            # fill
            fill!(L, 2)
            for lm in LowerTriangularArrays.eachindex(L)
                @test L[lm] == 2
            end

            # copy
            L2 = deepcopy(L)
            @test L2 == L

            L2[1] = 3
            @test L[1] == 2     # should be a deep copy
            @test L2[1] == 3

            # convert
            L = randn(LowerTriangularMatrix{NF}, lmax, mmax)
            L3 = convert(LowerTriangularMatrix{Float16}, L)
            for lm in LowerTriangularArrays.eachindex(L, L3)
                @test Float16(L[lm]) == L3[lm]
            end
        end
    end
end

@testset "LowerTriangularMatrix: *, +, eachindex, similar" begin
    @testset for NF in (Float16, Float32, Float64)
        L = randn(LowerTriangularMatrix{NF}, 3, 3)

        @test (L + L) == 2L
        @test (L + L) == L * 2
        @test (L - L) == zero(L)

        @test L + L isa LowerTriangularMatrix
        @test 2L isa LowerTriangularMatrix

        @test eachindex(L) == eachindex(L.data)
        @test eachindex(L, L) == eachindex(L.data, L.data)

        @test size(similar(L)) == size(L)
        @test eltype(L) == eltype(similar(L, eltype(L)))

        @test (5, 5) == size(similar(L, 5, 5), as = Matrix)
        @test (5, 5) == size(similar(L, (5, 5)), as = Matrix)

        @test similar(L) isa LowerTriangularMatrix
        @test similar(L, Float64) isa LowerTriangularMatrix{Float64}

        # spectrum should be the same
        @test similar(L).spectrum === L.spectrum
    end
end

@testset "LowerTriangularArray: *, +, eachindex, similar" begin
    @testset for idims in ((), (5,), (5, 5))
        @testset for NF in (Float16, Float32, Float64)
            L = randn(LowerTriangularArray{NF}, 3, 3, idims...)

            @test (L + L) == 2L
            @test (L + L) == L * 2
            @test (L - L) == zero(L)

            @test L + L isa LowerTriangularArray
            @test 2L isa LowerTriangularArray

            @test eachindex(L) == eachindex(L.data)
            @test eachindex(L, L) == eachindex(L.data, L.data)

            @test size(similar(L)) == size(L)
            @test eltype(L) == eltype(similar(L, eltype(L)))

            @test (5, 5, idims...) == size(similar(L, 5, 5, idims...), as = Matrix)
            @test (5, 5, idims...) == size(similar(L, (5, 5, idims...)), as = Matrix)

            @test similar(L) isa LowerTriangularArray
            @test similar(L, Float64) isa LowerTriangularArray{Float64}

            @test similar(L).spectrum === L.spectrum
        end
    end
end

@testset "sum" begin
    @testset for idims in ((5,), (5, 5))
        L = randn(LowerTriangularArray{Float32}, 3, 3, idims...)

        @test sum(L, dims = 1) == sum(L.data, dims = 1)
        @test sum(L, dims = 2) == sum(L.data, dims = 2)
    end
end

@testset "LowerTriangularMatrix: copyto!" begin
    @testset for NF in (Float16, Float32, Float64)
        L1 = randn(LowerTriangularMatrix{NF}, 10, 10)
        L2 = randn(LowerTriangularMatrix{NF}, 5, 5)
        L1c = deepcopy(L1)

        copyto!(L2, L1)  # bigger into smaller
        copyto!(L1, L2)  # and back should be identical

        @test L1 == L1c

        # now smaller into bigger
        L1 = randn(LowerTriangularMatrix{NF}, 10, 10)
        L2 = randn(LowerTriangularMatrix{NF}, 5, 5)
        L2c = deepcopy(L2)

        copyto!(L1, L2)
        copyto!(L2, L1)

        @test L2 == L2c

        # with ranges
        L1 = zeros(LowerTriangularMatrix{NF}, 33, 32)
        L2 = randn(LowerTriangularMatrix{NF}, 65, 64)
        L2T = LowerTriangularArrays.truncate(L2, size(L1, OneBased, as = Matrix)...)

        copyto!(L1, L2, 1:33, 1:32)     # size of smaller matrix
        @test L1 == L2T

        copyto!(L1, L2, 1:65, 1:64)     # size of bigger matrix
        @test L1 == L2T

        copyto!(L1, L2, 1:50, 1:50)     # in between
        @test L1 == L2T
    end
end

@testset "LowerTriangularArray: copyto!" begin
    @testset for idims in ((), (5,), (5, 5))
        @testset for NF in (Float16, Float32, Float64)

            # copyto! same size
            L1 = randn(LowerTriangularArray{NF}, 10, 10, idims...)
            L2 = similar(L1)
            copyto!(L2, L1)

            @test L2 == L1

            # copyto! Vector
            L1 = randn(LowerTriangularArray{NF}, 10, 10, idims...)
            V = randn(size(L1, as = Vector)...)
            copyto!(L1, V)

            @test L1.data == NF.(V)

            # copyto! Array
            M = zeros(NF, 10, 10, idims...)
            copyto!(M, L1)

            ind = LowerTriangularArrays.lowertriangle_indices(M)
            not_ind = @. ~(ind)

            @test all(M[not_ind] .== zero(NF))
            @test LowerTriangularArray(M) == L1

            L1 = randn(LowerTriangularArray{NF}, 10, 10, idims...)
            L2 = randn(LowerTriangularArray{NF}, 5, 5, idims...)
            L1c = deepcopy(L1)

            copyto!(L2, L1)  # bigger into smaller
            copyto!(L1, L2)  # and back should be identical

            @test L1 == L1c

            # now smaller into bigger
            L1 = randn(LowerTriangularArray{NF}, 10, 10, idims...)
            L2 = randn(LowerTriangularArray{NF}, 5, 5, idims...)
            L2c = deepcopy(L2)

            copyto!(L1, L2)
            copyto!(L2, L1)

            @test L2 == L2c

            # with ranges
            L1 = zeros(LowerTriangularArray{NF}, 33, 32, idims...)
            L2 = randn(LowerTriangularArray{NF}, 65, 64, idims...)
            L2T = LowerTriangularArrays.truncate(L2, (size(L1, OneBased, as = Matrix)[1:2])...)

            copyto!(L1, L2, 1:33, 1:32)     # size of smaller matrix
            @test L1 == L2T

            copyto!(L1, L2, 1:65, 1:64)     # size of bigger matrix
            @test L1 == L2T

            copyto!(L1, L2, 1:50, 1:50)     # in between
            @test L1 == L2T
        end
    end
end

@testset "Simple broadcast" begin
    @testset for NF in (Float16, Float32, Float64)
        L1 = randn(LowerTriangularMatrix{NF}, 10, 10)
        L2 = deepcopy(L1)

        L2 .*= NF(5)
        @test L1 .* NF(5) ≈ L2

        L1 = randn(LowerTriangularMatrix{NF}, 10, 10)
        L2 = deepcopy(L1)

        L2 ./= NF(5)
        @test L1 ./ NF(5) ≈ L2

        L1 = randn(LowerTriangularMatrix{NF}, 10, 10)
        L2 = deepcopy(L1)

        L2 .^= NF(2)
        @test L1 .^ NF(2) ≈ L2
    end
end

@testset "Mixed-rank broadcast" begin
    # broadcasting a single field (rank-1 LowerTriangularMatrix) against a layered
    # array (rank-2 LowerTriangularArray) must promote to the higher rank and give
    # the same result regardless of argument order. A non-commutative BroadcastStyle
    # rule previously raised "conflicting broadcast rules defined" here.
    @testset for NF in (Float32, Float64)
        @testset for nlayers in (1, 3)
            L_array = randn(LowerTriangularArray{NF}, 10, 10, nlayers)  # (lm, nlayers)
            L_matrix = randn(LowerTriangularMatrix{NF}, 10, 10)         # (lm,)

            R1 = L_array .- L_matrix
            R2 = L_matrix .- L_array

            # result promotes to the higher (rank-2) container, both orderings
            @test R1 isa LowerTriangularArray{NF, 2}
            @test R2 isa LowerTriangularArray{NF, 2}
            @test size(R1) == size(L_array)
            @test size(R2) == size(L_array)

            # values match plain-array broadcasting, including layer by layer
            @test R1.data ≈ L_array.data .- L_matrix.data
            @test R2.data ≈ L_matrix.data .- L_array.data
            for k in 1:nlayers
                @test R1.data[:, k] ≈ L_array.data[:, k] .- L_matrix.data
            end

            # in-place accumulation as used in surface_pressure_spectral_tendency!
            dest = deepcopy(L_array)
            @. dest = -dest - L_matrix
            @test dest.data ≈ -L_array.data .- L_matrix.data
        end
    end
end

@testset "GPU (JLArrays)" begin
    NF = Float32
    idims = (5,)
    spectrum = Spectrum(10, 10)
    jl_arch = architecture(JLArray)
    spectrum_jlarray = Spectrum(spectrum, architecture = jl_arch)

    L_cpu = randn(LowerTriangularArray{NF}, spectrum, idims...)

    # constructors/adapt
    L = on_architecture(jl_arch, L_cpu)
    L2 = LowerTriangularArray(on_architecture(jl_arch, L_cpu.data), spectrum_jlarray)
    @test all(L .== L2)

    # getindex
    @test typeof(L[1, :]) <: JLArray
    for lm in eachindex(L.spectrum)
        @test Array(L[lm, :]) == L_cpu[lm, :]
    end

    # setindex!
    A_test = JLArray(rand(NF, size(L_cpu, 2)))
    L[1, :] = A_test
    @test L[1, :] == A_test

    # fill
    fill!(L, 2)
    for lm in eachindex(L2.spectrum)
        @test all(L[lm, [Colon() for i in 1:length(idims)]...] .== 2)
    end

    # copy
    L2 = deepcopy(L)
    @test all(L2 .== L)

    rand_array = JLArray(rand(NF, 5))
    L2[1, :] = rand_array
    @test all(L[1, :] .== 2)     # should be a deep copy
    @test all(L2[1, :] .== rand_array)

    # rand + convert
    L3 = on_architecture(jl_arch, randn(LowerTriangularArray{NF}, spectrum, idims...))
    L4 = convert(LowerTriangularArray{Float16, 2, JLArray{Float16, 2}, typeof(spectrum_jlarray)}, L3)

    # for (lm, (l, m)) in enumerate(LowerTriangularArrays.eachharmonic(L, L3))
    for lm in eachindex(L3.spectrum)
        @test all(Float16.(L3[lm, :]) .== L4[lm, :])
    end

    # *
    @test all((L + L) .== L * 2)
    @test all((L - L) .== zero(L))

    # similar
    @test size(similar(L)) == size(L)
    @test eltype(L) == eltype(similar(L, eltype(L)))

    @test (5, 5, idims...) == size(similar(L, 5, 5, idims...), as = Matrix)
    @test (5, 5, idims...) == size(similar(L, (5, 5, idims...)), as = Matrix)

    @test similar(L) isa LowerTriangularArray

    # copyto! same size
    L1 = randn(LowerTriangularArray{NF}, 10, 10, idims...)
    L1 = on_architecture(jl_arch, L1)
    L2 = similar(L1)
    copyto!(L2, L1)

    @test all(L2 .== L1)

    # test the truncating copyto! function

    L1 = on_architecture(jl_arch, zeros(LowerTriangularArray{NF}, 33, 32, idims...))
    L2 = on_architecture(jl_arch, randn(LowerTriangularArray{NF}, 65, 64, idims...))

    L2T = LowerTriangularArrays.truncate(L2, (size(L1, OneBased; as = Matrix)[1:2])...)
    L3 = on_architecture(jl_arch, zeros(LowerTriangularArray{NF}, 33, 32, idims...))

    copyto!(L1, L2, 1:33, 1:32)     # size of smaller matrix
    @test L1 == L2T

    copyto!(L3, L2, 1:33, 1:32)     # size of smaller matrix
    @test L1 == L3

    copyto!(L3, L2, 1:65, 1:64)     # size of bigger matrix
    @test L1 == L3

    copyto!(L1, L2, 1:50, 1:50)     # in between
    @test L1 == L2T

    copyto!(L3, L2, 1:50, 1:50)     # in between
    @test L3 == L1
end

@testset "Different architecture broadcast" begin
    @testset for idims in ((), (2,), (2, 2))
        @testset for NF in (Float32, Float64)
            @testset for ArrayType in (Array, JLArray)

                arch = architecture(ArrayType)
                L1 = on_architecture(arch, randn(LowerTriangularArray{NF}, 10, 10, idims...))
                L2 = deepcopy(L1)

                L2 .*= 5
                @test 5L1 == L2

                L1 = on_architecture(arch, randn(LowerTriangularArray{NF}, 10, 10, idims...))
                L2 = deepcopy(L1)

                L2 ./= 5
                @test (L1.data ./ 5) == L2.data

                L1 = on_architecture(arch, randn(LowerTriangularArray{NF}, 10, 10, idims...))
                L2 = deepcopy(L1)

                L2 .^= 2
                @test L1.data .^ 2 == L2.data

                # tests mirroring usage in dynamical core
                L1 = on_architecture(arch, randn(LowerTriangularArray{NF}, 10, 10, idims...))
                L2 = on_architecture(arch, randn(LowerTriangularArray{NF}, 10, 10, idims...))
                L3 = deepcopy(L2)

                @. L2 += 5L1
                @test L2.data == L3.data .+ 5L1.data

                L1 = on_architecture(arch, randn(LowerTriangularArray{NF}, 10, 10, idims...))
                L2 = on_architecture(arch, randn(LowerTriangularArray{NF}, 10, 10, idims...))

                @. L3 = -L1 - L2
                @test L3.data == -L1.data - L2.data

                L1 = on_architecture(arch, randn(LowerTriangularArray{NF}, 10, 10, idims...))
                L2 = on_architecture(arch, randn(LowerTriangularArray{NF}, 10, 10, idims...))
                L3 = deepcopy(L2)

                L2 .+= L1
                L3.data .+= L1.data
                @test L2.data == L3.data

                L1 = on_architecture(arch, randn(LowerTriangularArray{NF}, 10, 10, idims...))
                L2 = similar(L1)

                L2 .= 5L1
                @test L2 == 5L1

                # spectrum should be the same
                @test L2.spectrum === L1.spectrum
                @test (L1 .+ L2).spectrum === L1.spectrum
            end
        end
    end
end

@testset "Rotate" begin
    @testset for NF in (Float16, Float32, Float64)
        @testset for truncation in (5, 10, 15)
            @testset for k in 0:3
                if k == 0
                    L = rand(LowerTriangularArray{Complex{NF}}, truncation, truncation)
                else
                    L = rand(LowerTriangularArray{Complex{NF}}, truncation, truncation, k)
                end

                L2 = deepcopy(L)
                L3 = deepcopy(L)
                @test rotate!(L2, 0) == L
                @test rotate!(rotate!(rotate!(rotate!(L2, 90), 90), 90), 90) == L
                @test rotate!(rotate!(L2, 180), 180) == L
                @test rotate!(rotate!(L2, 270), 90) == L

                @test rotate!(rotate!(L2, 90), -90) == L
                @test rotate!(rotate!(L2, -90), 90) == L

                # these tests include rounding errors, use isapprox
                @test rotate!(rotate!(L2, 45), 45) ≈ rotate!(L3, 90)
                @test rotate!(rotate!(L2, 30), 60) ≈ rotate!(L3, 90)
                @test rotate!(rotate!(L2, 60), 30) ≈ rotate!(rotate!(L3, 80), 10)
            end
        end
    end
end

@testset "Reverse" begin
    @testset for NF in (Float16, Float32, Float64)
        @testset for truncation in (5, 10, 15)
            @testset for k in 0:3
                if k == 0
                    L = rand(LowerTriangularArray{Complex{NF}}, truncation, truncation)
                else
                    L = rand(LowerTriangularArray{Complex{NF}}, truncation, truncation, k)
                end

                L2 = reverse(L, dims = :lat)
                L3 = reverse(L, dims = :lon)

                # reversing twice is back to the beginning
                @test reverse(L2, dims = :lat) == L
                @test reverse(L3, dims = :lon) == L

                # order of reversals doesn't matter
                @test reverse(L2, dims = :lon) == reverse(L3, dims = :lat)

                # in place
                reverse!(L2, dims = :lat)
                reverse!(L3, dims = :lon)
                @test L2 == L
                @test L3 == L
            end
        end
    end
end

@testset "Spectrum" begin
    # truncation vs lmax, mmax constructors
    @test Spectrum(5, 5) == Spectrum(5, one_degree_more = false)
    @test Spectrum(5, 5) == Spectrum(truncation = 5, one_degree_more = false)
    @test Spectrum(6, 5) == Spectrum(truncation = 5, one_degree_more = true)

    s = Spectrum(5, 5)
    L = rand(Float32, s)

    for lms in eachorder(L)
        for lm in lms
            l, m = LowerTriangularArrays.i2lm(lm, s.mmax)
            @test l == s.l_indices[lm]
            @test m == s.m_indices[lm]
        end
    end
end

@testset "LTA view" begin
    L = randn(LowerTriangularArray{Float32}, 5, 5, 2)
    @test view(L, :, 1) isa SubArray
    @test view(L, 1, :) isa SubArray
    @test LowerTriangularArrays.lta_view(L, :) isa SubArray                 # unravels both layers
    @test LowerTriangularArrays.lta_view(L, :, 1) isa LowerTriangularArray
    @test LowerTriangularArrays.lta_view(L, 1, :) isa SubArray

    L = randn(LowerTriangularArray{Float32}, 5, 5)
    @test LowerTriangularArrays.lta_view(L, 1:3) isa SubArray
    @test LowerTriangularArrays.lta_view(L, 1) isa SubArray
    @test LowerTriangularArrays.lta_view(L, :) isa LowerTriangularArray     # this is LTA representable though!
end

@testset "zero_last_degree!" begin
    @testset for NF in (Float32, Float64)
        # Test 1D LowerTriangularMatrix
        @testset "1D LowerTriangularMatrix" begin
            lmax, mmax = 6, 5
            L = randn(LowerTriangularMatrix{NF}, lmax, mmax)
            L_copy = copy(L.data)

            # Zero the last degree
            zero_last_degree!(L)    # is exported
            LowerTriangularArrays.zero_last_degree!(L)

            # Check that all elements with l == lmax are zero
            for m in 1:mmax
                @test L[lmax, m] == 0
            end

            # Check that other elements are unchanged
            for m in 1:mmax
                for l in m:(lmax - 1)
                    @test L[l, m] == L_copy[LowerTriangularArrays.lm2i(l, m, lmax)]
                end
            end
        end

        # Test 2D LowerTriangularArray (with vertical layers)
        @testset "2D LowerTriangularArray" begin
            lmax, mmax, nlayers = 6, 5, 3
            L = randn(LowerTriangularArray{NF}, lmax, mmax, nlayers)
            L_copy = copy(L.data)

            # Zero the last degree
            LowerTriangularArrays.zero_last_degree!(L)

            # Check that all elements with l == lmax are zero across all layers
            for k in 1:nlayers
                for m in 1:mmax
                    @test L[lmax, m, k] == 0
                end
            end

            # Check that other elements are unchanged
            for k in 1:nlayers
                for m in 1:mmax
                    for l in m:(lmax - 1)
                        lm = LowerTriangularArrays.lm2i(l, m, lmax)
                        @test L[l, m, k] == L_copy[lm, k]
                    end
                end
            end
        end
    end
end

@testset "truncate!" begin
    @testset for NF in (Float32, ComplexF32)
        @testset for lmax in (8, 16, 32)
            mmax = lmax
            nlayers = 3

            # Test LowerTriangularMatrix (2D)
            L = rand(LowerTriangularMatrix{NF}, lmax, mmax)
            L_original = deepcopy(L)

            # Truncate to half the resolution (1-based)
            ltrunc = lmax ÷ 2
            mtrunc = mmax ÷ 2
            LowerTriangularArrays.truncate!(L, ltrunc, mtrunc)

            # Check that coefficients beyond truncation are zero
            for m in 1:mmax
                for l in m:lmax
                    if l > ltrunc || m > mtrunc  # 1-based indexing
                        @test L[l, m] == 0
                    else
                        # Check that coefficients within truncation are unchanged
                        @test L[l, m] == L_original[l, m]
                    end
                end
            end

            # Test LowerTriangularArray (3D)
            L3D = rand(LowerTriangularArray{NF}, lmax, mmax, nlayers)
            L3D_original = deepcopy(L3D)

            LowerTriangularArrays.truncate!(L3D, ltrunc, mtrunc)

            for k in 1:nlayers
                for m in 1:mmax
                    for l in m:lmax
                        if l > ltrunc || m > mtrunc
                            @test L3D[l, m, k] == 0
                        else
                            @test L3D[l, m, k] == L3D_original[l, m, k]
                        end
                    end
                end
            end

            # Test asymmetric truncation (ltrunc != mtrunc)
            L_asym = rand(LowerTriangularMatrix{NF}, lmax, mmax)
            L_asym_original = deepcopy(L_asym)

            ltrunc_asym = lmax - 1  # truncate only last degree
            mtrunc_asym = mmax ÷ 2  # truncate half the orders
            LowerTriangularArrays.truncate!(L_asym, ltrunc_asym, mtrunc_asym)

            for m in 1:mmax
                for l in m:lmax
                    if l > ltrunc_asym || m > mtrunc_asym
                        @test L_asym[l, m] == 0
                    else
                        @test L_asym[l, m] == L_asym_original[l, m]
                    end
                end
            end
        end
    end
end

@testset "ArrayDimensions" begin
    using SpeedyWeatherInternals.ArrayDimensions: LM, LMZ, LMT, LMZT, hastime, hasvertical

    s = Spectrum(truncation = 6)

    # default dims is LM (2D spectral)
    L2 = zeros(LowerTriangularMatrix{Float32}, s)
    @test L2.dims isa LM
    @test !hastime(L2)
    @test !hasvertical(L2)

    # explicit 3D spectral + vertical
    L3z = zeros(LowerTriangularArray{Float32}, s, LMZ(), 3)
    @test L3z.dims isa LMZ
    @test !hastime(L3z)
    @test hasvertical(L3z)

    # explicit 3D spectral + time
    L3t = zeros(LowerTriangularArray{Float32}, s, LMT(), 3)
    @test L3t.dims isa LMT
    @test hastime(L3t)
    @test !hasvertical(L3t)

    # explicit 4D spectral + vertical + time
    L4 = zeros(LowerTriangularArray{Float32}, s, LMZT(), 3, 2)
    @test L4.dims isa LMZT
    @test hastime(L4)
    @test hasvertical(L4)

    # dims are preserved through similar, zero, and lta_view
    L3z_sim = similar(L3z)
    @test L3z_sim.dims isa LMZ

    L3z_zero = zero(L3z)
    @test L3z_zero.dims isa LMZ

    L3z_view = lta_view(L3z, :, 1)
    @test L3z_view.dims isa LM

    L3z_range_view = lta_view(L3z, :, 1:2)
    @test L3z_range_view.dims isa LMZ

    # getindex with integer drops dims; range preserves
    @test L3z[:, 1].dims isa LM
    @test L3z[:, 1:2].dims isa LMZ

    # 4D: two explicit non-horizontal indices
    @test L4[:, 1:3, 1].dims isa LMZ   # drop time, keep vertical range
    @test L4[:, 1, 1].dims isa LM      # drop both vertical and time

    # dims are preserved through truncate and interpolate
    L3z_trunc = LowerTriangularArrays.truncate(L3z, 3)
    @test L3z_trunc.dims isa LMZ
    @test size(L3z_trunc, OneBased, as = Matrix) == (3, 3, 3)

    L3z_interp = LowerTriangularArrays.interpolate(L3z, 10)
    @test L3z_interp.dims isa LMZ
    @test size(L3z_interp, OneBased, as = Matrix) == (10, 10, 3)

    L2_trunc = LowerTriangularArrays.truncate(L2, 3)
    @test L2_trunc.dims isa LM
end

@testset "Rotate/Reverse n-dimensional" begin
    @testset for trailing_dims in ((2,), (2, 3), (2, 3, 2))
        L = rand(LowerTriangularArray{ComplexF64}, 10, 10, trailing_dims...)

        rotated = rotate!(deepcopy(L), 30)
        reversed_lat = reverse(L, dims = :lat)
        reversed_lon = reverse(L, dims = :lon)

        # operating on all matrices at once == operating on every matrix independently
        for c in CartesianIndices(trailing_dims)
            layer = L[:, c]
            @test rotate!(deepcopy(layer), 30) == rotated[:, c]
            @test reverse(layer, dims = :lat) == reversed_lat[:, c]
            @test reverse(layer, dims = :lon) == reversed_lon[:, c]
        end
    end
end
